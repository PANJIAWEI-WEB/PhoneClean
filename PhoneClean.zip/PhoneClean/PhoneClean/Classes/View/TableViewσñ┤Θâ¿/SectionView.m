//
//  SectionView.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "SectionView.h"

@interface SectionView ()

@property (nonatomic, weak) UILabel *countView;
@property (nonatomic, strong) NSString *title;

@end
@implementation SectionView

+ (instancetype)headerViewWithTableView:(UITableView *)tableView title:(nonnull NSString *)title
{
    
    static NSString *ID = @"header";
    
    SectionView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:ID];
    if (header == nil) {
        header = [[SectionView alloc] initWithReuseIdentifier:ID];
    }
    header.title = title;
    header.countView.text = title;
    
    return header;
    
}



// 在这个初始化方法中,SectionView的frame\bounds没有值
- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier

{

    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {

       // 添加子控件
        UILabel *countView = [[UILabel alloc] init];
        countView.font = [UIFont systemFontOfSize:14.0f];
        countView.backgroundColor = [UIColor clearColor];
        countView.textColor = UIColorFromRGB(0x999999);
        countView.numberOfLines = 0;
        [self.contentView addSubview:countView];
        self.countView = countView;
    }
   return self;
}


- (void)layoutSubviews
{
#warning 一定要调用super的方法
   [super layoutSubviews];
    CGFloat countY = 12;
    CGFloat countX = 12;
    CGFloat countH = self.frame.size.height - countY;
    CGFloat countW = ScreenWidth - countX * 2;
    self.countView.frame = CGRectMake(countX, countY, countW, countH);
}

@end
