//
//  CircleUpView.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "CircleUpView.h"

@implementation CircleUpView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)drawRect:(CGRect)rect{
    
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:rect
    byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft cornerRadii:CGSizeMake(20, 20)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = rect;
    maskLayer.path = maskPath.CGPath;
    self.layer.mask = maskLayer;
}

@end
