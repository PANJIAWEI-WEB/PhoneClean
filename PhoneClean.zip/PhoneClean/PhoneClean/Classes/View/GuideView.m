//
//  GuideView.m
//  PhoneClean
//
//  Created by PW on 2021/5/9.
//

#import "GuideView.h"
@interface GuideView()

@property (nonatomic,strong) UILabel *label;
@property (nonatomic,strong) UILabel *infoLabel0;
@property (nonatomic,strong) UILabel *infoLabel1;
@property (nonatomic,strong) UILabel *infoLabel2;
@property (nonatomic,strong) UILabel *infoLabel3;
@property (nonatomic,strong) UIImageView *imageView;



@end
@implementation GuideView

- (instancetype)initWithFrame:(CGRect)frame
                        index:(NSInteger)index
{
    self = [super initWithFrame:frame];
    if (self) {
        self.index = index;
        [self initUI];
    }
    return self;
}

- (void)initUI{
    self.backgroundColor = RGB_COLOR(26, 199, 108);
    
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = RGB_COLOR(26, 199, 108);
    [self addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        if (@available(iOS 11.0, *)) {
            make.top.mas_equalTo(self.mas_safeAreaLayoutGuideTop).mas_offset(0);
        }else{
            make.top.mas_equalTo(self.mas_top).mas_offset(0);
        }
        make.left.right.mas_equalTo(self);
        make.height.mas_equalTo(260);
    }];
    
    UIView *whiteView = [[UIView alloc] init];
    [whiteView setBackgroundColor:UIColorFromRGB(0xf5f5f5)];
    [self addSubview:whiteView];
    [whiteView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(view.mas_bottom);
        make.left.right.bottom.mas_equalTo(self);
    }];
    
    
    
    UIButton *continueButton = [[UIButton alloc] init];
    [continueButton setBackgroundColor:RGB_COLOR(26, 199, 108)];
    [whiteView addSubview:continueButton];
    [continueButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(whiteView);
        make.left.mas_equalTo(whiteView).mas_offset(60);
        make.height.mas_equalTo(40);
        if (@available(iOS 11.0, *)) {
            make.bottom.mas_equalTo(self.mas_safeAreaLayoutGuideBottom).mas_offset(-90);
        } else {
            // Fallback on earlier versions
            make.bottom.mas_equalTo(self.mas_bottom).mas_offset(-90);
        }
    }];
    [continueButton setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [continueButton.titleLabel setFont:[UIFont systemFontOfSize:15]];
    [continueButton setTitle:@"继续" forState:(UIControlStateNormal)];
    [continueButton addTarget:self action:@selector(clickedAction) forControlEvents:(UIControlEventTouchDown)];
    continueButton.layer.cornerRadius = 10;
    continueButton.layer.masksToBounds = YES;
    
    
    
    
    
    self.label = [[UILabel alloc] init];
    self.label.backgroundColor = [UIColor clearColor];
    self.label.font = [UIFont boldSystemFontOfSize:25];
    self.label.text = @"图片清理";
    [self.label setTextColor:UIColorFromRGB(0x333333)];
    [whiteView addSubview:self.label];
    [self.label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(whiteView).mas_offset(20);
        make.centerX.mas_equalTo(whiteView);
    }];
    
    self.infoLabel0 = [self createLabel];
    [whiteView addSubview:self.infoLabel0];
    [self.infoLabel0 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.label.mas_bottom).mas_offset(15);
        make.centerX.mas_equalTo(whiteView);
    }];
    
    
    self.infoLabel1 = [self createLabel];
    [whiteView addSubview:self.infoLabel1];
    [self.infoLabel1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.infoLabel0.mas_bottom).mas_offset(15);
        make.centerX.mas_equalTo(whiteView);
    }];
    self.infoLabel2 = [self createLabel];
    [whiteView addSubview:self.infoLabel2];
    [self.infoLabel2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.infoLabel1.mas_bottom).mas_offset(15);
        make.centerX.mas_equalTo(whiteView);
    }];
    self.infoLabel3 = [self createLabel];
    [whiteView addSubview:self.infoLabel3];
    [self.infoLabel3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.infoLabel2.mas_bottom).mas_offset(15);
        make.centerX.mas_equalTo(whiteView);
    }];
    
    
    self.imageView = [[UIImageView alloc] init];
    [view addSubview:self.imageView];
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.mas_equalTo(160);
        make.centerX.mas_equalTo(view);
        make.bottom.mas_equalTo(view).mas_offset(-40);
    }];
    
}

- (UILabel *)createLabel{
    UILabel *label = [[UILabel alloc] init];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:17];
    label.text = @"";
    [label setTextColor:UIColorFromRGB(0x666666)];
    return label;
}


- (void)setIndex:(NSInteger)index{
    _index = index;
    switch (index) {
        case 0:{
            self.label.text = @"图片&视频清理";
            self.infoLabel0.text = @"1.快速查找重复图片&视频";
            self.infoLabel1.text = @"2.甄别大图片&视频　　　";
            self.infoLabel2.text = @"3.发现模糊图片&损坏视频";
            self.infoLabel3.text = @"4.自定义图片&视频参数　";
        }break;
        case 1:{
            self.label.text = @"通讯录清理";
            self.infoLabel0.text = @"1.查找无效通讯录联系人";
            self.infoLabel1.text = @"2.筛选重复联系人　　　";
            self.infoLabel2.text = @"";
            self.infoLabel3.text = @"";
            
        }break;
        case 2:{
            self.label.text = @"日历&提醒清理";
            self.infoLabel0.text = @"1.过期日历及时删除　　　";
            self.infoLabel1.text = @"2.无用提醒事项实时清理　";
            self.infoLabel2.text = @"3.更多功能等你来体验　　";
            self.infoLabel3.text = @"";
        }break;
            
        default:
            break;
    }
    [self.imageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"guide%zd",index]]];
}

- (void)clickedAction{
    if ([self.delegate respondsToSelector:@selector(didSelected:)]) {
        [self.delegate didSelected:self.index];
    }
    NSLog(@"当前index : %zd",self.index);
}
@end
