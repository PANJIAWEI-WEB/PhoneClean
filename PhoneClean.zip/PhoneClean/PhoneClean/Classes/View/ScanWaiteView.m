//
//  ScanWaiteView.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "ScanWaiteView.h"
@interface ScanWaiteView()
//三角
@property(nonatomic , strong)CAShapeLayer *sanjiaoLayer;

@end
@implementation ScanWaiteView

- (void)layoutSubviews{
    [super layoutSubviews];
    self.showLayer.frame = self.bounds;
    self.sanjiaoLayer.frame = self.bounds;
}
#pragma mark - lazy
- (CAShapeLayer *)showLayer{
    if (!_showLayer) {
        _showLayer = [CAShapeLayer new];
        _showLayer.lineWidth = 1;
        _showLayer.strokeColor = RGB_COLOR(59,185,222).CGColor;
        _showLayer.strokeColor = UIColorFromRGB(0xf1f1f1).CGColor;
        _showLayer.fillColor = [UIColor clearColor].CGColor;
        _showLayer.fillColor = RGBA_COLOR(251, 251, 251, 0.3).CGColor;
        [self.layer addSublayer:_showLayer];
    }
    return _showLayer;
}
- (CAShapeLayer *)sanjiaoLayer{
    if (!_sanjiaoLayer) {
        _sanjiaoLayer = [CAShapeLayer new];
        _sanjiaoLayer.lineWidth = 1;
        _sanjiaoLayer.strokeColor = RGB_COLOR(59,185,222).CGColor;
        _sanjiaoLayer.strokeColor = UIColorFromRGB(0xf1f1f1).CGColor;
        _sanjiaoLayer.fillColor = [UIColor clearColor].CGColor;
        _sanjiaoLayer.fillColor = RGBA_COLOR(251, 251, 251, 0.3).CGColor;
        [self.layer addSublayer:_sanjiaoLayer];
    }
    return _showLayer;
}
#pragma mark - method
- (void)startAnim{
    
    [self sanjiao];
    //添加扫描view
//    [[UIColor whiteColor] set];
    
//    UIBezierPath *path = [AxcDrawPath AxcDrawArrowBlockArcRingCenter:CGPointMake(60, 60)    // 中心
//                                              outsideRadius:58.5                  // 外圆半径
//                                                blockRadius:18                   // 箭头半径
//                                                 blockCount:7                    // 块个数
//                                               angleSpacing:10                   // 角度间距
//                                                 arrowAngle:10                   // 箭头相对伸出角度
//                                                 startAngle:-90                  // 起始角度
//                                               openingAngle:0                    // 开合角度
//                                                  clockwise:YES];
    
//    UIBezierPath *path = [AxcDrawPath AxcDrawPointArrowCenter:CGPointMake(60, 60)   // 圆心
//                                                       radius:58.5                     // 半径
//                                                  arrowRadius:10                      // 箭头高度/向心半径差
//                                                  arrowRadian:20                      // 箭头圆弧角度
//                                                   arrowCount:10                       // 箭头个数
//                                                  connections:YES                     // 是否形成闭合圆？
//                                               arcConnections:NO                     // 是否使用圆弧作为连接边？
//                                                      outSide:NO                     // 箭头向外
//                                                   startAngle:-90-(20/2.f)            // 起始角
//                                                 openingAngle:0                       // 开合角
//                                                    clockwise:YES];
    
    UIBezierPath *path = [AxcDrawPath AxcDrawTrapezoidalBlockArcRingCenter:CGPointMake(60, 60)   // 中心
                                                             outsideRadius:58.6                    // 外圆半径
                                                               blockRadius:12                     // 块半径
                                                                blockCount:9                      // 块个数
                                                              angleSpacing:10   // 间距角度
                                                                startAngle:-115 ];
    
    
    path.lineWidth = 3.f;

    self.showLayer.path = path.CGPath;
    CABasicAnimation *animation = [AxcCAAnimation AxcDrawLineDuration:2 timingFunction:kCAMediaTimingFunctionEaseInEaseOut];
    animation.autoreverses = YES;               // 动画结束时执行逆动画
    animation.repeatCount = HUGE_VALF;          // 重复次数
    animation.removedOnCompletion = NO;
    [self.showLayer addAnimation:animation forKey:@"animation"];
    
//    [self sanjiao];
}

- (void)sanjiao{
    
//    [[UIColor whiteColor] set];
    UIBezierPath *path = [AxcDrawPath AxcDrawCircularArcCenter:CGPointMake(60, 60)  // 中心
                                                        radius:20                    // 半径
                                                         count:3                      // 圆弧个数
                                                        radian:30                     // 圆弧弧度
                                                    startAngle:-90-15
                                                  openingAngle:0
                                                    connection:YES];
    path.lineWidth = 3.f;
    self.showLayer.path = path.CGPath;
}



@end
