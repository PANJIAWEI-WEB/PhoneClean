//
//  AutoCleanCell.h
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import <UIKit/UIKit.h>
@class AutoModel;
NS_ASSUME_NONNULL_BEGIN

@interface AutoCleanCell : UITableViewCell
@property (nonatomic, strong) AutoModel *model;
@property (nonatomic, assign) NSInteger index;
@end

NS_ASSUME_NONNULL_END
