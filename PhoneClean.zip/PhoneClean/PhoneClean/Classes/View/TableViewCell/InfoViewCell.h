//
//  InfoViewCell.h
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, InfoType) {
    InfoTypeEvents,
    InfoTypeReminder,
    InfoTypeSameNumber,
    InfoTypeNilNumber,
};
@interface InfoViewCell : UITableViewCell
@property (nonatomic, assign) InfoType type;
@property (nonatomic, strong) id info;

@property (nonatomic, assign) BOOL deleted;
@end
NS_ASSUME_NONNULL_END
