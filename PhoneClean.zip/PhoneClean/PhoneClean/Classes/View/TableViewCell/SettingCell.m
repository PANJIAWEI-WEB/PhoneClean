//
//  SettingCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "SettingCell.h"

@interface SettingCell()

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@end
@implementation SettingCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setTitleString:(NSString *)titleString{
    
    _titleString = titleString;
    self.nameLabel.text = titleString;
}
@end
