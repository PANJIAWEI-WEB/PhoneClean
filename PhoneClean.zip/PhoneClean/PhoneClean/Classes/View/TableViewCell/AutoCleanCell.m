//
//  AutoCleanCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "AutoCleanCell.h"
#import "AutoModel.h"
@interface AutoCleanCell()

@property (weak, nonatomic) IBOutlet UILabel *labelTitle;
@property (weak, nonatomic) IBOutlet UILabel *seletedLabel;
@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *animView;

@end
@implementation AutoCleanCell


- (void)setModel:(AutoModel *)model{
    _model = model;
    if (model.process == 0) {
        [self.animView startAnimating];
        [self.animView setHidden:NO];
        self.labelTitle.text = model.title;
        self.seletedLabel.text = @"正在扫描中……";
    }else{
        [self.animView stopAnimating];
        [self.animView setHidden:YES];
        self.seletedLabel.text = @"扫描完成！";
        if(self.index > 1){
            self.labelTitle.text = [NSString stringWithFormat:@"%@(%d条)",model.title,(int)model.total];
        }else{
            [self updateInfo];
        }
    }
}

- (void)updateInfo{
    NSUInteger size = self.model.total;
    
    //文件大小
    NSString *fileSize = @"0";
    NSString *units = @"KB";
    
    NSInteger KB = M_KB;
    NSInteger MB = M_MB;
    NSInteger GB = MB*KB;
    if (size < 10)
    {
        fileSize =  @"0";
        units = @"KB";
        
    }else if (size < MB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/KB];
        units = @"KB";
    }else if (size < GB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/MB];
        units = @"MB";
        
    }else
    {
        fileSize = [NSString stringWithFormat:@"%.2f",((CGFloat)size)/GB];
        units = @"GB";
    }
    
    self.labelTitle.text = [NSString stringWithFormat:@"%@(%@%@)",self.model.title,fileSize,units];
}
- (void)setIndex:(NSInteger)index{
    _index = index;
    NSArray *array = @[@"图片清理",@"视频清理",@"日历&提醒清理",@"通讯录清理"];
    [self.coverImageView setImage:[UIImage imageNamed:array[index]]];
}
@end
