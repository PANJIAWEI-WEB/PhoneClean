//
//  InfoViewCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "InfoViewCell.h"
#import <Contacts/Contacts.h>
#import <EventKit/EventKit.h>
#import "EventHelper.h"
#import "ContactHelper.h"
#import <Contacts/Contacts.h>
@interface InfoViewCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *desLabel;
@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *widthConstraint;
@property (weak, nonatomic) IBOutlet UIImageView *tagImageView;

@end
@implementation InfoViewCell

//两种信息
- (void)setType:(InfoType)type{
    _type = type;
    if (type < InfoTypeSameNumber) {
        self.widthConstraint.constant = 2;
    }else{
        self.widthConstraint.constant = 45;
    }
}
//信息展示
- (void)setInfo:(id)info{
    
    _info = info;
    if ([info isKindOfClass:[EKReminder class]]) {
        
        self.nameLabel.text = ((EKReminder *)info).title;
        self.desLabel.text = [EventHelper getTimeBy:info];
        
    }else if([info isKindOfClass:[EKEvent class]]) {
        
        self.nameLabel.text = ((EKEvent *)info).title;
        self.desLabel.text = [EventHelper getTimeBy:info];
    }else{
//        CNContact
        CNContact *temp = info;
        
        CNLabeledValue *labelValue = temp.phoneNumbers.firstObject;
        CNPhoneNumber *phoneNumber = labelValue.value;
        self.desLabel.text = phoneNumber.stringValue;
        
        NSString *nameStr = [NSString stringWithFormat:@"%@%@",temp.familyName,temp.givenName];
        self.nameLabel.text = nameStr;
        if (!nameStr || nameStr.length == 0) {
            self.nameLabel.text = phoneNumber.stringValue;
        }
    }
}
//删除标记
- (void)setDeleted:(BOOL)deleted{
    _deleted = deleted;
    [self.tagImageView setImage:[UIImage imageNamed:deleted?@"selected":@"unselected"]];
}
@end
