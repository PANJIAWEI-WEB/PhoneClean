//
//  ConfigCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "ConfigCell.h"
@interface ConfigCell()

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;

@end
@implementation ConfigCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (void)setTitleString:(NSString *)titleString{
    
    _titleString = titleString;
    self.nameLabel.text = titleString;
}
- (void)setSizeInfo:(NSString *)sizeInfo{
    _sizeInfo = sizeInfo;
    
    self.numberLabel.text = sizeInfo;
}
@end
