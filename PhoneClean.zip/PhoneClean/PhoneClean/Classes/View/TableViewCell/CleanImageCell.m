//
//  CleanImageCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "CleanImageCell.h"
#import "ImageUtils.h"
#import "VideoUtils.h"
@interface CleanImageCell()

@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *deletedArray;
@property (nonatomic, strong) NSString *title;

@property (weak, nonatomic) IBOutlet UILabel *labelTitle;
@property (weak, nonatomic) IBOutlet UILabel *seletedLabel;
@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *animView;


@end
@implementation CleanImageCell

- (NSMutableArray *)deletedArray{
    if (!_deletedArray) {
        _deletedArray = [NSMutableArray array];
    }
    return _deletedArray;
}

- (void)setTitle:(NSString *)title{
    _title = title;

    if (self.scanModel) {
        self.labelTitle.text = title;
    }else{
        NSString *dw = @"张";
        if (self.video) {
            dw = @"个";
        }
        self.labelTitle.text = [NSString stringWithFormat:@"%@  %zd%@",title,self.deletedArray.count,dw];
    }
    
    
}
- (void)setScanModel:(BOOL)scanModel {
    _scanModel = scanModel;
    
    [self.animView setHidden:!scanModel];
    if (scanModel) {
        [self.animView startAnimating];
    }else{
        [self.animView stopAnimating];
    }
}

- (void)setType:(NSInteger)type{
    _type = type;
    
    NSString *name = @"image";
    if (!self.video) {
        [self.dataArray removeAllObjects];
        [self.dataArray addObjectsFromArray:[[ImageUtils shareManager] getImageDataByType:type]];
        [self.deletedArray removeAllObjects];
        [self.deletedArray addObjectsFromArray:[[ImageUtils shareManager] getDeletedImageByType:type]];
        
        
        switch (type) {
            case 0:
                self.title = @"相似图片";
                break;
                
            case 1:
                self.title = @"屏幕截图";
                break;
                
            case 2:
                self.title = @"模糊图片";
                break;
                
            case 3:
                self.title = @"超大图片";
                break;
            default:
                break;
        }
    
    }else{
        [self.dataArray removeAllObjects];
        [self.dataArray addObjectsFromArray:[[VideoUtils shareManager] getVideoDataByType:type]];
        [self.deletedArray removeAllObjects];
        [self.deletedArray addObjectsFromArray:[[VideoUtils shareManager] getDeletedVideoByType:type]];
        name = @"video";
        
        switch (type) {
            case 0:
                self.title = @"相似视频";
                break;
                
            case 1:
                self.title = @"损坏视频";
                break;
                
            case 2:
                self.title = @"超大视频";
                break;
            default:
                break;
        }
        
    }
    
    
    [self.coverImageView setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@%zd",name,type]]];
    
    [self updateSize];
    
    
}
- (void)updateSize{
    
    
    NSUInteger size = [[ImageUtils shareManager] getSizeByType:self.type];
    
    if (self.video) {
        size = [[VideoUtils shareManager] getSizeByType:self.type];
    }
    
    //文件大小
    NSString *fileSize = @"0KB";
    
    NSInteger KB = M_KB;
    NSInteger MB = M_MB;
    NSInteger GB = MB*KB;
    if (size < 10)
    {
        fileSize =  @"0KB";
        
    }else if (size < MB)
    {
        fileSize = [NSString stringWithFormat:@"%.1fKB",((CGFloat)size)/KB];
    }else if (size < GB)
    {
        fileSize = [NSString stringWithFormat:@"%.1fMB",((CGFloat)size)/MB];
    }else
    {
        fileSize = [NSString stringWithFormat:@"%.2fGB",((CGFloat)size)/GB];
    }
    
    if (self.scanModel) {
        self.seletedLabel.text = @"正在扫描中……";
    }else{
        self.seletedLabel.text = [NSString stringWithFormat:@"已选中%@",fileSize];
    }
}
@end
