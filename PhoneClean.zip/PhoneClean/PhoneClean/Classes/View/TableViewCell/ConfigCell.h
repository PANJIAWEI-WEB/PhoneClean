//
//  ConfigCell.h
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ConfigCell : UITableViewCell

@property (nonatomic, strong) NSString *titleString;
@property (nonatomic, strong) NSString *sizeInfo;

@end

NS_ASSUME_NONNULL_END
