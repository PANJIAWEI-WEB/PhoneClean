//
//  GuideView.h
//  PhoneClean
//
//  Created by PW on 2021/5/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol GuideViewDelegate <NSObject>

- (void)didSelected:(NSInteger)index;

@end
@interface GuideView : UIView

@property(nonatomic , assign)NSInteger index;
@property(nonatomic , assign)id<GuideViewDelegate> delegate;
- (instancetype)initWithFrame:(CGRect)frame
                        index:(NSInteger)index;
@end

NS_ASSUME_NONNULL_END
