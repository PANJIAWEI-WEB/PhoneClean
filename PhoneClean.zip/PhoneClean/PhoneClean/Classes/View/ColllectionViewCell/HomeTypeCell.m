//
//  HomeTypeCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "HomeTypeCell.h"
@interface HomeTypeCell()
@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end
@implementation HomeTypeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (void)setInfo:(NSString *)info{
    _info = info;
    self.label.text = info;
    self.coverImageView.image = [UIImage imageNamed:info];
}

@end
