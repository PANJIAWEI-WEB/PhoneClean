//
//  VideoCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "VideoCell.h"
#import <Photos/Photos.h>
#import "VideoUtils.h"
@interface VideoCell()
@property (weak, nonatomic) IBOutlet UIImageView *coverImageView;
@property (weak, nonatomic) IBOutlet UIButton *seletedButton;
@property (nonatomic, strong) PHImageRequestOptions *imageOpt;

@end
@implementation VideoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self.seletedButton setImageEdgeInsets:(UIEdgeInsetsMake(5, 10, 10, 5))];
}
- (void)setDeleted:(BOOL)deleted{
    _deleted = deleted;
    
    [self.seletedButton setImage:[UIImage imageNamed:deleted?@"selected":@"unselected"] forState:(UIControlStateNormal)];
    
    
}
- (IBAction)selectedAction:(UIButton *)sender {
    self.deleted = !self.deleted;
    
    [[VideoUtils shareManager] updateDeletedInfo:self.info withType:(self.type)];
    
    if ([self.delegate respondsToSelector:@selector(updateInfo:)]) {
        [self.delegate updateInfo:self.type];
    }
    
}


- (void)setInfo:(NSDictionary *)info{
    _info = info;
    PHAsset *asset = info[@"asset"];
    
    
    
    PHVideoRequestOptions *options = [[PHVideoRequestOptions alloc] init];
    options.version = PHImageRequestOptionsVersionCurrent;
    options.deliveryMode = PHVideoRequestOptionsDeliveryModeAutomatic;
    
    
    [[PHImageManager defaultManager] requestAVAssetForVideo:asset options:options resultHandler:^(AVAsset * _Nullable ast, AVAudioMix * _Nullable audioMix, NSDictionary * _Nullable info) {

        AVURLAsset* urlAsset = (AVURLAsset*)ast;

        NSNumber *size;
        [urlAsset.URL getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
        // 获取缩率图
            __weak typeof(self) weakSelf = self;
        PHImageManager *mgr = [PHImageManager defaultManager];
        [mgr requestImageForAsset:asset targetSize:CGSizeMake(125, 125) contentMode:PHImageContentModeAspectFill options:self.imageOpt resultHandler:^(UIImage *result, NSDictionary *info) {
            StrongSelf(strongSelf)
            strongSelf.coverImageView.image = result;
        }];
    }];
    
    // 获取缩率图
    PHImageManager *mgr = [PHImageManager defaultManager];
    __weak typeof(self) weakSelf = self;
    [mgr requestImageForAsset:asset
                   targetSize:CGSizeMake(125, 125)
                  contentMode:PHImageContentModeDefault
                      options:self.imageOpt
                resultHandler:^(UIImage *result, NSDictionary *info) {
        
        weakSelf.coverImageView.image = result;
    }];
    
}
- (PHImageRequestOptions *)imageOpt {
    if (!_imageOpt) {
        _imageOpt = [[PHImageRequestOptions alloc] init];
        // resizeMode 属性控制图像的剪裁
        _imageOpt.resizeMode = PHImageRequestOptionsResizeModeNone;
        // deliveryMode 则用于控制请求的图片质量
        _imageOpt.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
    }
    return _imageOpt;
}
@end
