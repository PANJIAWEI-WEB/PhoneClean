//
//  VideoCell.h
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol VideoCellDelegate <NSObject>

- (void)updateInfo:(NSInteger)type;

@end
@interface VideoCell : UICollectionViewCell

@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) id<VideoCellDelegate> delegate;
@property (nonatomic, assign) BOOL deleted;
@property (nonatomic, strong) NSDictionary *info;
@end

NS_ASSUME_NONNULL_END
