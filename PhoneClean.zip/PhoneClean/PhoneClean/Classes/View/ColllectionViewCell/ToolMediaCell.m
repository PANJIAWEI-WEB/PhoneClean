//
//  ToolMediaCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "ToolMediaCell.h"
#import <Photos/Photos.h>
@interface ToolMediaCell()
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UIButton *button;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) PHImageRequestOptions *imageOpt;
@end
@implementation ToolMediaCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}
- (void)initUI{
    self.clipsToBounds = YES;
    self.imageView = [[UIImageView alloc] init];
    self.imageView.contentMode = UIViewContentModeScaleAspectFill;
    [self addSubview:self.imageView];
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self);
    }];
    
    UIView *grayView = [[UIView alloc] init];
    grayView.backgroundColor = RGBA_COLOR(0, 0, 0, 0.1);
    [self addSubview:grayView];
    [grayView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self);
    }];
    
    //
    self.button = [[UIButton alloc] init];
    [self.button addTarget:self action:@selector(selectedAction) forControlEvents:(UIControlEventTouchDown)];
    self.button.imageEdgeInsets = UIEdgeInsetsMake(5, 10, 10, 5);
    [self.contentView addSubview:self.button];
    [self.button setImage:[UIImage imageNamed:@"selected"] forState:(UIControlStateNormal)];
    [self.button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.width.mas_equalTo(35);
        make.right.top.mas_equalTo(self.contentView);
    }];
    
    //大小
    self.label = [[UILabel alloc] init];
    self.label.textAlignment = NSTextAlignmentCenter;
    self.label.font = [UIFont systemFontOfSize:12];
    self.label.textColor = UIColorFromRGB(0xffffff);
    self.label.backgroundColor = RGBA_COLOR(0,0,0,0.3);
    [self addSubview:self.label];
    [self.label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self).mas_offset(-2);
        make.right.mas_equalTo(self.mas_right).mas_offset(-3);
        make.height.mas_equalTo(18);
        make.width.mas_equalTo(self).multipliedBy(0.6);
//        make.left.mas_greaterThanOrEqualTo(self).mas_offset(10);
    }];
    self.label.layer.masksToBounds = YES;
    self.label.layer.cornerRadius = 9.0f;
    
}


- (void)setDict:(NSDictionary *)dict{
    _dict = dict;
    NSNumber *size = [dict valueForKey:@"size"];
    
    self.label.text = [ConfigModel sizeStringBy:([size integerValue])];
    
    //图片
    PHAsset *asset = [dict valueForKey:@"asset"];
    
    //判断类型
    if(asset.mediaType == PHAssetMediaTypeVideo){
        
        
        PHVideoRequestOptions *options = [[PHVideoRequestOptions alloc] init];
        options.version = PHImageRequestOptionsVersionCurrent;
        options.deliveryMode = PHVideoRequestOptionsDeliveryModeAutomatic;
        
        __weak typeof(self) weakSelf = self;
        PHImageManager *mgr = [PHImageManager defaultManager];
        [mgr requestImageForAsset:asset targetSize:CGSizeMake(125, 125) contentMode:PHImageContentModeAspectFill options:self.imageOpt resultHandler:^(UIImage *result, NSDictionary *info) {
            StrongSelf(strongSelf)
            strongSelf.imageView.image = result;
        }];
        
//        [[PHImageManager defaultManager] requestAVAssetForVideo:asset options:options resultHandler:^(AVAsset * _Nullable ast, AVAudioMix * _Nullable audioMix, NSDictionary * _Nullable info) {
//
//            AVURLAsset* urlAsset = (AVURLAsset*)ast;
//
//            NSNumber *size;
//            [urlAsset.URL getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
//            // 获取缩率图
//                __weak typeof(self) weakSelf = self;
//            PHImageManager *mgr = [PHImageManager defaultManager];
//            [mgr requestImageForAsset:asset targetSize:CGSizeMake(125, 125) contentMode:PHImageContentModeAspectFill options:self.imageOpt resultHandler:^(UIImage *result, NSDictionary *info) {
//                StrongSelf(strongSelf)
//                strongSelf.imageView.image = result;
//            }];
//        }];
//
//        // 获取缩率图
//        PHImageManager *mgr = [PHImageManager defaultManager];
//        __weak typeof(self) weakSelf = self;
//        [mgr requestImageForAsset:asset
//                       targetSize:CGSizeMake(125, 125)
//                      contentMode:PHImageContentModeDefault
//                          options:self.imageOpt
//                    resultHandler:^(UIImage *result, NSDictionary *info) {
//
//            weakSelf.imageView.image = result;
//        }];
    }else{
        // 获取缩率图
        PHImageManager *mgr = [PHImageManager defaultManager];
        __weak typeof(self) weakSelf = self;
        [mgr requestImageForAsset:asset
                       targetSize:CGSizeMake(125, 125)
                      contentMode:PHImageContentModeAspectFill
                          options:self.imageOpt
                    resultHandler:^(UIImage *result, NSDictionary *info) {
            
            weakSelf.imageView.image = result;
        }];
    }
    
    
    
    
}

- (void)selectedAction{
    self.showSelected = !self.showSelected;
    
    if ([self.delegate respondsToSelector:@selector(changeData:index:)]) {
        [self.delegate changeData:self.dict index:self.index];
    }
}

- (void)setShowSelected:(BOOL)showSelected{
    _showSelected = showSelected;
    [self.button setImage:[UIImage imageNamed:showSelected?@"selected":@"unselected"] forState:(UIControlStateNormal)];
}
- (PHImageRequestOptions *)imageOpt {
    if (!_imageOpt) {
        _imageOpt = [[PHImageRequestOptions alloc] init];
        // resizeMode 属性控制图像的剪裁
        _imageOpt.resizeMode = PHImageRequestOptionsResizeModeFast;
        // deliveryMode 则用于控制请求的图片质量
        _imageOpt.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
    }
    return _imageOpt;
}
@end
