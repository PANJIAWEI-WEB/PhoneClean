//
//  ToolViewCell.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "ToolViewCell.h"

@interface ToolViewCell()

@property (nonatomic,strong) UIImageView *imageView;
@property (nonatomic,strong) UILabel *label;

@end
@implementation ToolViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}

- (void)initUI{
    self.imageView = [[UIImageView alloc] init];
    [self.contentView addSubview:self.imageView];
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.contentView).mas_offset(-10);
        make.centerX.mas_equalTo(self.contentView);
        
        if (([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)) {
            
            make.width.height.mas_equalTo(self.contentView.mas_width).multipliedBy(1 / 3.0f);
        }else{
            make.width.height.mas_equalTo(30);
        }
    }];
    
    self.label = [[UILabel alloc] init];
    [self.contentView addSubview:self.label];
    
    if (([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)) {
        self.label.font = [UIFont systemFontOfSize:18];
    }else{
        self.label.font = [UIFont systemFontOfSize:12];
    }
    self.label.textAlignment = NSTextAlignmentCenter;
    self.label.textColor = UIColorFromRGB(0x555555);
    self.label.text = @"title";
    [self.label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.imageView.mas_bottom);
        make.centerX.mas_equalTo(self.contentView);
    }];
}
- (void)setInfo:(NSString *)info{
    _info = info;
    self.label.text = info;
    self.imageView.image = [UIImage imageNamed:info];
}
@end
