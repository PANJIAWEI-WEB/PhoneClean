//
//  ToolMediaCell.h
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ToolMediaCellDelegate <NSObject>

- (void)changeData:(NSDictionary *)dict
             index:(NSInteger)index;

@end

@interface ToolMediaCell : UICollectionViewCell

@property (nonatomic, strong) NSDictionary *dict;
@property (nonatomic, assign) BOOL showSelected;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, assign) id<ToolMediaCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
