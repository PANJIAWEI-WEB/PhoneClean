//
//  ImageDetailController.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "ImageDetailController.h"
#import "ImageUtils.h"
#import "ImageCell.h"
#import <YBImageBrowser/YBImageBrowser.h>
@interface ImageDetailController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate,ImageDelegate>
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomConstraint;
@property (weak, nonatomic) IBOutlet UILabel *tLabel;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *deletedArray;
@property (nonatomic, strong)YBImageBrowser * browser;
@end

@implementation ImageDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initData];
    [self initUI];
}
#pragma mark - lazy
- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSMutableArray *)deletedArray{
    if (!_deletedArray) {
        _deletedArray = [NSMutableArray array];
    }
    return _deletedArray;
}
#pragma mark - method
- (IBAction)backAction:(id)sender {
    if (self.backBlock) {
        self.backBlock();
    }
    [self dismissViewControllerAnimated:YES completion:^{
            
    }];
}
- (void)initUI{
    
    switch (self.type) {
        case 0:
            self.tLabel.text = @"相似图片";
            break;
            
        case 1:
            self.tLabel.text = @"屏幕截图";
            break;
            
        case 2:
            self.tLabel.text = @"模糊图片";
            break;
            
        case 3:
            self.tLabel.text = @"超大图片";
            break;
        default:
            break;
    }
    self.bottomConstraint.constant = 0;
    
    
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ImageCell class]) bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:NSStringFromClass([ImageCell class])];
    
    self.collectionView.emptyDataSetSource = self;
    self.collectionView.emptyDataSetDelegate = self;
    
}
- (void)initData{
    [self.dataArray removeAllObjects];
    [self.dataArray addObjectsFromArray:[[ImageUtils shareManager] getImageDataByType:self.type]];
    [self.deletedArray removeAllObjects];
    [self.deletedArray addObjectsFromArray:[[ImageUtils shareManager] getDeletedImageByType:self.type]];
}
#pragma mark - delegate


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ImageCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ImageCell class]) forIndexPath:indexPath];
    
    NSDictionary *dict = self.dataArray[indexPath.row];
    cell.type = self.type;
    cell.info = dict;
    cell.deleted = [self.deletedArray containsObject:dict];
    cell.delegate = self;
    cell.backgroundColor = [UIColor whiteColor];
    cell.layer.cornerRadius = 5.f;
    cell.layer.masksToBounds = YES;
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat width = CGRectGetWidth(collectionView.frame);
    
    CGFloat count = 4;
    
    CGFloat w = (width - count * 10 - 10 * 2 - 2) / count;
    
    return CGSizeMake(w, w);
    
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    //显示大图self.browser.dataSourceArray = da;
    self.browser = [YBImageBrowser new];
    
    NSMutableArray *data = [NSMutableArray array];
    for (NSDictionary *dict in self.dataArray) {
        
        YBIBImageData *data1 = [YBIBImageData new];
        data1.imagePHAsset = dict[@"asset"];
        [data addObject:data1];
    }
    YBIBToolViewHandler *info = [YBIBToolViewHandler new];
    self.browser.toolViewHandlers = @[info,info];
    self.browser.dataSourceArray = data;
    self.browser.currentPage = indexPath.row;
    [self.browser show];
}



#pragma mark - 更新
- (void)updateInfo:(NSInteger)type{
    [self.deletedArray removeAllObjects];
    [self.deletedArray addObjectsFromArray:[[ImageUtils shareManager] getDeletedImageByType:type]];
    
//    [self updateSize];
    
}

- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView
{
    NSString *text = @"未扫描到该类图片";
    
    NSDictionary *attributes = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:14.0f],
                                 NSForegroundColorAttributeName: UIColorFromRGB(0x999999)};
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}
@end
