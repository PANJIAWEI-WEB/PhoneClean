//
//  HomeController.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "HomeController.h"
#import "ZZDottedLineProgress.h"
#import "WaveProgressView.h"
#import "CircleUpView.h"
#import "HomeTypeCell.h"
#import "OptimizeViewController.h"
#import "CategoryViewController.h"
#import "ImageCleanController.h"
#import "VideoCleanController.h"
#import "SettingController.h"
#import "AutoViewController.h"
#import "VIPController.h"
@interface HomeController ()<ZZDottedLineProgressDelegate,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UILabel *tLabel;
@property (weak, nonatomic) IBOutlet ZZDottedLineProgress *circleProcess;
@property (weak, nonatomic) IBOutlet WaveProgressView *waveProgress;
@property (weak, nonatomic) IBOutlet UILabel *processLabel;
@property (weak, nonatomic) IBOutlet UIButton *scanLabel;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UILabel *diskLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *collectionViewConstraint;
@property (weak, nonatomic) IBOutlet CircleUpView *backgroundView;


@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSArray *titleArray;
@property (nonatomic, strong) NSArray *colorArray;

@end

@implementation HomeController

#pragma mark - overwrite
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Data
    [self initData];
    
    //UI
    [self initUI];
    
//    //update data
//    [self updateInfo];
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self updateInfo];
}
- (void)updateBottom{
    if (@available(iOS 11.0, *)) {
        UIWindow *window = UIApplication.sharedApplication.keyWindow;
        self.collectionViewConstraint.constant = self.bView.frame.size.height + window.safeAreaInsets.bottom;
    }else{
        self.collectionViewConstraint.constant = self.bView.frame.size.height;
    }
}
#pragma mark - lazy
- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

#pragma mark - method
- (void)initData{
    self.titleArray = @[@"图片清理",@"视频清理",@"日历&提醒清理",@"通讯录清理",@"分类清理",@"设置"]; //,@"缓存知识"
    self.colorArray = @[RGBA_COLOR(84, 217, 172, 0.15),
                        RGBA_COLOR(123, 126, 246, 0.15),
                        RGBA_COLOR(76, 243, 179, 0.15),
                        RGBA_COLOR(31, 133, 251, 0.15),
                        RGBA_COLOR(33, 151, 216, 0.15),
                        RGBA_COLOR(105, 120, 243, 0.15),
                        ]; // RGBA_COLOR(165, 52, 220, 0.15),
}

- (void)initUI{
    //圆角
    
//    [self.backgroundView setBackgroundColor:[UIColor redColor]];
    
  
    //水波 进度 设置
    self.circleProcess.startColor = [UIColor yellowColor];
    self.circleProcess.endColor = [UIColor redColor];
    self.circleProcess.roundStyle = YES;
    self.circleProcess.showProgressText = NO;
    self.circleProcess.pathBackColor = [UIColor colorWithWhite:1.0 alpha:0.5];;
    self.circleProcess.delegate = self;

    //collectionView
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.backgroundColor = UIColorFromRGB(0xf1f1f1);
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([HomeTypeCell class]) bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:NSStringFromClass([HomeTypeCell class])];
}
- (void)updateInfo{
    //存储空间
    self.diskLabel.text = [NSString stringWithFormat:@"%@/%@",[DeviceInfo usedDiskSizeString],[DeviceInfo totalDiskSizeString]];
    self.circleProcess.progress = (float)[DeviceInfo usedDiskSize] / [DeviceInfo totalDiskSize];
//
//    self.diskLabel.text = @"34.6GB/121.1GB";
//    self.circleProcess.progress = 34.6 / 121.1;
}
- (IBAction)scanAction:(UIButton *)sender{
    //界面跳转
    AutoViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"AutoViewController"];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:nil];
}
//VIP Action
- (IBAction)vipAction:(UIButton *)sender {
    //VIP 跳转
    VIPController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VIPController"];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark - delegate
//collectionView
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.titleArray.count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    HomeTypeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([HomeTypeCell class]) forIndexPath:indexPath];
    cell.backgroundColor = self.colorArray[indexPath.row];
    cell.layer.cornerRadius = 10.0f;
    cell.layer.masksToBounds = YES;
    cell.info = self.titleArray[indexPath.row];
    return cell;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    //
    CGFloat w = ScreenWidth - 20 * 2; //除去边距
    CGFloat margin = 12;
    w = (w - margin * 2) / 3.0f;
    return CGSizeMake(w, w * 1.38);
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
   
    return UIEdgeInsetsMake(20, 20, 20, 20);
  
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.row) {
        case 0:{
            //图片
            ImageCleanController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ImageCleanController"];
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            vc.scanModel = YES;
            [self presentViewController:vc animated:YES completion:nil];
        }break;
        case 1:{
            //视频
            VideoCleanController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VideoCleanController"];
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            vc.scanModel = YES;
            [self presentViewController:vc animated:YES completion:nil];
        }break;
        case 2:{
            //日历&提醒
            OptimizeViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"OptimizeViewController"];
            
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            vc.scanModel = YES;
            vc.type = OptimizeCalendar;
            [self presentViewController:vc animated:YES completion:nil];
        }break;
        case 3:{
            //通讯录
            OptimizeViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"OptimizeViewController"];
            
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            vc.scanModel = YES;
            vc.type = OptimizeContact;
            [self presentViewController:vc animated:YES completion:nil];
        }break;
        case 4:{
            //手动
            CategoryViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"CategoryViewController"];
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            [self presentViewController:vc animated:YES completion:nil];
        }break;
        case 5:{
            //设置
            SettingController *vc =  [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SettingController"];
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            [self presentViewController:vc animated:YES completion:nil];
        }break;
            
        default:
            break;
    }
    
}
/// 进度条 进度改变
- (void)getCurrentProcess:(CGFloat)value{
   
    self.waveProgress.progress = value;
    self.processLabel.text = [NSString stringWithFormat:@"%.01f",value * 100];
}

@end
