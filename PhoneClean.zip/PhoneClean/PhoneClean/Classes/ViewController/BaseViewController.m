//
//  BaseViewController.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "BaseViewController.h"

@interface BaseViewController ()<GADBannerViewDelegate,GADFullScreenContentDelegate>
//page ads
@property(nonatomic, strong) GADInterstitialAd *interstitial;

@property (nonatomic,assign) CGFloat bannerHeight;
@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = UIColorFromRGB(0xf1f2f6);
    self.bannerHeight = 0;
    self.count = 0;
    //广告位置
    self.imageView = [[UIImageView alloc] init];
    self.imageView.image = [UIImage imageNamed:@"广告位"];
    [self.view addSubview:self.imageView];
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        make.bottom.mas_equalTo(self.view.mas_bottom);
        make.top.mas_equalTo(self.view.mas_bottom).mas_offset(0);
    }];
    
//    [self createAndLoadBanner];
}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    // Note loadBannerAd is called in viewDidAppear as this is the first time that
    // the safe area is known. If safe area is not a concern (e.g., your app is
    // locked in portrait mode), the banner can be loaded in viewWillAppear.
    [self createAndLoadBanner];
    if ([SandBoxHelper VIP]) { //VIP
        if (self.bView) {
            [self.bView setHidden:YES];
        }
    }else{
        [self.bView setHidden:NO];
    }
    
}

- (void)viewWillTransitionToSize:(CGSize)size
       withTransitionCoordinator:(id)coordinator {
     [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
     [coordinator animateAlongsideTransition:^(id
         _Nonnull context) {
           [self createAndLoadBanner];
     } completion:nil];
}

#pragma mark - 提醒
- (void)addTipWithTitle:(NSString *)title
                    tip:(NSString *)tip
                OKTitle:(NSString *)okTitle
              okHandler:(void (^ __nullable)(UIAlertAction *action))handler
            cancleTitle:(NSString *)cancleTitle
          cancleHandler:(void (^ __nullable)(UIAlertAction *action))cancleHandler{
    
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:tip preferredStyle:(UIAlertControllerStyleAlert)];
    
  
   
    if (cancleTitle.length > 0) {
        UIAlertAction *cancle = [UIAlertAction actionWithTitle:cancleTitle style:(UIAlertActionStyleDefault) handler:cancleHandler];
     
        [alert addAction:cancle];
    }
    if (okTitle.length > 0) {
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:okTitle style:(UIAlertActionStyleDefault) handler:handler]; [alert addAction:okAction];
    }
   
    
    [self presentViewController:alert animated:YES completion:nil];
    
}



#pragma mark - page ads
- (void)createAndLoadInterstitial{
    
    if ([SandBoxHelper VIP]) { //VIP 无广告
        return;
    }
    
    self.count += 1;
    
#if defined(DEBUG)||defined(_DEBUG)
    NSLog(@"谷歌广告Debug环境设置");
    GADMobileAds.sharedInstance.requestConfiguration.testDeviceIdentifiers = @[ kGADSimulatorID ];
#endif
    
    GADRequest *request = [GADRequest request];
    
    
#if defined(DEBUG)||defined(_DEBUG)
    [GADInterstitialAd loadWithAdUnitID:@"ca-app-pub-3940256099942544/4411468910"
                                request:request
                      completionHandler:^(GADInterstitialAd *ad, NSError *error) {
        if (error) {
            NSLog(@"Failed to load interstitial ad with error: %@", [error localizedDescription]);
            return;
        }
        self.interstitial = ad;
        self.interstitial.fullScreenContentDelegate = self;
    }];
#else
    [GADInterstitialAd loadWithAdUnitID:ID_AD_PAGE
                                request:request
                      completionHandler:^(GADInterstitialAd *ad, NSError *error) {
        if (error) {
            NSLog(@"Failed to load interstitial ad with error: %@", [error localizedDescription]);
            return;
        }
        self.interstitial = ad;
        self.interstitial.fullScreenContentDelegate = self;
    }];
#endif
    
}
- (BOOL)showInterstitial{
    
    if ([SandBoxHelper VIP]) {
        return YES;
    }
    
    if (self.interstitial) {
        [self.interstitial presentFromRootViewController:self];
        return YES;
    } else {
        [self createAndLoadInterstitial];
        return NO;
    }
}

#pragma mark - banner ads

- (GADBannerView *)bView{
    if (!_bView) {
        _bView = [[GADBannerView alloc]
                  initWithAdSize:kGADAdSizeBanner];
        _bView.adUnitID = ID_AD_BANNER;
        _bView.rootViewController = self;
        [_bView setDelegate:self];
        [self.view addSubview:_bView];
        [_bView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(self.view);
            if (@available(iOS 11.0, *)) {
                make.bottom.mas_equalTo(self.view.mas_safeAreaLayoutGuideBottom);
            } else {
                // Fallback on earlier versions
                make.bottom.mas_equalTo(self.view);
            }
        }];
        self.bannerHeight = kGADAdSizeBanner.size.height;
    }
    return _bView;
}

- (void)updateBottom{
    
}
- (void)createAndLoadBanner{
    
    if ([SandBoxHelper VIP]) { //VIP 无广告
        return;
    }
    
    
    
    GADRequest *request = [GADRequest request];
#if defined(DEBUG)||defined(_DEBUG)
    NSLog(@"测试环境使用");
    
    self.bView.adUnitID = @"ca-app-pub-3940256099942544/2934735716";
    GADMobileAds.sharedInstance.requestConfiguration.testDeviceIdentifiers = @[kGADSimulatorID];
#endif
    [self.bView loadRequest:request];
}

- (CGFloat)bottomSafeHeight{
    
    CGFloat height = 0;
    if (@available(iOS 11.0, *)) {
        CGFloat safeHeight = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom;
        height += safeHeight;
    }
    return height;;
}



#pragma mark - GADBannerViewDelegate

- (void)bannerViewDidReceiveAd:(GADBannerView *)bannerView {
    NSLog(@"bannerViewDidReceiveAd");
    self.bannerHeight = kGADAdSizeBanner.size.height;
    [self.bView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(self.view);
        if (@available(iOS 11.0, *)) {
            make.bottom.mas_equalTo(self.view.mas_safeAreaLayoutGuideBottom);
        } else {
            // Fallback on earlier versions
            make.bottom.mas_equalTo(self.view);
        }
        make.height.mas_equalTo(self.bannerHeight);
    }];
    
    [self.imageView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(_bView);
    }];
    [self updateBottom];
}

- (void)bannerView:(GADBannerView *)bannerView didFailToReceiveAdWithError:(NSError *)error {
    NSLog(@"bannerView:didFailToReceiveAdWithError: %@", [error localizedDescription]);
}

- (void)bannerViewDidRecordImpression:(GADBannerView *)bannerView {
    NSLog(@"bannerViewDidRecordImpression");
}

- (void)bannerViewWillPresentScreen:(GADBannerView *)bannerView {
    NSLog(@"bannerViewWillPresentScreen");
}

- (void)bannerViewWillDismissScreen:(GADBannerView *)bannerView {
    NSLog(@"bannerViewWillDismissScreen");
}

- (void)bannerViewDidDismissScreen:(GADBannerView *)bannerView {
    NSLog(@"bannerViewDidDismissScreen");
}

#pragma mark - GADInterstitialAdDelegate
/// Tells the delegate that the ad failed to present full screen content.
- (void)ad:(nonnull id<GADFullScreenPresentingAd>)ad
didFailToPresentFullScreenContentWithError:(nonnull NSError *)error {
    NSLog(@"Ad did fail to present full screen content.");
}

/// Tells the delegate that the ad presented full screen content.
- (void)adDidPresentFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"Ad did present full screen content.");
}

/// Tells the delegate that the ad dismissed full screen content.
- (void)adDidDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad {
    NSLog(@"Ad did dismiss full screen content.");
    self.count = 0;
    //拉取新的广告
    [self createAndLoadInterstitial];
    [self endInterstitial];
}


- (UIStatusBarStyle)preferredStatusBarStyle {
   return UIStatusBarStyleLightContent;
   // return UIStatusBarStyleDefault;
}
@end
