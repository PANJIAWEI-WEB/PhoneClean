//
//  HomeController.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HomeController : BaseViewController

@end

NS_ASSUME_NONNULL_END
