//
//  AutoViewController.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "AutoViewController.h"
#import "AutoCleanCell.h"
#import "AutoModel.h"
#import "EventHelper.h"
#import "ContactHelper.h"
#import "ImageUtils.h"
#import "VideoUtils.h"
#import "ImageCleanController.h"
#import "VideoCleanController.h"
#import "OptimizeViewController.h"
#import "ScanWaiteView.h"
@interface AutoViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@property (weak, nonatomic) IBOutlet UILabel *dwLabel;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *cleanButton;
@property (weak, nonatomic) IBOutlet UIView *infoBackView;
@property (weak, nonatomic) IBOutlet UIView *scanBackView;
@property (weak, nonatomic) IBOutlet UILabel *processLabel;
@property (strong, nonatomic)  ScanWaiteView *scanWaiteView;
@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, assign) BOOL endScan;
@end

@implementation AutoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self createAndLoadInterstitial];
    [self initData];
    [self initUI];
    
    [self scanAction];
}
#pragma mark - lazy
- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (ScanWaiteView *)scanWaiteView{
    if (!_scanWaiteView) {
        _scanWaiteView = [[ScanWaiteView alloc] init];
        _scanWaiteView.layer.masksToBounds = YES;
        _scanWaiteView.layer.cornerRadius = 60;
        _scanWaiteView.layer.borderColor = [UIColor whiteColor].CGColor;
        _scanWaiteView.layer.borderWidth = 0.0f;
    }
    return _scanWaiteView;
}
#pragma mark - method
- (void)initData{
    NSArray *array = @[@"图片清理",@"视频清理",@"日历&提醒清理",@"通讯录清理"];
    [self.dataArray removeAllObjects];
    for (NSString *str in array) {
        AutoModel *model = [[AutoModel alloc] init];
        model.title = str;
        model.total = 0;
        model.process = 0;
        model.selected = YES;
        [self.dataArray addObject:model];
    }
}
- (void)initUI{
    self.tableView.tableFooterView = [UIView new];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([AutoCleanCell class]) bundle:[NSBundle mainBundle]] forCellReuseIdentifier:NSStringFromClass([AutoCleanCell class])];
    self.tableView.estimatedRowHeight = 200.0f;
    
    
    [self.scanBackView addSubview:self.scanWaiteView];
    [self.scanWaiteView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(self.scanBackView);
        make.width.height.mas_equalTo(120);
    }];
}
- (IBAction)backAction:(UIButton *)sender {
  
    if (self.backBlock) {
        self.backBlock();
    }
    
    if (self.endScan) {
        [self dismissViewControllerAnimated:YES completion:^{
                
        }];
    }else{
        WeakSelf(weakSelf)
        [self addTipWithTitle:@"Tip" tip:@"您想终止扫描进程并退出吗？" OKTitle:@"确定" okHandler:^(UIAlertAction * _Nonnull action) {
            StrongSelf(strongSelf)
            dispatch_async(dispatch_get_main_queue(), ^{;
                [[ImageUtils shareManager] stopLoadPhoto];
                [[VideoUtils shareManager] stopLoadPhoto];
                [[ContactHelper shareManager] stopLoadPhoto];
                
                
                [strongSelf dismissViewControllerAnimated:YES completion:^{
                        
                }];
            });
            
            
        } cancleTitle:@"继续扫描" cancleHandler:^(UIAlertAction * _Nonnull action) {
            
        }];
    }
    
    
    
}


- (void)scanAction{
    
    
    self.processLabel.text = @"扫描中…";
    [self.cleanButton setHidden:YES];
    //扫描图形
    [self.scanBackView setHidden:NO];
    [self.infoBackView setHidden:YES];
    [self.scanWaiteView startAnim];
    dispatch_queue_t myqueue = dispatch_queue_create("com.queue.scan", DISPATCH_QUEUE_CONCURRENT); //并发
    
    WeakSelf(weakSelf)
    dispatch_async(myqueue, ^{
        [weakSelf imageScan];
    });
    dispatch_async(myqueue, ^{
        [weakSelf videoScan];
    });
    dispatch_async(myqueue, ^{
        [weakSelf contactScan];
    });
    dispatch_async(myqueue, ^{
        [weakSelf eventScan];
    });
}

//几个扫描
- (void)eventScan{
    WeakSelf(weakSelf)
    [[EventHelper shareManager] loadContactWithProcess:^(NSInteger current, NSInteger total, NSString * _Nonnull currentName) {
       //扫描进度
//        NSLog(@"%zd --- %zd",current,total);
    } completionHandler:^(BOOL success, NSError * _Nonnull error) {
        ((AutoModel*)weakSelf.dataArray[2]).process = 1.0;
        NSLog(@"总条数：%zd",[EventHelper shareManager].totalSaveSpace);
        ((AutoModel*)weakSelf.dataArray[2]).total = [EventHelper shareManager].totalSaveSpace;
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf checkScanStatus];
            [strongSelf.tableView reloadData];
        });
    }];
}

- (void)contactScan{
    
    WeakSelf(weakSelf)
    [[ContactHelper shareManager] loadContactWithProcess:^(NSInteger current, NSInteger total, NSString * _Nonnull currentName) {
           //扫描进度
//            NSLog(@"%zd --- %zd",current,total);
    } completionHandler:^(BOOL success, NSError * _Nonnull error) {
        ((AutoModel*)weakSelf.dataArray[3]).process = 1.0;
        ((AutoModel*)weakSelf.dataArray[3]).total = [ContactHelper shareManager].totalSaveSpace;
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf checkScanStatus];
            [strongSelf.tableView reloadData];
        });
    }];
}


- (void)videoScan{
    WeakSelf(weakSelf)
    [[VideoUtils shareManager] loadVideoWithProcess:^(NSInteger current, NSInteger total, NSString * _Nonnull currentName) {
        //扫描进度
//         NSLog(@"%zd --- %zd",current,total);
    } completionHandler:^(BOOL success, NSError * _Nonnull error) {
        ((AutoModel*)weakSelf.dataArray[1]).process = 1.0;
        ((AutoModel*)weakSelf.dataArray[1]).total = [VideoUtils shareManager].totalSaveSpace;
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf checkScanStatus];
            [strongSelf.tableView reloadData];
        });
    }];
    
    
}
- (void)imageScan{
    //图片
    WeakSelf(weakSelf)
    [[ImageUtils shareManager] loadPhotoWithProcess:^(NSInteger current, NSInteger total, NSString *name) {
        //扫描进度
//         NSLog(@"%zd --- %zd",current,total);
    } completionHandler:^(BOOL success, NSError * _Nonnull error) {
        
        ((AutoModel*)weakSelf.dataArray[0]).process = 1.0;
        ((AutoModel*)weakSelf.dataArray[0]).total = [ImageUtils shareManager].totalSaveSpace;
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [weakSelf checkScanStatus];
            [strongSelf.tableView reloadData];
        });
    }];
}
- (IBAction)cleanAction:(id)sender {
    
    if ([SandBoxHelper VIP]) {
        [self endInterstitial];
    }else{
//        [self endInterstitial];
        if (![self showInterstitial]) {
            [[[UIApplication sharedApplication] keyWindow] makeToast:@"未拉取到广告" duration:3.0f position:@"bottom"];
            //未获取到page ads
            
            if (self.count == 2) {
                [self endInterstitial];
            }
        }
    }
}
- (void)endInterstitial{
    //显示清理中……
    NSMutableArray *delArray = [NSMutableArray array];
    if ([ImageUtils shareManager].clean) {
        [delArray addObjectsFromArray:[[ImageUtils shareManager] cleanArray]];
    }
    if ([VideoUtils shareManager].clean) {
        [delArray addObjectsFromArray:[[VideoUtils shareManager] cleanArray]];
    }
    
    WeakSelf(weakSelf)
    //清理视频，图片
    [[ImageUtils shareManager] cleanAll:delArray completion:^(BOOL success, NSUInteger size) {
            
        //开始清理 通讯录
        [[ContactHelper shareManager] cleanAction:^(BOOL success, NSError * _Nonnull error) {
            
        }];
        //清理提醒事项
        [[EventHelper shareManager] cleanAction:^(BOOL success, NSInteger count) {
                        
        }];
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf finishClean];
            
        });
    }];
}
- (void)finishClean{
    
    [self showInfo];
    
}
- (void)showInfo{
    
    NSInteger count = ((AutoModel *)self.dataArray[2]).total +((AutoModel *)self.dataArray[3]).total;
    [self initData];
    //清理完成
    WeakSelf(weakSelf)
    [self addTipWithTitle:@"清理结果" tip:[NSString stringWithFormat:@"智能清理完成，共计释放%@%@，清理%zd条数据",self.numberLabel.text,self.dwLabel.text ,count] OKTitle:nil okHandler:^(UIAlertAction * _Nonnull action) {
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf scanAction];
            [strongSelf.tableView reloadData];
        });
        
    } cancleTitle:@"返回上一级" cancleHandler:^(UIAlertAction * _Nonnull action) {
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf backAction:strongSelf.cleanButton];
        });
    }];
}

//更新界面 ，扫描完成
- (void)checkScanStatus{
    
    
    
    BOOL finish = YES;
    for (AutoModel *model in self.dataArray) {
        if (model.process != 1.0f) {
            finish = NO;
            break;
        }
    }
    if (finish) {
        //更新标题
        [self.cleanButton setTitle:@"立即清理" forState:(UIControlStateNormal)];
        self.endScan = YES;
        [self.cleanButton setHidden:NO];
        [self.scanBackView setHidden:YES];
        [self.infoBackView setHidden:NO];
        
        
        //计算数据，
        NSInteger count = 0;
        NSInteger size = 0;
        for (NSInteger i = 0; i < self.dataArray.count; i ++) {
            AutoModel *model = self.dataArray[i];
            if (i < 2) {
                size += model.total;
            }else{
                count += model.total;
            }
        }
       
        [self updateInfo:size];
        
    }
    
}


- (void)updateInfo:(NSUInteger)size{
    
    //文件大小
    NSString *fileSize = @"0";
    NSString *units = @"KB";
    
    NSInteger KB = M_KB;
    NSInteger MB = M_MB;
    NSInteger GB = MB*KB;
    if (size < 10)
    {
        fileSize =  @"0";
        units = @"KB";
        
    }else if (size < MB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/KB];
        units = @"KB";
    }else if (size < GB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/MB];
        units = @"MB";
        
    }else
    {
        fileSize = [NSString stringWithFormat:@"%.2f",((CGFloat)size)/GB];
        units = @"GB";
    }
    
    self.numberLabel.text = fileSize;
    self.dwLabel.text = units;
    
}

///MARK: 界面跳转
- (void)turnShowImage{
    ImageCleanController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ImageCleanController"];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    vc.scanModel = NO;
    WeakSelf(weakSelf)
    [vc setBackBlock:^{
        ((AutoModel*)weakSelf.dataArray[0]).total = [ImageUtils shareManager].totalSaveSpace;
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf checkScanStatus];
            [strongSelf.tableView reloadData];
        });
    }];
    [self presentViewController:vc animated:YES completion:nil];
}
- (void)turnVideo{
    VideoCleanController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VideoCleanController"];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    vc.scanModel = NO;
    WeakSelf(weakSelf)
    [vc setBackBlock:^{
        ((AutoModel*)weakSelf.dataArray[1]).total = [VideoUtils shareManager].totalSaveSpace;
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf checkScanStatus];
            [strongSelf.tableView reloadData];
        });
    }];
    [self presentViewController:vc animated:YES completion:nil];
}
- (void)turnCalendar:(BOOL)canlendar{
    OptimizeViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"OptimizeViewController"];
    
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    vc.scanModel = NO;
    if (canlendar) {
        vc.type = OptimizeCalendar;
    }else{
        vc.type = OptimizeContact;
    }
    WeakSelf(weakSelf)
    [vc setBackBlock:^{
        if (canlendar) {
            ((AutoModel*)weakSelf.dataArray[2]).total = [EventHelper shareManager].totalSaveSpace;
        }else{
            ((AutoModel*)weakSelf.dataArray[3]).total = [ContactHelper shareManager].totalSaveSpace;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf checkScanStatus];
            [strongSelf.tableView reloadData];
        });
    }];
    
    
    [self presentViewController:vc animated:YES completion:nil];
}
#pragma mark - delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    AutoCleanCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([AutoCleanCell class]) forIndexPath:indexPath];
    
    cell.index = indexPath.row;
    cell.model = self.dataArray[indexPath.row];
    if (cell.model.process != 0) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    AutoModel *model = self.dataArray[indexPath.row];
    if (model.process == 1.0) {
        //扫描结束才能展示
        //界面跳转
        switch (indexPath.row) {
            case 0:
                [self turnShowImage];
                break;
            case 1:
                [self turnVideo];
                break;
            case 2:
                [self turnCalendar:YES];
                break;
            case 3:
                [self turnCalendar:NO];
                break;
                
            default:
                break;
        }
        
    }
}
@end
