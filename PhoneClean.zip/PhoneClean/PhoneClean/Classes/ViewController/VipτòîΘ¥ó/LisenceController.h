//
//  LisenceController.h
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LisenceController : UIViewController

@property (nonatomic,assign)NSInteger type;

@end

NS_ASSUME_NONNULL_END
