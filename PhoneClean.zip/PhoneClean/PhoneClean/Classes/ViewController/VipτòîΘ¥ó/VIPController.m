//
//  VIPController.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "VIPController.h"
#import <StoreKit/StoreKit.h>
#import <AFNetworking/AFNetworking.h>
#import "IAPManager.h"
#import "LisenceController.h"

@interface VIPController ()<IApRequestResultsDelegate>

@property (weak, nonatomic) IBOutlet UIButton *restoreBtn;
@property (weak, nonatomic) IBOutlet UIView *selectView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topConstraint;

@property (nonatomic,assign)NSInteger type;

@end

@implementation VIPController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.type = 1;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.restoreBtn.layer.masksToBounds = YES;
    self.restoreBtn.layer.cornerRadius = 13.f;
    
    [IAPManager shared].delegate = self;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(success) name:@"BuySuccess" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(faild) name:@"BuyFaild" object:nil];
    
    //折扣字体
    for (int i = 1; i < 4; i ++) {
        UILabel *label = [[self.selectView viewWithTag:i * 100] viewWithTag:i * 100 + 4];
        NSMutableAttributedString *attritu = [[NSMutableAttributedString alloc]initWithString:label.text];
        [attritu addAttributes:@{
            NSStrikethroughStyleAttributeName:@(NSUnderlineStyleThick),
            NSForegroundColorAttributeName:
                [UIColor lightGrayColor],
            NSBaselineOffsetAttributeName:
                @(0),
            NSFontAttributeName: label.font
        } range:NSMakeRange(0, label.text.length)];
        [label setAttributedText:attritu];
    }
    
    if (@available(iOS 11.0, *)) {
        self.topConstraint.constant = - UIApplication.sharedApplication.keyWindow.safeAreaInsets.top;
    }
}
- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)success{
    [self dismissViewControllerAnimated:YES completion:^{
        [SVProgressHUD showSuccessWithStatus:@"购买成功"];
        [SVProgressHUD dismissWithDelay:1];
    }];
}

- (void)faild{
    [SVProgressHUD showErrorWithStatus:@"购买失败"];
    [SVProgressHUD dismissWithDelay:1];
}
- (IBAction)cancelAction:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)getOrderAction:(id)sender {
    [SVProgressHUD showWithStatus:@"正在恢复您的购买记录"];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
    [[IAPManager shared] refreshOrder];
}
- (IBAction)useLisence:(id)sender {
    LisenceController *vc = [[LisenceController alloc] init];
    vc.type = 0;
    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)privatLisence:(id)sender {
    LisenceController *vc = [[LisenceController alloc] init];
    vc.type = 1;
    [self presentViewController:vc animated:YES completion:nil];
}
- (void)chooseMonth{
    self.type = 0;
}

- (void)chooseYear{
    self.type = 1;
}
//月 季 年 选择
- (IBAction)vipAction:(UIButton *)sender {
    self.type = sender.tag / 100;
    
    for (int i = 1 ; i < 4; i ++) { //月 季 年
        
        BOOL selected = NO;
        if (self.type == i) {
            selected = YES;
        }
        
        
        UIColor *color0 = UIColorFromRGB(0x737373);
        UIColor *color1 = UIColorFromRGB(0x555555);
        
        if (selected) {
            color0 = [UIColor whiteColor];
            color1 = [UIColor whiteColor];
            [((UIButton *) [[self.selectView viewWithTag:i * 100] viewWithTag:i * 100 + 5]) setImage:[UIImage imageNamed:@"vipSelected"] forState:(UIControlStateNormal)];
        }else{
            [((UIButton *) [[self.selectView viewWithTag:i * 100] viewWithTag:i * 100 + 5]) setImage:[UIImage imageNamed:@"vipCustom"] forState:(UIControlStateNormal)];
        }
        
        ((UILabel *) [[self.selectView viewWithTag:i * 100] viewWithTag:i * 100 + 1]).textColor  = color0;
        ((UILabel *) [[self.selectView viewWithTag:i * 100] viewWithTag:i * 100 + 2]).textColor  = color1;
        ((UILabel *) [[self.selectView viewWithTag:i * 100] viewWithTag:i * 100 + 3]).textColor  = color1;
        
    
    }
    
    
    
}

#pragma mark IApRequestResultsDelegate
- (void)onceProductPaySuccess:(BOOL)success{
    if(success){
        //单次购买成功
        [self success];
        
        
    }else{
        //单次购买失败
        [self faild];
        
        
    }
}

- (void)filedWithErrorCode:(NSInteger)errorCode andError:(NSString *)error {
    [SVProgressHUD dismiss];
    switch (errorCode) {
        case IAP_FILEDCOED_APPLECODE:
            NSLog(@"用户禁止应用内付费购买:%@",error);
            break;

        case IAP_FILEDCOED_NORIGHT:
            NSLog(@"用户禁止应用内付费购买");
            break;

        case IAP_FILEDCOED_EMPTYGOODS:
            NSLog(@"商品为空");
            break;

        case IAP_FILEDCOED_CANNOTGETINFORMATION:
            NSLog(@"无法获取产品信息，请重试");
            break;

        case IAP_FILEDCOED_BUYFILED:
            NSLog(@"购买失败，请重试");
            [SVProgressHUD showErrorWithStatus:@"购买失败，请重试"];
            break;

        case IAP_FILEDCOED_USERCANCEL:
            NSLog(@"用户取消交易");
            break;

        default:
            break;
    }
}



#pragma mark - IAP支付流程

- (IBAction)buyAction:(id)sender {
    [self buyAction];
}
- (void)buyAction{


    //查询用户是否允许应用内付费
    if ([SKPaymentQueue canMakePayments]) {
        NSLog(@"允许程序内付费购买");
        [SVProgressHUD showWithStatus:@"正在购买..."];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
        [self requestProductData];
    }
    else
    {
        NSLog(@"不允许程序内付费购买");

        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"您的设备没有打开程序内付费购买" preferredStyle:(UIAlertControllerStyleAlert)];
        [alertController addAction:[UIAlertAction actionWithTitle:@"关闭" style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {

        }]];
        [self presentViewController:alertController animated:YES completion:^{

        }];


    }
}

//请求单次商品
- (void)requestOnceProductData{
    [SVProgressHUD showWithStatus:@"正在购买..."];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
//    [[IAPManager shared] requestOnceProductWithId:vip_once];
}

// 请求商品信息
- (void)requestProductData{
    NSLog(@"---------请求对应的产品信息------------");
    NSArray *product = nil;
    if (self.type == 1) { //周卡
        [[IAPManager shared] requestProductWithId:vip_week];
        
    }else if (self.type == 2) {//月卡
        [[IAPManager shared] requestProductWithId:vip_month];
        
    }else if (self.type == 3) {//年卡
        [[IAPManager shared] requestProductWithId:vip_quarter];

    }


}
- (UIStatusBarStyle)preferredStatusBarStyle {
   return UIStatusBarStyleLightContent;
   // return UIStatusBarStyleDefault;
}
@end
