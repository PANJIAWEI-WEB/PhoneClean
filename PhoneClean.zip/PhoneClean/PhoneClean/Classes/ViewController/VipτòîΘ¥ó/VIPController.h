//
//  VIPController.h
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
//typedef NS_ENUM(NSUInteger, <#MyEnum#>) {
//    <#MyEnumValueA#>,
//    <#MyEnumValueB#>,
//    <#MyEnumValueC#>,
//};
@interface VIPController : UIViewController

@end

NS_ASSUME_NONNULL_END
