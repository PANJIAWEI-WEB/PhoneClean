//
//  LisenceController.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "LisenceController.h"

@interface LisenceController ()

@property (nonatomic,strong)UITextView *mainLabel;

@end

@implementation LisenceController

- (void)back{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(20, 30, 30, 30)];
    [button setImage:[UIImage imageNamed:@"backImg"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
    
    UILabel *label = [[UILabel alloc] init];
    [self.view addSubview:label];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor whiteColor];
    label.backgroundColor = [UIColor clearColor];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.view);
            make.left.right.mas_equalTo(self.view);
            make.centerY.mas_equalTo(button);
    }];
    if (self.type == 0) {
        label.text = @"使用条款";
    }else{
        label.text = @"隐私政策";
    }
    
    
    
    self.view.backgroundColor = RGB_COLOR(26, 199, 108);
    self.mainLabel = [[UITextView alloc] initWithFrame:CGRectMake(20, 70, [UIScreen mainScreen].bounds.size.width-40, CGRectGetHeight(self.view.bounds)-120)];
    self.mainLabel.textColor = [UIColor whiteColor];
    self.mainLabel.backgroundColor = [UIColor clearColor];
    self.mainLabel.editable = NO;
    self.mainLabel.showsVerticalScrollIndicator = NO;
    self.mainLabel.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.mainLabel];
    
    
    if (self.type == 0) {
        self.mainLabel.text = @"1.印章助手会员享有哪些功能\n印章助手会员目前包含高级付费项有：\n 可自定义上传背景\n 保存次数没有限制\n 产品内纯净无广告\n2.如何成为印章助手会员\n直接订阅印章助手会员包即可成为印章助手会员\n3.已购买印章助手会员无法使用高级功能\n当您成功订阅VIP会员，如出现无法使用付费功能的情况，请先确认登录的苹果账号无误，并在「设置」的「会员页面」中点击「恢复购买」；或卸载印章助手，前往 App Store 重新登陆购买账户，下载印章助手，再进行「恢复购买」操作\n4.如何取消订阅成为印章助手会员\n用户有权利选择不继续接受会员服务，如您需取消订阅，请查看以下链接，或联络苹果客服（400-666-8800）：https://support.apple.com/zh-cn/HT202039 ，此取消行为将无法获得已交纳的会员服务费的退还或其他任何形式的补偿/赔偿";
    }else{
        self.mainLabel.text = @"印章助手手机客户端软件最终用户使用授权协议如下\n本最终用户软件授权协议（以下简称“协议”）是由您，作为最终用户，与印章助手手机客户端软件共同签订\n1. 用户个人隐私信息保护\n1.1.适用范围\n在您使用本软件网络服务，本软件自动接收并记录的您的手机上的信息，包括但不限于您的健康数据、使用的语言、访问日期和时间、软硬件特征信息及您需求的网页记录等数据\n1.2.信息的使用\n在获得您的数据之后，本软件会将其上传至服务器，以生成您的数据统计，以便您能够更好地使用服务\n1.3.信息披露\na) 本软件不会将您的信息披露给不受信任的第三方\nb) 根据法律的有关规定，或者行政或司法机构的要求，向第三方或者行政、司法机构披露\nc) 如您出现违反中国有关法律、法规或者相关规则的情况，需要向第三方披露\n2. 知识产权保护\n本软件受中华人民共和国著作权法及国际著作权条约、知识产权法、国际版权法及条约的保护，其所有知识产权归印章助手所有。除非本协议另有明确规定，否则本协议不向您提供任何有关该软件的知识产权。该软件的所有标题和版权，包括但不限于其操作、代码、结构和执行、外观、屏幕显示结果、任何图象、照片、动画、录像、录音、音乐、文字和附加程序、随附的帮助材料、及本软件产品的任何副本，均属印章助手的知识财产。印章助手保留所有在本协议中未明确授让的权利。用户不得对本软件产品进行反向工程（reverse engineer）、反向编译（decompile）或反汇编（disassemble），违者属于侵权行为，将可能受到来自印章助手的法律追究，行为人并应当自行承担由此产生的不利后果\n3. 软件认定\n本软件产品可以通过网络等途径下载、传播，iOS版本，均会通过官方正规商店渠道向用户提供下载，对于从非印章助手指定站点下载的本软件产品以及从非印章助手发行的介质上获得的本软件产品，印章助手无法保证该软件的完整性、安全性和有效性，不承担由此引起的直接和间接损害责任\n4. 功能升级\n印章助手保证本软件的升级模块中也不含有任何旨在破坏用户计算机数据和获取用户隐私信息的恶意代码，不含有任何跟踪、监视用户计算机和或操作行为的功能代码，不会监控用户网上、网下的行为或泄漏用户隐私\n5. 使用规则\n遵守中华人民共和国相关法律法规，包括但不限于《中华人民共和国计算机信息系统安全保护条例》、《计算机软件保护条例》、《最高人民法院关于审理涉及计算机网络著作权纠纷案件适用法律若干问题的解释(法释󞪄]1号)》、《全国人大常委会关于维护互联网安全的决定》、《互联网电子公告服务管理规定》、《互联网新闻信息服务管理规定》、《互联网著作权行政保护办法》、《信息网络传播权保护条例》和《互联网用户账号名称管理规定》等有关计算机互联网规定和知识产权的法律和法规、实施办法\n6. 用户发布内容规范\n用户对其自行发表、上传或传送的内容负全部责任，所有用户不得通过本软件发布含有下列内容之一的信息，否则本软件有权自行处理并不通知用户：\n(1)违反宪法确定的基本原则的；\n(2)危害国家安全，泄漏国家机密，颠覆国家政权，破坏国家统一的；\n(3)损害国家荣誉和利益的；\n(4)煽动民族仇恨、民族歧视，破坏民族团结的；\n(5)破坏国家宗教政策，宣扬邪教和封建迷信的；\n(6)散布谣言，扰乱社会秩序，破坏社会稳定的；\n(7)散布淫秽、色情、赌博、暴力、恐怖或者教唆犯罪的；\n(8)侮辱或者诽谤他人，侵害他人合法权益的；\n(9)煽动非法集会、结社、游行、示威、聚众扰乱社会秩序的；\n(10)以非法民间组织名义活动的；\n(11)含有法律、法规、规章、地方规范性文件、国家政策、政府通知、公序良俗等禁止的内容；\n(12)本软件认为不利于软件内的社区生态、可能给本软件造成损失的内容。\n7. 自愿性软件和卸载权\n本软件为自愿性质的软件，您可以在任何时候来卸载本软件，因删除产生的一切后果由用户承担\n8. 终止\n如果您违反了本协议，则您使用本软件的授权将被终止。终止后，您必须将本软件的拷贝及所有相关文档销毁\n9. 争议解决\n双方一致同意本协议的内容及效力，双方一致同意由于执行本协议而产生的一切纠纷适用中华人民共和国法律，并由印章助手所在地法院管辖";
    }
}
- (UIStatusBarStyle)preferredStatusBarStyle {
   return UIStatusBarStyleLightContent;
   // return UIStatusBarStyleDefault;
}
@end
