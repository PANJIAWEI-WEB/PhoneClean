//
//  StartVIPController.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "StartVIPController.h"
#import "HomeController.h"
#import "LisenceController.h"
#import "IAPManager.h"
@interface StartVIPController ()<UITextViewDelegate,IApRequestResultsDelegate>

@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (nonatomic, assign) BOOL buyValue;
@end

@implementation StartVIPController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.buyValue = NO;
    self.button.layer.cornerRadius = 10;
    self.button.layer.masksToBounds = YES;
    if(![[NSUserDefaults standardUserDefaults] valueForKey:@"NotFirstIn"]){
        [[NSUserDefaults standardUserDefaults] setValue:@"NotFirstIn" forKey:@"NotFirstIn"];
    }
    //富文本
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc]initWithString:self.textView.text];
    [attributedString addAttribute:NSLinkAttributeName value:@"shiyongtiaokuan://"
                             range:[[attributedString string]rangeOfString:@"使用条款"]];

    [attributedString addAttribute:NSLinkAttributeName
                             value:@"yisizhengce://"
                             range:[[attributedString string]rangeOfString:@"隐私政策"]];
    [attributedString addAttribute:NSLinkAttributeName
                             value:@"huifugoumai://"
                             range:[[attributedString string]rangeOfString:@"恢复购买"]];

    [attributedString addAttribute:NSForegroundColorAttributeName value:UIColorFromRGB(0x999999) range:NSMakeRange(0,self.textView.text.length)];
    //文字颜色
    self.textView.linkTextAttributes = @{NSForegroundColorAttributeName:RGB_COLOR(26, 199, 108)};

    self.textView.delegate=self;

    self.textView.attributedText = attributedString;
    
    
    
    [IAPManager shared].delegate = self;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(success) name:@"BuySuccess" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(faild) name:@"BuyFaild" object:nil];
}
- (IBAction)closeAction:(UIButton *)sender {
    
    HomeController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"HomeController"];
    
    AppDelegate *delegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.window setRootViewController:vc];
    
}
- (IBAction)goOnAction:(id)sender {
    
    self.buyValue = YES;
    [self buyAction];
}
- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)success{
    if (!self.buyValue) {
        [self closeAction:nil];
        return;
    }
    [self dismissViewControllerAnimated:YES completion:^{
        [SVProgressHUD showSuccessWithStatus:@"购买成功"];
        [SVProgressHUD dismissWithDelay:1];
    }];
    [self closeAction:nil];
}

- (void)faild{
    
    if (!self.buyValue) {
        return;
    }
    
    [SVProgressHUD showErrorWithStatus:@"购买失败"];
    [SVProgressHUD dismissWithDelay:1];
    
    [self closeAction:nil];
}
#pragma mark IApRequestResultsDelegate
- (void)onceProductPaySuccess:(BOOL)success{
    if(success){
        //单次购买成功
        [self success];
    }else{
        //单次购买失败
        [self faild];
    }
}

- (void)filedWithErrorCode:(NSInteger)errorCode andError:(NSString *)error {
    [SVProgressHUD dismiss];
    switch (errorCode) {
        case IAP_FILEDCOED_APPLECODE:
            NSLog(@"用户禁止应用内付费购买:%@",error);
            break;

        case IAP_FILEDCOED_NORIGHT:
            NSLog(@"用户禁止应用内付费购买");
            break;

        case IAP_FILEDCOED_EMPTYGOODS:
            NSLog(@"商品为空");
            break;

        case IAP_FILEDCOED_CANNOTGETINFORMATION:
            NSLog(@"无法获取产品信息，请重试");
            break;

        case IAP_FILEDCOED_BUYFILED:
            NSLog(@"购买失败，请重试");
            [SVProgressHUD showErrorWithStatus:@"购买失败，请重试"];
            break;

        case IAP_FILEDCOED_USERCANCEL:
            NSLog(@"用户取消交易");
            break;

        default:
            break;
    }
}



#pragma mark - IAP支付流程
- (void)buyAction{


    //查询用户是否允许应用内付费
    if ([SKPaymentQueue canMakePayments]) {
        NSLog(@"允许程序内付费购买");
        [SVProgressHUD showWithStatus:@"正在购买..."];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
        [self requestProductData];
    }
    else
    {
        NSLog(@"不允许程序内付费购买");

        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"您的设备没有打开程序内付费购买" preferredStyle:(UIAlertControllerStyleAlert)];
        [alertController addAction:[UIAlertAction actionWithTitle:@"关闭" style:(UIAlertActionStyleCancel) handler:^(UIAlertAction * _Nonnull action) {

        }]];
        [self presentViewController:alertController animated:YES completion:^{

        }];


    }
}

//请求单次商品
- (void)requestOnceProductData{
    [SVProgressHUD showWithStatus:@""];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
//    [[IAPManager shared] requestOnceProductWithId:vip_once];
}

// 请求商品信息
- (void)requestProductData{
    NSLog(@"---------请求对应的产品信息------------");
    [[IAPManager shared] requestProductWithId:vip_quarter];
}

#pragma mark  - delegate
- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange interaction:(UITextItemInteraction)interaction{
    if ([[URL scheme] isEqualToString:@"shiyongtiaokuan"]) {
        NSLog(@"富文本点击 使用条款");
        LisenceController *vc = [[LisenceController alloc] init];
        vc.type = 0;
        vc.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:vc animated:YES completion:nil];
        return NO;
    }else if ([[URL scheme] isEqualToString:@"yisizhengce"]) {
        NSLog(@"富文本点击 隐私政策");
        
        LisenceController *vc = [[LisenceController alloc] init];
        vc.type = 1;
        vc.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:vc animated:YES completion:nil];
        return NO;
    }else if ([[URL scheme] isEqualToString:@"huifugoumai"]) {
        NSLog(@"富文本点击 恢复购买");
        [SVProgressHUD showWithStatus:@"正在恢复您的购买记录"];
        [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
        [[IAPManager shared] refreshOrder];
        return NO;
    }
    return YES;
}
- (UIStatusBarStyle)preferredStatusBarStyle {
   return UIStatusBarStyleLightContent;
   // return UIStatusBarStyleDefault;
}
@end
