//
//  SettingController.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "SettingController.h"
#import "SectionView.h"
#import <StoreKit/StoreKit.h>
#import "SettingCell.h"
#import "ConfigCell.h"
#import <MessageUI/MessageUI.h>

@interface SettingController ()<UITableViewDelegate,UITableViewDataSource,MFMailComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSMutableArray *dataArray;
@property (strong, nonatomic) NSMutableArray *titleArray;

@end

@implementation SettingController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    [self initData];
    [self initUI];
}

-(NSMutableArray *)titleArray{
    if (!_titleArray) {
        _titleArray = [NSMutableArray array];
    }
    return _titleArray;
}
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (IBAction)backAction:(UIButton *)sender {
    
    
    
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}
- (void)initData{
    [self.dataArray addObject:@"大照片"];
    [self.dataArray addObject:@"模糊照片"];
    [self.dataArray addObject:@"大视频"];
    [self.dataArray addObject:@"分享给好友"];
    [self.dataArray addObject:@"联系我们"];
    [self.dataArray addObject:@"给个好评"];
    
    
    [self.titleArray addObject:@"应用配置"];
    [self.titleArray addObject:@"关于"];
    
    
}
- (void)initUI{
    self.tableView.backgroundColor = UIColorFromRGB(0xf1f1f1);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    //    self.tableView
    [self.tableView registerClass:[SectionView class] forHeaderFooterViewReuseIdentifier:NSStringFromClass([SectionView class])];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([SettingCell class]) bundle:[NSBundle mainBundle]] forCellReuseIdentifier:NSStringFromClass([SettingCell class])];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([ConfigCell class]) bundle:[NSBundle mainBundle]] forCellReuseIdentifier:NSStringFromClass([ConfigCell class])];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    switch (section) {
        case 0:
            return 3;
            break;
        case 1:
            return 3;
            break;
            
        default:
            return 0;
            break;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    switch (section) {
        case 0:
            return 1;
            break;
        case 1:
            return [self heightForTitle:10];
            break;
            
        default:
            return 0.1f;
            break;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    
    if (section < 3) {
        return [self heightForTitle:section];
    }
    return 0.1f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (indexPath.section == 0) {
        ConfigCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ConfigCell class]) forIndexPath:indexPath];
        cell.titleString = self.dataArray[indexPath.row];
        cell.backgroundColor = [UIColor whiteColor];
        
        switch (indexPath.row) {
            case 0:
                cell.sizeInfo = [ConfigModel sizeStringBy:[ConfigModel imageMaxSize]];
                break;
            case 1:
                cell.sizeInfo = [ConfigModel dimDescription];
                break;
            case 2:
                cell.sizeInfo = [ConfigModel sizeStringBy:[ConfigModel videoMaxSize]];
                
                break;
                
            default:
                cell.sizeInfo = @"";
                break;
        }
        
        
        
        return cell;
    }else{
        SettingCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([SettingCell class]) forIndexPath:indexPath];
        
        cell.titleString = self.dataArray[indexPath.row + 3] ;
        cell.backgroundColor = [UIColor whiteColor];
        
        return cell;
    }
    
    
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    SectionView *header = [SectionView headerViewWithTableView:tableView title:self.titleArray[section]];
    return header;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    NSString *title = @"";
    if(section == 1){
        title = @"您完全可以自定义扫描配置，让手机清理更符合您的心意!";
    }
    
    SectionView *footerView = [SectionView headerViewWithTableView:tableView title:title];
    
    return footerView;
}



- (CGFloat)heightForTitle:(NSInteger)index{
    
    NSString *str = @"您完全可以自定义扫描配置，让手机清理更符合您的心意!" ;
    if (index < self.titleArray.count) {
        str = self.titleArray[index];
    }
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:4];//设置行间距
    //最大宽度为300，最大高度为200
    
    CGFloat countW = ScreenWidth - 12 * 2;
    CGSize size = [str boundingRectWithSize:CGSizeMake(countW, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14] ,NSParagraphStyleAttributeName:paragraphStyle} context:nil].size;
    
    return size.height + 18;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        [self showInfo:indexPath.row];
    }else if(indexPath.section == 1){
        if (indexPath.row == 0) {
            [self shareAction];
        }else if (indexPath.row == 1){
            [self feedBackAction];
        }else{
            [self commentAction];
        }
    }
    
    
}

- (void)showInfo:(NSInteger)index{
    
    NSMutableArray *dataArray = [NSMutableArray array];
    NSInteger defaultIndex = 0;
    if (index != 2) {
        for (NSInteger i = 3; i < 101; i ++) {
            [dataArray addObject:@(i)];
        }
        
        NSNumber *number = @(100);
        if (index == 0) {
            number = @((NSInteger)[ConfigModel imageMaxSize] / (M_KB * M_KB));
        }else{
            number = @((NSInteger)[ConfigModel dimSize]);
        }
        
        defaultIndex = [dataArray indexOfObject:number];
    }else{
        for (NSInteger i = 1; i < 101; i ++) {
            [dataArray addObject:@(i * 10)];
        }
        
        
        NSNumber *number = @((NSInteger)[ConfigModel videoMaxSize] / (M_KB * M_KB));
        
        defaultIndex = [dataArray indexOfObject:number];
    }
    
    
    
    
    
    ActionStringDoneBlock done = ^(ActionSheetStringPicker *picker, NSInteger selectedIndex, id selectedValue) {
        
        switch (picker.tag - 100) {
            case 0:
                [ConfigModel updateImageMaxSize:[selectedValue integerValue]];
                break;
            case 1:
                [ConfigModel updateDimSize:[selectedValue integerValue]];
                
                break;
            case 2:
                [ConfigModel updateVideoMaxSize:[selectedValue integerValue]];
                
                break;
                
            default:
                break;
        }
        WeakSelf(weakSelf)
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf.tableView reloadData];
        });
        
    };
    ActionStringCancelBlock cancel = ^(ActionSheetStringPicker *picker) {
        NSLog(@"Block Picker Canceled");
    };
    ActionSheetStringPicker *picker = [ActionSheetStringPicker showPickerWithTitle:self.dataArray[index] rows:dataArray initialSelection:defaultIndex doneBlock:done cancelBlock:cancel origin:self.tableView];
    picker.tag = 100 + index;
}

#pragma mark - action

- (void)feedBackAction {
    
    MFMailComposeViewController* controller = [[MFMailComposeViewController alloc] init];
    if (!controller) {
        // 在设备还没有添加邮件账户的时候mailViewController为空，下面的present view controller会导致程序崩溃，这里要作出判断
        //            NSLog(@"设备还没有添加邮件账户");
        [self.view makeToast:@"您的设备还没有添加邮件账户" duration:3.0f position:@"center"];
    }else{
        controller.mailComposeDelegate = self;
        NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
        // app名称
        NSString *app_Name = [infoDictionary objectForKey:@"CFBundleName"];
        // app版本
        NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
        
        [controller setSubject:[NSString stringWithFormat:@"%@(%@)%@",app_Name,app_Version,(@"反馈")]];
        NSString * device = [[UIDevice currentDevice] model];
        NSString * ios = [[UIDevice currentDevice] systemVersion];
        NSString *body = [NSString stringWithFormat:(@"请留下您的宝贵建议和意见：\n\n\n以下信息有助于我们确认您的问题，建议保留。\nDevice: %@\nOS Version: %@\n"), device, ios];
        [controller setMessageBody:body isHTML:NO];
        NSArray *toRecipients = [NSArray arrayWithObject:@"1328783670@qq.com"];
        [controller setToRecipients:toRecipients];
        
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            [self presentViewController:controller animated:YES completion:nil];
        }
        //if iPad
        else {
            // Change Rect to position Popover
            UIPopoverController *popup = [[UIPopoverController alloc] initWithContentViewController:controller];
            [popup presentPopoverFromRect:CGRectMake(self.view.frame.size.width/2, self.view.frame.size.height/4, 0, 0)inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        }
        
    }
}
- (void)commentAction{
    if (@available(iOS 10.3, *)) {
        [SKStoreReviewController requestReview];
    }else{
        [[UIApplication sharedApplication] openURL:APP_RATE];
    }
}
- (void)shareAction {
    UIImage *shareImage = [UIImage imageNamed:@"logo"];
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    // app名称
    NSString *shareTitle = [infoDictionary objectForKey:@"CFBundleName"];
    
    UIActivityViewController * activityViewController = [[UIActivityViewController alloc]initWithActivityItems:@[shareTitle,shareImage,APP_SHARE] applicationActivities:nil];
    
    WeakSelf(weakSelf)
    [activityViewController setCompletionWithItemsHandler:^(UIActivityType  _Nullable activityType, BOOL completed, NSArray * _Nullable returnedItems, NSError * _Nullable activityError) {
        StrongSelf(strongSelf)
        if (completed){
            [strongSelf.view makeToast:@"分享成功" duration:3.0f position:@"bottom"];
            //            [Toast showToast:@"分享成功" location:@"bottom" showTime:3.0];
        }else{
            [strongSelf.view makeToast:@"分享取消" duration:3.0f position:@"bottom"];
            //            [Toast showToast:@"分享取消" location:@"bottom" showTime:3.0];
        }
    }];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        [self presentViewController: activityViewController animated: YES completion: nil];
    }
    //if iPad
    else {
        // Change Rect to position Popover
        UIPopoverController *popup = [[UIPopoverController alloc] initWithContentViewController:activityViewController];
        [popup presentPopoverFromRect:CGRectMake(self.view.frame.size.width/2, self.view.frame.size.height/4, 0, 0)inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }
}



- (void)mailComposeController:(MFMailComposeViewController*)controller
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError*)error;
{
    if (result == MFMailComposeResultSent) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:(@"您的反馈信息发送成功了") message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:(@"确定") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alertController addAction:okAction];
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            [self presentViewController:alertController animated:YES completion:nil];
        }
        //if iPad
        else {
            // Change Rect to position Popover
            UIPopoverController *popup = [[UIPopoverController alloc] initWithContentViewController:alertController];
            [popup presentPopoverFromRect:CGRectMake(self.view.frame.size.width/2, self.view.frame.size.height/4, 0, 0)inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
        }
        
        
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
