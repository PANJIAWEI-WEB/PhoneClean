//
//  BaseViewController.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^BackBlock)(void);
@interface BaseViewController : UIViewController


/// 请求插页广告次数
@property(nonatomic, assign) NSInteger count;

@property (nonatomic , copy) BackBlock backBlock;

//提醒框
- (void)addTipWithTitle:(NSString *)title
                    tip:(NSString *)tip
                OKTitle:(NSString *)okTitle
              okHandler:(void (^ __nullable)(UIAlertAction *action))handler
            cancleTitle:(NSString *)cancleTitle
          cancleHandler:(void (^ __nullable)(UIAlertAction *action))cancleHandler;


//banner ADs
@property(nonatomic, strong) GADBannerView *bView;
//广告位置
@property(nonatomic, strong) UIImageView *imageView;

//创建插页广告
- (void)createAndLoadInterstitial;
//展示插页广告
- (BOOL)showInterstitial;
//插页广告结束
- (void)endInterstitial;
//更新底部高度
- (void)updateBottom;
@end

NS_ASSUME_NONNULL_END
