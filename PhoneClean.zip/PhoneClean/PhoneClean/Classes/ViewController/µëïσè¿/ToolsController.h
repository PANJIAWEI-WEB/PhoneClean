//
//  ToolsController.h
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

/// 详情界面
@interface ToolsController : BaseViewController
//根据index判断界面
@property (nonatomic, assign) NSInteger index;

@end

NS_ASSUME_NONNULL_END
