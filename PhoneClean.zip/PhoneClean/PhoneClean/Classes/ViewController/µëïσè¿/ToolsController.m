//
//  ToolsController.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "ToolsController.h"
#import "ToolMediaCell.h"
#import "ImageUtils.h"
#import "MediaHelper.h"
#import "YBIBToolViewHandler.h"
#import <YBImageBrowser/YBImageBrowser.h>
#import <YBImageBrowser/YBIBVideoData.h>
#import "MBProgressHUD.h"
@interface ToolsController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate,ToolMediaCellDelegate>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *heightConstraint;
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomConstraint;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *deletedArray;
@property (nonatomic, strong) MediaHelper *helper;
@property (nonatomic, strong)YBImageBrowser * browser;
@property (nonatomic, strong) MBProgressHUD *hud;
@end

@implementation ToolsController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //创建插页广告
    [self createAndLoadInterstitial];
    
    self.heightConstraint.constant = 60;
    
    NSArray *array = @[@"自拍",@"实况",@"全景",@"App图片",@"连拍",@"屏幕截图",@"Gif",@"所有视频",@"其他App视频"];
    
    self.label.text = array[self.index];
    
    
    [self initData];
    [self initUI];
    if (@available(iOS 11.0, *)) {
        UIWindow *window = UIApplication.sharedApplication.keyWindow;
        self.bottomConstraint.constant = self.bView.frame.size.height + window.safeAreaInsets.bottom;
    }else{
        self.bottomConstraint.constant = self.bView.frame.size.height;
    }
//    self.bottomConstraint.constant = self.bView.frame.size.height + KERN_SAFEBOOT;

}
- (IBAction)backAction:(id)sender {
//    self dism
    [self dismissViewControllerAnimated:YES completion:^{
            
    }];
}
- (IBAction)wholeAction:(UIButton *)sender {
    
    NSString *newTitle = @"全选";
    if ([sender.titleLabel.text isEqualToString:@"全选"]) {
        newTitle = @"取消全选";
        [self.deletedArray removeAllObjects];
        [self.deletedArray addObjectsFromArray:self.dataArray];
    }else{
        [self.deletedArray removeAllObjects];
    }
    [sender setTitle:newTitle forState:(UIControlStateNormal)];
    
    [self.collectionView reloadData];
    
}
- (IBAction)cleanAction:(id)sender {
    if ([SandBoxHelper VIP]) {
        [self endInterstitial];
    }else{
        if (![self showInterstitial]) {
            //未获取到page ads
            if (self.count == 2) {
                [self endInterstitial];
            }
        }
    }
}
- (void)endInterstitial{
    self.count = 0;

    //开始删除选中内容
    WeakSelf(weakSelf)
    [[ImageUtils shareManager] cleanAll:self.deletedArray completion:^(BOOL success, NSUInteger size) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf action:size];
        });
       
        
        
    }];
    
}

- (void)action:(NSUInteger)size{
    NSInteger count = self.deletedArray.count;
    if (size > 0) {
        for (NSDictionary *dict in self.deletedArray) {
            [self.dataArray removeObject:dict];
        }
        [self.collectionView reloadData];
    }
   
    
    WeakSelf(weakSelf)
    [self addTipWithTitle:@"清理结果" tip:[NSString stringWithFormat:@"清理完成，共计清理%@空间\n%zd条数据",[ConfigModel sizeStringBy:((NSUInteger) size)],count] OKTitle:@"继续清理" okHandler:^(UIAlertAction * _Nonnull action) {
        
        
    } cancleTitle:@"返回上一级" cancleHandler:^(UIAlertAction * _Nonnull action) {
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf backAction:nil];
        });
    }];
    
    
    
}

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSMutableArray *)deletedArray{
    if (!_deletedArray) {
        _deletedArray = [NSMutableArray array];
    }
    return _deletedArray;
}

- (void)initData{
    
    
    self.hud = [[MBProgressHUD alloc] init];
    self.hud.label.text = @"正在查找媒体文件……";
    self.hud.mode = MBProgressHUDModeIndeterminate;
    
    self.hud.label.textColor = UIColorFromRGB(0x333333);
    self.hud.label.font = [UIFont systemFontOfSize:14];
    [self.hud showAnimated:YES];
    [self.view addSubview:self.hud];
    
    WeakSelf(weakSelf)
    self.helper = [[MediaHelper alloc] init];
    [self.helper getDataByIndex:self.index completion:^(BOOL success, NSArray * _Nonnull array) {
        [weakSelf.dataArray removeAllObjects];
        [weakSelf.dataArray addObjectsFromArray:array];
        
        
        //处理删除Array
        for (NSDictionary *dict in array) {
            NSNumber *size = dict[@"size"];
            
            if (weakSelf.index < 7) {
                if ([size integerValue] > [ConfigModel imageMaxSize]) {
                    [weakSelf.deletedArray addObject:dict];
                }
            }else{
                if ([size integerValue] > [ConfigModel videoMaxSize]) {
                    [weakSelf.deletedArray addObject:dict];
                }
            }
            
        }
        
        
        
        
        weakSelf.collectionView.emptyDataSetSource = self;
        weakSelf.collectionView.emptyDataSetDelegate = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf.hud hideAnimated:YES];
//            [MBProgressHUD hideHUD];
            if (strongSelf.dataArray.count > 0) {
                strongSelf.heightConstraint.constant = 60;
                
            }else{
                strongSelf.heightConstraint.constant = 60;
                
            }
            
            
            if (![strongSelf.label.text isEqualToString:@"工具界面"]) {
                [strongSelf.collectionView reloadData];
            }
        });
        
    }];
}

- (void)initUI{
    self.collectionView.backgroundColor = [UIColor whiteColor];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.collectionView registerClass:[ToolMediaCell class] forCellWithReuseIdentifier:NSStringFromClass([ToolMediaCell class])];
//    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ToolMediaCell class]) bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:NSStringFromClass([ToolMediaCell class])];
}


- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView
{
    NSString *text = [NSString stringWithFormat:@"您的当前设备中没有%@资源",self.label.text];
    
    NSDictionary *attributes = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:14.0f],
                                 NSForegroundColorAttributeName: UIColorFromRGB(0x999999)};
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataArray.count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ToolMediaCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ToolMediaCell class]) forIndexPath:indexPath];
    
//    NSDictionary *dict = self.dataArray[indexPath.row];
//    cell.type = self.type;
    cell.dict = self.dataArray[indexPath.row];
    cell.showSelected = [self.deletedArray containsObject:self.dataArray[indexPath.row]];
    cell.delegate = self;
    cell.index = indexPath.row;
    cell.backgroundColor = [UIColor whiteColor];
    cell.backgroundColor = RANDOM_COLOR;
    cell.layer.cornerRadius = 5.f;
    cell.layer.masksToBounds = YES;
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    CGFloat width = CGRectGetWidth(collectionView.frame);
    
    CGFloat count = 4;
    
    CGFloat w = (width - count * 10 - 10 * 2 - 2) / count;
    
    return CGSizeMake(w, w);
    
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.index < 7 ) { //图片预览
        self.browser = [YBImageBrowser new];
        NSMutableArray *data = [NSMutableArray array];
        for (NSDictionary *dict in self.dataArray) {
            YBIBImageData *data1 = [YBIBImageData new];
            data1.imagePHAsset = dict[@"asset"];
            [data addObject:data1];
        }
        YBIBToolViewHandler *info = [YBIBToolViewHandler new];
        self.browser.toolViewHandlers = @[info,info];
        self.browser.dataSourceArray = data;
        self.browser.currentPage = indexPath.row;
        [self.browser show];
    }else{ //视频预览
        self.browser = [YBImageBrowser new];
        
        NSMutableArray *data = [NSMutableArray array];
        for (NSDictionary *dict in self.dataArray) {
            
            YBIBVideoData *data1 = [YBIBVideoData new];
            data1.videoPHAsset  = dict[@"asset"];
            [data addObject:data1];
        }
        YBIBToolViewHandler *info = [YBIBToolViewHandler new];
        self.browser.toolViewHandlers = @[info,info];
        self.browser.dataSourceArray = data;
        self.browser.currentPage = indexPath.row;
        [self.browser show];
    }
}


- (void)changeData:(NSDictionary *)dict index:(NSInteger)index{
    if ([self.deletedArray containsObject:dict]) {
        [self.deletedArray removeObject:dict];
    }else{
        [self.deletedArray addObject:dict];
    }
    [self.collectionView reloadItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]]];
}
@end
