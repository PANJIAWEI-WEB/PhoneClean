//
//  CategoryViewController.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "CategoryViewController.h"
#import "ToolViewCell.h"
#import "ToolsController.h"
@interface CategoryViewController()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@property (nonatomic,strong) NSMutableArray *dataArray;
@end

@implementation CategoryViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [self initUI];
    
}
#pragma mark - lazy
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
        [_dataArray addObject:@[@"自拍",@"实况",@"全景",@"App图片",@"快照连拍",@"屏幕截图",@"Gif"]];
        [_dataArray addObject:@[@"所有视频",@"其他App视频"]];
    }
    return _dataArray;
}
#pragma mark - method
- (void)initUI{
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[ToolViewCell class] forCellWithReuseIdentifier:NSStringFromClass([ToolViewCell class])];
}
- (void)turnToTools:(NSInteger)index{
    
    ToolsController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ToolsController"];
    vc.index = index;
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    
    [self presentViewController:vc animated:YES completion:^{
            
    }];
}
- (IBAction)backAction:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:^{
            
    }];
}

#pragma mark - delegate

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return self.dataArray.count;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return ((NSArray *)self.dataArray[section]).count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ToolViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ToolViewCell class]) forIndexPath:indexPath];
    cell.info = self.dataArray[indexPath.section][indexPath.row];
    cell.backgroundColor = [UIColor whiteColor];
    cell.layer.masksToBounds = NO;
    cell.layer.cornerRadius = 10;

    cell.layer.shadowOpacity = 0.16;   //阴影透明度
    cell.layer.shadowColor = [UIColor blackColor].CGColor;   //阴影颜色
    cell.layer.shadowRadius = 5;  //模糊计算的半径
    cell.layer.shadowOffset = CGSizeMake(0, 0);
    cell.backgroundColor = [UIColor whiteColor];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger index = indexPath.row;
    if (indexPath.section > 0) {
        index += ((NSArray *)self.dataArray[indexPath.section - 1]).count;
    }
    [self turnToTools:index];
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    //
    CGFloat w = ScreenWidth - 20 * 2; //除去边距
    CGFloat margin = 10;
    w = (w - margin * 2) / 3.0f;
    return CGSizeMake(w, w);
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
   
    return UIEdgeInsetsMake(20, 20, 20, 20);
  
}

-(CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}

@end
