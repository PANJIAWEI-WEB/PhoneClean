//
//  OptimizeViewController.m
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "OptimizeViewController.h"
#import "SectionView.h"
#import "InfoViewCell.h"
#import "ContactHelper.h"
#import "EventHelper.h"
#import "PrivacyUtils.h"
@interface OptimizeViewController ()<UITableViewDelegate,UITableViewDataSource,DZNEmptyDataSetSource, DZNEmptyDataSetDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *heightConstaint;
@property (weak, nonatomic) IBOutlet UIView *whiteView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *toolBottomConstraint;

@property (nonatomic, strong) NSMutableArray *deleteArray;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (weak, nonatomic) IBOutlet UIButton *allButton;
@property (weak, nonatomic) IBOutlet UIView *deleteView;

@end
@implementation OptimizeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    
    
    //创建插页广告
    [self createAndLoadInterstitial];
    
    [self initUI];
    
    
    if (self.type == OptimizeCalendar) {
        
        WeakSelf(weakSelf)
        //日历
        [[PrivacyUtils shareInstance] CheckPrivacyAuthWithType:(PrivacyType_Calendars) isPushSetting:YES withHandle:^(BOOL granted, AuthStatus status) {
            
            //提醒事项
            [[PrivacyUtils shareInstance] CheckPrivacyAuthWithType:(PrivacyType_Reminders) isPushSetting:YES withHandle:^(BOOL granted, AuthStatus status) {
                 StrongSelf(strongSelf)
                dispatch_async(dispatch_get_main_queue(), ^{
                    [strongSelf initData];
                });
            }];
            
        }];
        
    }else{
        
        [self initData];
    }
    
    
    [self.allButton setHidden:YES];
    self.toolBottomConstraint.constant =  0;
//    self.toolBottomConstraint.constant = self.bView.frame.size.height;
    
}


//更新底部高度
- (void)updateBottom{
    self.toolBottomConstraint.constant = self.bView.frame.size.height;
}

-(NSMutableArray *)deleteArray{
    if (!_deleteArray) {
        _deleteArray = [NSMutableArray array];
    }
    return _deleteArray;
}
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)initData{
    if (self.scanModel) {
        //扫描状态
        if (self.type == OptimizeContact) {
           
            [[ContactHelper shareManager] loadContactWithProcess:^(NSInteger current, NSInteger total, NSString * _Nonnull currentName) {
                
            } completionHandler:^(BOOL success, NSError * _Nonnull error) {
                WeakSelf(weakSelf)
                dispatch_async(dispatch_get_main_queue(), ^{
                    StrongSelf(strongSelf)
                    [strongSelf configData];
                });
            }];
        }else{
            [[EventHelper shareManager] loadContactWithProcess:^(NSInteger current, NSInteger total, NSString * _Nonnull currentName) {
                
            } completionHandler:^(BOOL success, NSError * _Nonnull error) {
                WeakSelf(weakSelf)
                dispatch_async(dispatch_get_main_queue(), ^{
                    StrongSelf(strongSelf)
                    [strongSelf configData];
                });
            }];
        }
        
    }else{
        [self configData];
    }
}

- (void)configData{
    
    if (self.scanModel) {
        self.heightConstaint.constant = 60;
        self.whiteView.hidden = NO;
    }else{
        self.heightConstaint.constant = 0;
        self.whiteView.hidden = YES;
        
    }
    
    if (self.type == OptimizeContact) {
        [self.dataArray addObjectsFromArray:[[ContactHelper shareManager] getContactArray]];
        [self.deleteArray addObjectsFromArray:[[ContactHelper shareManager] getAllDelArray]];
    }else{
        [self.dataArray addObjectsFromArray:[[EventHelper shareManager] getAllEvents]];
        [self.deleteArray addObjectsFromArray:[[EventHelper shareManager] getAllDelEvents]];
    }
    
    
    NSInteger count = 0;
    for (id data in self.dataArray) {
        if (self.type == OptimizeContact) {
            count += ((NSArray *)(([data allValues]).firstObject)).count;
        }else{
            count += ((NSArray *)data).count;
        }
    }
//    [self.allButton setHidden:count == 0];
    [self.deleteView setHidden:count == 0];
    [self.tableView reloadData];
}

- (void)initUI{
    if (self.type == OptimizeContact) {
        self.nameLabel.text = @"通讯录清理";
    }else{
        self.nameLabel.text = @"日历&提醒清理";
    }
    
    self.tableView.backgroundColor = UIColorFromRGB(0xf1f1f1);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.emptyDataSetSource = self;
    self.tableView.emptyDataSetDelegate = self;
    
//    self.tableView
    [self.tableView registerClass:[SectionView class] forHeaderFooterViewReuseIdentifier:NSStringFromClass([SectionView class])];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([InfoViewCell class]) bundle:[NSBundle mainBundle]] forCellReuseIdentifier:NSStringFromClass([InfoViewCell class])];
    
    
}

- (IBAction)allAction:(UIButton *)sender {
    
}
- (IBAction)backAction:(UIButton *)sender {
    
    if (self.backBlock) {
        self.backBlock();
    }
    
    [self dismissViewControllerAnimated:YES completion:^{
            
    }];
}

- (IBAction)cleanAction:(UIButton *)sender {
    
    if ([SandBoxHelper VIP]) {
        [self endInterstitial];
    }else{
//        [self endInterstitial];
        if (![self showInterstitial]) {
            [[[UIApplication sharedApplication] keyWindow] makeToast:@"未拉取到广告" duration:3.0f position:@"bottom"];
            //未获取到page ads
            
            if (self.count == 2) {
                [self endInterstitial];
            }
        }
    }
}
- (void)endInterstitial{
    self.count = 0;
    if (self.type == OptimizeContact) {
        WeakSelf(weakSelf)
        [[ContactHelper shareManager] cleanAction:^(BOOL success, NSError * _Nonnull error) {
            [weakSelf showInfo:@"通讯录" count:-1];
        }];
    }else{
        WeakSelf(weakSelf)
        [[EventHelper shareManager] cleanAction:^(BOOL success, NSInteger count) {
            [weakSelf showInfo:@"日历&提醒" count:count];
        }];
    }
}

- (void)showInfo:(NSString *)info count:(NSInteger) count{
    
    //清理完成
    WeakSelf(weakSelf)
    [self addTipWithTitle:@"清理结果" tip:[NSString stringWithFormat:@"%@优化清理完成，共计清理%zd条数据",info,(count > -1 ? count : self.deleteArray.count)] OKTitle:@"确定" okHandler:^(UIAlertAction * _Nonnull action) {
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf backAction:nil];
        });
        
    } cancleTitle:@"" cancleHandler:^(UIAlertAction * _Nonnull action) {
//        [weakSelf backAction:nil];
    }];
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (self.type == OptimizeContact) {
//        self.nameLabel.text = @"通讯录优化";
        return self.dataArray.count;
    }else{
        return self.dataArray.count;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
   
    if (self.type == OptimizeContact) {
        NSDictionary *dict = self.dataArray[section];
        return ((NSArray *)(([dict allValues]).firstObject)).count;
    }else{
        return ((NSArray *)self.dataArray[section]).count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    InfoViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([InfoViewCell class]) forIndexPath:indexPath];
    
    if (self.type == OptimizeContact) {
        if (indexPath.section == self.dataArray.count - 1) {
            cell.type = InfoTypeSameNumber;
        }else{
            cell.type = InfoTypeNilNumber;
        }
        
        NSDictionary *dict = self.dataArray[indexPath.section];
        cell.info = ((NSArray *)(([dict allValues]).firstObject))[indexPath.row];
        
    }else{ //事项
        if (indexPath.section == self.dataArray.count - 1) {
            cell.type = InfoTypeReminder;
        }else{
            cell.type = InfoTypeEvents;
        }
        cell.info = self.dataArray[indexPath.section][indexPath.row];
    }
    
    cell.deleted = [self.deleteArray containsObject:cell.info];
    
    
    return cell;
    
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    id info;
    if (self.type == OptimizeContact) {
       
        NSDictionary *dict = self.dataArray[indexPath.section];
        info = ((NSArray *)(([dict allValues]).firstObject))[indexPath.row];
        
        [[ContactHelper shareManager] updateInfo:info event:NO];
        
    }else{ //事项
       info = self.dataArray[indexPath.section][indexPath.row];
        
        if (indexPath.section == self.dataArray.count - 1) {
            [[EventHelper shareManager] updateInfo:info event:NO];
        }else{
            [[EventHelper shareManager] updateInfo:info event:YES];
        }
    }
    
    if ([self.deleteArray containsObject:info]) {
        [self.deleteArray removeObject:info];
    }else{
        [self.deleteArray addObject:info];
    }
    
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:(UITableViewRowAnimationNone)];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
  
    return 5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 45;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 68;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    NSString *title = @"";
    if (self.type == OptimizeContact) {
        title = [self.dataArray[section] allKeys].firstObject;
    }else{
        switch (section) {
            case 0:
                title = @"过期日历";
                break;
            case 1:
                title = @"过期提醒事项";
                break;
                
            default:
                break;
        }
    }
    
    
    SectionView *headerView = [SectionView headerViewWithTableView:tableView title:title];
    
    return headerView;
}


- (NSAttributedString *)titleForEmptyDataSet:(UIScrollView *)scrollView
{
    NSString *text = @"您的当前设备中无该类内容的推荐清理优化";
    
    NSDictionary *attributes = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:14.0f],
                                 NSForegroundColorAttributeName: UIColorFromRGB(0x999999)};
    
    return [[NSAttributedString alloc] initWithString:text attributes:attributes];
}

@end
