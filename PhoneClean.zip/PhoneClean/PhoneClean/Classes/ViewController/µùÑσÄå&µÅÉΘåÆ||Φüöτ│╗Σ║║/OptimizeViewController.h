//
//  OptimizeViewController.h
//  PhoneClean
//
//  Created by PW on 2021/5/7.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSUInteger, OptimizeType) {
    OptimizeContact, //联系人
    OptimizeCalendar, //日历
};
@interface OptimizeViewController : BaseViewController

//是否需要扫描
@property (nonatomic, assign) BOOL scanModel;

@property (nonatomic, assign) OptimizeType type;

@end

NS_ASSUME_NONNULL_END
