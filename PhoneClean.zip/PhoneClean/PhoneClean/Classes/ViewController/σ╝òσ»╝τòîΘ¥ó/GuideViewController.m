//
//  GuideViewController.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "GuideViewController.h"
#import "StartVIPController.h"
#import "GuideView.h"
@interface GuideViewController ()<UIScrollViewDelegate,GuideViewDelegate>
@property (nonatomic, strong) UIScrollView *scrollView;

@end

@implementation GuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initUI];
}

- (void)initUI{
    
//    UIButton *button = [[UIButton alloc] init];
//    [self.view addSubview:button];
//    [button addTarget:self action:@selector(clickedAction) forControlEvents:(UIControlEventTouchDown)];
//    [button mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.center.mas_equalTo(self.view);
//        make.width.height.mas_equalTo(100);
//    }];
//    [button setBackgroundColor:[UIColor redColor]];
    
    
    
    self.scrollView = [[UIScrollView alloc] init];
    [self.scrollView setBackgroundColor:[UIColor orangeColor]];
    [self.view addSubview:self.scrollView];
    [self.scrollView setScrollEnabled:NO];
    [self.scrollView setPagingEnabled:YES];
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
    self.scrollView.delegate = self;
    self.scrollView.contentSize = CGSizeMake(ScreenWidth * 3,ScreenHeight);
    self.scrollView.contentOffset = CGPointMake(0, 0);
    
    
    for (NSInteger i = 0; i < 3; i ++) {
        GuideView *view = [[GuideView alloc] initWithFrame:CGRectMake(i * ScreenWidth, 0, ScreenWidth, ScreenHeight) index:i];
        
        view.index = i;
        view.delegate = self;
        [self.scrollView addSubview:view];
    }
    
}



- (void)clickedAction{
    StartVIPController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"StartVIPController"];
    // 展示会员
    AppDelegate *delegate=(AppDelegate*)[[UIApplication sharedApplication] delegate];
    [delegate.window setRootViewController:vc];
}

#pragma mark - delegate
- (void)didSelected:(NSInteger)index{
    
    switch (index) {
        case 0:{
            WeakSelf(weakSelf)
            //相册
            [[PrivacyUtils shareInstance] CheckPrivacyAuthWithType:(PrivacyType_Photos) isPushSetting:YES withHandle:^(BOOL granted, AuthStatus status) {
                 StrongSelf(strongSelf)
                dispatch_async(dispatch_get_main_queue(), ^{
                    strongSelf.scrollView.contentOffset = CGPointMake((index + 1) * ScreenWidth, 0);
                });
            }];
        }break;
        case 1:{
            WeakSelf(weakSelf)
            //通讯录
            [[PrivacyUtils shareInstance] CheckPrivacyAuthWithType:(PrivacyType_Contacts) isPushSetting:YES withHandle:^(BOOL granted, AuthStatus status) {
                 StrongSelf(strongSelf)
                dispatch_async(dispatch_get_main_queue(), ^{
                    strongSelf.scrollView.contentOffset = CGPointMake((index + 1) * ScreenWidth, 0);
                });
            }];
        }
            break;
        case 2:{
            WeakSelf(weakSelf)
            //日历
            [[PrivacyUtils shareInstance] CheckPrivacyAuthWithType:(PrivacyType_Calendars) isPushSetting:YES withHandle:^(BOOL granted, AuthStatus status) {
                //提醒事项
                [[PrivacyUtils shareInstance] CheckPrivacyAuthWithType:(PrivacyType_Reminders) isPushSetting:YES withHandle:^(BOOL granted, AuthStatus status) {
                    StrongSelf(strongSelf)
                   dispatch_async(dispatch_get_main_queue(), ^{
                       
                       [strongSelf clickedAction];
//                       strongSelf.scrollView.contentOffset = CGPointMake((index + 1) * ScreenWidth, 0);
                   });
                }];
                 
            }];
        } break;
            
        default:
            break;
    }
}


- (UIStatusBarStyle)preferredStatusBarStyle {
   return UIStatusBarStyleLightContent;
   // return UIStatusBarStyleDefault;
}

@end
