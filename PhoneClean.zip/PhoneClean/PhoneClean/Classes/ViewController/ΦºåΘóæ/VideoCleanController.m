//
//  VideoCleanController.m
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "VideoCleanController.h"
#import "ScanWaiteView.h"
#import "CleanImageCell.h"
#import "VideoUtils.h"
#import "ImageDetailController.h"
#import "VideoDetailController.h"
@interface VideoCleanController ()<UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@property (weak, nonatomic) IBOutlet UILabel *dwLabel;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *cleanButton;
@property (nonatomic, assign) BOOL statusNotScan;


@property (weak, nonatomic) IBOutlet UIView *infoBackView;
@property (weak, nonatomic) IBOutlet UIView *scanBackView;
@property (weak, nonatomic) IBOutlet UILabel *processLabel;
@property (strong, nonatomic)  ScanWaiteView *scanWaiteView;

@end

@implementation VideoCleanController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self createAndLoadInterstitial];
    self.statusNotScan = !self.scanModel;
    [self initUI];
    
    if (self.scanModel) {
        [self cleanAction];
    }else{
        //结果展示
        self.statusNotScan = YES;
        [self.cleanButton setHidden:YES];
        [self.scanBackView setHidden:YES];
        [self.infoBackView setHidden:NO];
        [self updateInfo];
    }
    
}

- (void)initUI{
    
    self.tableView.tableFooterView = [UIView new];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([CleanImageCell class]) bundle:[NSBundle mainBundle]] forCellReuseIdentifier:NSStringFromClass([CleanImageCell class])];
    self.tableView.estimatedRowHeight = 200.0f;
}
- (void)showInfo:(NSString *)info{
    
    //清理完成
    WeakSelf(weakSelf)
    [self addTipWithTitle:@"清理结果" tip:[NSString stringWithFormat:@"照片优化清理完成，共计释放%@",info] OKTitle:@"重新扫描" okHandler:^(UIAlertAction * _Nonnull action) {
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf cleanAction];
            [strongSelf.tableView reloadData];
        });
        
    } cancleTitle:@"返回上一级" cancleHandler:^(UIAlertAction * _Nonnull action) {
        dispatch_async(dispatch_get_main_queue(), ^{
            StrongSelf(strongSelf)
            [strongSelf backAction:strongSelf.cleanButton];
        });
//        [weakSelf backAction:weakSelf.clearButton];
    }];
}
- (void)cleanAction{
    self.processLabel.text = @"0.0";
    
    self.statusNotScan = NO;
    //扫描图形
    [self.scanBackView setHidden:NO];
    [self.infoBackView setHidden:YES];
    
    
    [self.scanBackView addSubview:self.scanWaiteView];
    [self.scanWaiteView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(self.scanBackView);
        make.width.height.mas_equalTo(120);
    }];
    
  
//    [self.scanWaiteView startAnim];
    WeakSelf(weakSelf)
    [[VideoUtils shareManager] loadVideoWithProcess:^(NSInteger current, NSInteger total, NSString * _Nonnull currentName) {
        weakSelf.processLabel.text = [NSString stringWithFormat:@"%.1f",(CGFloat)current / total * 100];
        
    } completionHandler:^(BOOL success, NSError * _Nonnull error) {
        StrongSelf(strongSelf)
        strongSelf.processLabel.text = @"100.0";
        strongSelf.statusNotScan = YES;
        
        [strongSelf.scanBackView setHidden:YES];
        [strongSelf.infoBackView setHidden:NO];
        [strongSelf updateInfo];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [strongSelf.tableView reloadData];
        });
    }];
}
- (void)updateInfo{
    NSUInteger size = [VideoUtils shareManager].totalSaveSpace;
    
    //文件大小
    NSString *fileSize = @"0";
    NSString *units = @"KB";
    
    NSInteger KB = M_KB;
    NSInteger MB = M_MB;
    NSInteger GB = MB*KB;
    if (size < 10)
    {
        fileSize =  @"0";
        units = @"KB";
        
    }else if (size < MB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/KB];
        units = @"KB";
    }else if (size < GB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/MB];
        units = @"MB";
        
    }else
    {
        fileSize = [NSString stringWithFormat:@"%.2f",((CGFloat)size)/GB];
        units = @"GB";
    }
    
    self.numberLabel.text = fileSize;
    self.dwLabel.text = units;
    
}

- (IBAction)cleanAction:(id)sender {
    
    if ([SandBoxHelper VIP]) {
        [self endInterstitial];
    }else{
        [self endInterstitial];
        if (![self showInterstitial]) {
            [[[UIApplication sharedApplication] keyWindow] makeToast:@"未拉取到广告" duration:3.0f position:@"bottom"];
            //未获取到page ads
            
            if (self.count == 2) {
                [self endInterstitial];
            }
        }
    }
}
- (void)endInterstitial{
    WeakSelf(weakSelf)
    [[VideoUtils shareManager] cleanAction:^(NSInteger current, NSInteger total, NSString * _Nonnull currentName) {
        
    } completionHandler:^(BOOL success, NSUInteger size) {
       
        //删除操作已完成
//        long long newSpace = [DeviceInfo availableDiskSize];
        StrongSelf(strongSelf)
        dispatch_async(dispatch_get_main_queue(), ^{
            [strongSelf showInfo:[ConfigModel sizeStringBy:(NSUInteger)(size)]];
        });
        
    }];
}

- (IBAction)backAction:(UIButton *)sender {
    if (self.backBlock) {
        self.backBlock();
    }
    if (self.scanModel) {
        [[VideoUtils shareManager] stopLoadPhoto];
    }
    [self dismissViewControllerAnimated:YES completion:^{
            
    }];
}

#pragma mark - tableview delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CleanImageCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([CleanImageCell class]) forIndexPath:indexPath];
    
    cell.video = YES;
    cell.scanModel = !self.statusNotScan;
    
    if (self.statusNotScan) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    
    cell.type = indexPath.row;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (self.statusNotScan) { //扫描结束
        //界面跳转
        VideoDetailController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VideoDetailController"];
        vc.modalPresentationStyle = UIModalPresentationFullScreen;
        vc.type = indexPath.row;
        
        WeakSelf(weakSelf)
        [vc setBackBlock:^{
             StrongSelf(strongSelf)
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [strongSelf updateInfo];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [strongSelf.tableView reloadData];
                });
                
                
            });
        }];
        [self presentViewController:vc animated:YES completion:nil];
    }
}
@end
