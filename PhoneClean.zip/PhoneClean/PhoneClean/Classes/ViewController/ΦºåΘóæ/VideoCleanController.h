//
//  VideoCleanController.h
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface VideoCleanController : BaseViewController

@property (nonatomic, assign) BOOL scanModel;

@end

NS_ASSUME_NONNULL_END
