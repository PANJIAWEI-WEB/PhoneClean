//
//  ConfigModel.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "ConfigModel.h"

@implementation ConfigModel

+ (ConfigModel *)shareConfig{
    static ConfigModel *mgr = nil;
    static dispatch_once_t token;
    dispatch_once(&token, ^{
        mgr = [[ConfigModel alloc] init];
    });
    return mgr;
}

+ (NSString *)dimDescription{
    
    
    return [NSString stringWithFormat:@"%.0f",[self dimSize]];
    
}
+ (NSString *)sizeStringBy:(NSUInteger)size{
    
    //文件大小
    NSString *fileSize = @"0";
    NSString *units = @"KB";
    
    NSInteger KB = M_KB;
    NSInteger MB = M_MB;
    NSInteger GB = MB*KB;
    if (size < 10)
    {
        fileSize =  @"0";
        units = @"KB";
        
    }else if (size < MB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/KB];
        units = @"KB";
    }else if (size < GB)
    {
        fileSize = [NSString stringWithFormat:@"%.1f",((CGFloat)size)/MB];
        units = @"MB";
        
    }else
    {
        fileSize = [NSString stringWithFormat:@"%.2f",((CGFloat)size)/GB];
        units = @"GB";
    }
    
    return [NSString stringWithFormat:@"%@%@",fileSize,units];
}
+ (CGFloat)videoMaxSize{
    
    if (![[NSUserDefaults standardUserDefaults] valueForKey:@"videoMaxSize"]) {
        [[NSUserDefaults standardUserDefaults] setValue:@(100) forKey:@"videoMaxSize"];
        
        return 100 * M_KB * M_KB;
    }
    
    return [[[NSUserDefaults standardUserDefaults] valueForKey:@"videoMaxSize"] floatValue] * M_KB * M_KB;
    
}

+ (CGFloat)imageMaxSize{
    
    
    
    if (![[NSUserDefaults standardUserDefaults] valueForKey:@"imageMaxSize"]) {
        [[NSUserDefaults standardUserDefaults] setValue:@(3) forKey:@"imageMaxSize"];
        
        return 3 * M_KB * M_KB;
    }
    
    return [[[NSUserDefaults standardUserDefaults] valueForKey:@"imageMaxSize"] floatValue] * M_KB * M_KB;
    
}

+ (CGFloat)dimSize{
    
    
    if (![[NSUserDefaults standardUserDefaults] valueForKey:@"dimSize"]) {
        [[NSUserDefaults standardUserDefaults] setValue:@(100) forKey:@"dimSize"];
        
        return 100 ;
    }
    
    return [[[NSUserDefaults standardUserDefaults] valueForKey:@"dimSize"] floatValue];
}

+ (void)updateDimSize:(CGFloat)dimSize{
    
    [[NSUserDefaults standardUserDefaults] setValue:@(dimSize) forKey:@"dimSize"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}
+ (void)updateImageMaxSize:(CGFloat)dimSize{
    
    [[NSUserDefaults standardUserDefaults] setValue:@(dimSize) forKey:@"imageMaxSize"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}
+ (void)updateVideoMaxSize:(CGFloat)dimSize{
    
    
    [[NSUserDefaults standardUserDefaults] setValue:@(dimSize) forKey:@"videoMaxSize"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}


@synthesize imageDelta = _imageDelta;
- (void)setImageDelta:(NSString *)imageDelta{
    _imageDelta = imageDelta;
    [[NSUserDefaults standardUserDefaults] setValue:imageDelta forKey:@"imageDelta"];
}
- (NSString *)imageDelta{
    if (!_imageDelta) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:@"imageDelta"]) {
            _imageDelta = [[NSUserDefaults standardUserDefaults] valueForKey:@"imageDelta"];
        }else{
            _imageDelta = @"100";
            [[NSUserDefaults standardUserDefaults] setValue:@"100" forKey:@"imageDelta"];
        }
    }
    return _imageDelta;
}
@end
