//
//  ConfigModel.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ConfigModel : NSObject

//默认清晰度 (100,大于100为清晰)
@property (nonatomic, copy) NSString *imageDelta;

//默认大图界限 (4M)
@property (nonatomic, copy) NSString *imageLarge;

//默认相似度 (0.9)
@property (nonatomic, copy) NSString *imageSililary;

//默认大视频 15MB
@property (nonatomic, copy) NSString *videoMax;


/// 扫描配置
+ (ConfigModel *)shareConfig;



+ (NSString *)sizeStringBy:(NSUInteger)size;

+ (CGFloat)dimSize;
+ (NSString *)dimDescription;
+ (void)updateDimSize:(CGFloat)dimSize;

+ (CGFloat)imageMaxSize;
+ (void)updateImageMaxSize:(CGFloat)dimSize;

+ (CGFloat)videoMaxSize;
+ (void)updateVideoMaxSize:(CGFloat)dimSize;

@end

NS_ASSUME_NONNULL_END
