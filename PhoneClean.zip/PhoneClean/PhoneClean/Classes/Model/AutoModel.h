//
//  AutoModel.h
//  PhoneClean
//
//  Created by PW on 2021/5/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 智能扫描
@interface AutoModel : NSObject


@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) double total;
@property (nonatomic, assign) CGFloat process;
@property (nonatomic, assign) BOOL selected;            

@end

NS_ASSUME_NONNULL_END
