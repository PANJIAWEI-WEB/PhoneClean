//
//  EventHelper.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <EventKit/EventKit.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface EventHelper : NSObject

//总共条数
@property (nonatomic, assign) NSInteger totalSaveSpace;

+ (instancetype)shareManager;


@property (nonatomic, assign) BOOL clean;

- (void)loadContactWithProcess:(void (^)(NSInteger current, NSInteger total,NSString *currentName))process
             completionHandler:(void (^)(BOOL success, NSError *error))completion;

- (NSArray *)getAllEvents;
- (NSArray *)getAllDelEvents;
- (void)updateInfo:(id)info
             event:(BOOL)event;

- (void)cleanAction:(void (^)(BOOL success, NSInteger count))completion;


+ (NSString *)getTimeBy:(id)info;




/**查询日历事件*/
-(EKEvent *)queryEKEventForIdentifier;
/**添加日历事件*/
-(void)createEKEventTitle:(NSString *)title startData:(NSDate *)startData endDate:(NSDate *)endDate;
/**删除日历事件*/
-(void)deleteEKEventIdentifier:(NSString *)Identifier;
/**修改日历事件*/
-(void)updateEKEventTitle:(NSString *)title startData:(NSDate *)startData endDate:(NSDate *)endDate;



/**添加提醒事项*/
-(void)addReminderNotifyTitle:(NSString *)title startData:(NSDate *)startData endDate:(NSDate *)endDate;
/**删除提醒事项*/
-(void)removeEKEntityTypeReminderCalendarItemIdentifier:(NSString *)calendarItemIdentifier;
/**修改提醒事项*/
-(void)updateReminderCalendarItemIdentifier:(NSString *)calendarItemIdentifier;

@end

NS_ASSUME_NONNULL_END
