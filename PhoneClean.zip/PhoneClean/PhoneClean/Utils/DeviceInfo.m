//
//  DeviceInfo.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "DeviceInfo.h"

#import <mach/mach_host.h>
#import <sys/mount.h>
#import <UIKit/UIKit.h>

@implementation DeviceInfo



+ (NSString *)applicationDisplayName{

    return appInfoDictionary()[@"CFBundleDisplayName"];
}

+ (NSString *)applicationVersion{

    return appInfoDictionary()[@"CFBundleShortVersionString"];
}



+ (long long)totalMemorySize{

    return [[NSProcessInfo processInfo] physicalMemory];

}
+(NSString *)totalMemorySizeString{
    
    return [self fileSizeToString:[self totalMemorySize]];

}
+ (NSString *)availableDiskSizeString{

    return [self fileSizeToString:[self availableDiskSize]];
}

+ (long long)availableMemorySize{

    vm_statistics_data_t vmStats;
    mach_msg_type_number_t infoCount = HOST_VM_INFO_COUNT;
    kern_return_t kernReturn = host_statistics(mach_host_self(), HOST_VM_INFO, (host_info_t)&vmStats, &infoCount);
    if (kernReturn != KERN_SUCCESS)
    {
        return NSNotFound;
    }
    
    return ((vm_page_size * vmStats.free_count + vm_page_size * vmStats.inactive_count));
}

+(NSString *)availableMemorySizeString{

    return [self fileSizeToString:[self availableMemorySize]];
}

+ (long long)totalDiskSize{

    struct statfs buf;
    unsigned long long freeSpace = -1;
    if (statfs("/var", &buf) >= 0)
    {
        freeSpace = (unsigned long long)(buf.f_bsize * buf.f_blocks);
    }
    return freeSpace;

}

+(NSString *)totalDiskSizeString{

    return [self fileSizeToString:[self totalDiskSize]];
}


+ (long long)usedDiskSize{
    
    return [self totalDiskSize] - [self availableDiskSize];
}
+ (NSString *)usedDiskSizeString{
    
    return [self fileSizeToString:[self usedDiskSize]];
}



+ (long long)availableDiskSize
{
    struct statfs buf;
    unsigned long long freeSpace = -1;
    if (statfs("/var", &buf) >= 0)
    {
        
//        freeSpace = (unsigned long long)(buf.f_bsize * buf.f_bavail);
        freeSpace = (unsigned long long)(buf.f_bsize * buf.f_bfree);
        
    }
    return freeSpace;
}

/**
 将空间大小转化为字符串

 @param fileSize 空间大小
 @return 字符串
 */
+ (NSString *)fileSizeToString:(unsigned long long)fileSize
{
//    NSInteger KB = 1024;
    NSInteger KB = M_KB;
    NSInteger MB = M_MB;
    NSInteger GB = MB*KB;
    
    if (fileSize < 10)
    {
        return @"0B";
        
    }else if (fileSize < KB)
    {
        return @"< 1 KB";
        
    }else if (fileSize < MB)
    {
        return [NSString stringWithFormat:@"%.1fKB",((CGFloat)fileSize)/KB];
        
    }else if (fileSize < GB)
    {
        return [NSString stringWithFormat:@"%.1fMB",((CGFloat)fileSize)/MB];
        
    }else
    {
        return [NSString stringWithFormat:@"%.1fGB",((CGFloat)fileSize)/GB];
    }
}

+ (NSDictionary *)getDivceSizeAndUserSize {

    NSDictionary *fattributes = [[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectory() error:nil];
    
    //总空间
    float   space     =   [[fattributes objectForKey:NSFileSystemSize] floatValue];
    //所剩空间
    float   freespace =   [[fattributes objectForKey:NSFileSystemFreeSize] floatValue];
    
    
    float free_m  =  freespace / 1000 / 1000 / 1000;
    float space_m =  space / 1000 / 1000 / 1000;
    float proportion = (space_m - free_m) / space_m;

    
    NSString * userStr = [NSString stringWithFormat:@"%0.2f",(space_m - free_m)];

    NSString * allStr = [NSString stringWithFormat:@"%0.2f",space_m];
    NSString * proportionStr = [NSString stringWithFormat:@"%.0f",proportion*100];
    

    NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:userStr,@"userSize",allStr,@"allSize",proportionStr,@"canuser", nil];

    return dic;
}


NS_INLINE NSDictionary * appInfoDictionary (void){

    return [[NSBundle mainBundle] infoDictionary];
}
@end
