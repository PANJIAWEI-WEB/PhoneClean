//
//  IAPManager.m
//  IAPDemo
//
//  Created by Charles.Yao on 2016/10/31.
//  Copyright © 2016年 com.pico. All rights reserved.
//



#import "IAPManager.h"
#import "SandBoxHelper.h"
#import "NSString+category.h"
#import "NSDate+category.h"
#import <AFNetworking/AFNetworking.h>

static NSString * const receiptKey = @"receipt_key";
static NSString * const dateKey = @"date_key";
static NSString * const userIdKey = @"userId_key";

dispatch_queue_t iap_queue() {
    static dispatch_queue_t as_iap_queue;
    static dispatch_once_t onceToken_iap_queue;
    dispatch_once(&onceToken_iap_queue, ^{
        as_iap_queue = dispatch_queue_create("com.iap.queue", DISPATCH_QUEUE_CONCURRENT);
    });
    
    return as_iap_queue;
}

@interface IAPManager ()<SKPaymentTransactionObserver, SKProductsRequestDelegate>

@property (nonatomic, assign) BOOL goodsRequestFinished; //判断一次请求是否完成

@property (nonatomic, copy) NSString *receipt; //交易成功后拿到的一个64编码字符串

@property (nonatomic, copy) NSString *date; //交易时间

@property (nonatomic, copy) NSString *userId; //交易人

@property (nonatomic, assign)BOOL onceProduct;//是否是单次购买

@end

@implementation IAPManager

singleton_implementation(IAPManager)


- (void)startManager { //开启监听

    dispatch_async(iap_queue(), ^{
       
        self.goodsRequestFinished = YES;
        
        /***
         内购支付两个阶段：
         1.app直接向苹果服务器请求商品，支付阶段；
         2.苹果服务器返回凭证，app向公司服务器发送验证，公司再向苹果服务器验证阶段；
         */
        
        /**
         阶段一正在进中,app退出。
         在程序启动时，设置监听，监听是否有未完成订单，有的话恢复订单。
         */
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
        
        /**
         阶段二正在进行中,app退出。
         在程序启动时，检测本地是否有receipt文件，有的话，去二次验证。
         */
        [self getReceipt]; //获取交易成功后的购买凭证
        [self saveReceipt]; //存储交易凭证
        [self checkIAPFiles];
        
    });
}

- (void)stopManager{

    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
    });
}

#pragma mark 查询
- (void)requestProductWithId:(NSString *)productId {

    if (self.goodsRequestFinished) {
       
        if ([SKPaymentQueue canMakePayments]) { //用户允许app内购
            
            if (productId.length) {
               
                NSLog(@"%@商品正在请求中",productId);
               
                self.goodsRequestFinished = NO; //正在请求
               
                NSArray *product = [[NSArray alloc] initWithObjects:productId, nil];
                
                NSSet *set = [NSSet setWithArray:product];
               
                SKProductsRequest *productRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:set];
               
                productRequest.delegate = self;
               
                [productRequest start];
            
            } else {
               
                NSLog(@"商品为空");
                
                [self filedWithErrorCode:IAP_FILEDCOED_EMPTYGOODS error:nil];
                
                self.goodsRequestFinished = YES; //完成请求
            }
        
        } else { //没有权限
            
            [self filedWithErrorCode:IAP_FILEDCOED_NORIGHT error:nil];
            
            self.goodsRequestFinished = YES; //完成请求
        }
    
    } else {

        NSLog(@"上次请求还未完成，请稍等");
    }
}

- (void)requestOnceProductWithId:(NSString *)productId{
    self.onceProduct = YES;
    [self requestProductWithId:productId];
}

#pragma mark SKProductsRequestDelegate 查询成功后的回调
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {

    NSArray *product = response.products;
    
    if (product.count == 0) {
        
        NSLog(@"无法获取商品信息，请重试");
        
        [self filedWithErrorCode:IAP_FILEDCOED_CANNOTGETINFORMATION error:nil];
        
        self.goodsRequestFinished = YES; //失败，请求完成

    } else {
        //发起购买请求
        SKPayment *payment = [SKPayment paymentWithProduct:product[0]];
       
        [[SKPaymentQueue defaultQueue] addPayment:payment];
    }
}

#pragma mark SKProductsRequestDelegate 查询失败后的回调
- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    
    [self filedWithErrorCode:IAP_FILEDCOED_APPLECODE error:[error localizedDescription]];
    
    self.goodsRequestFinished = YES; //失败，请求完成
}

#pragma Mark 购买操作后的回调
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(nonnull NSArray<SKPaymentTransaction *> *)transactions {

    for (SKPaymentTransaction *transaction in transactions) {
       
        switch (transaction.transactionState) {
           
            case SKPaymentTransactionStatePurchasing://正在交易
               
                break;

            case SKPaymentTransactionStatePurchased://交易完成
                if (!self.onceProduct) {
                    //单次购买到这此已经是购买成功了不需要再验证
                    
                     [self getReceipt]; //获取交易成功后的购买凭证
                    
                     [self saveReceipt]; //存储交易凭证
                    
                     [self checkIAPFiles];//把self.receipt发送到服务器验证是否有效
                }else{
                    
                    if (self.delegate && [self.delegate respondsToSelector:@selector(onceProductPaySuccess:)]) {
                        [self.delegate onceProductPaySuccess:YES];
                    }
                }
                [self completeTransaction:transaction];
                
                break;

            case SKPaymentTransactionStateFailed://交易失败
                if (self.onceProduct) {
                    if (self.delegate && [self.delegate respondsToSelector:@selector(onceProductPaySuccess:)]) {
                        [self.delegate onceProductPaySuccess:NO];
                    }
                }
                [self failedTransaction:transaction];
                
                break;

            case SKPaymentTransactionStateRestored://已经购买过该商品
                if (self.onceProduct) {
                    if (self.delegate && [self.delegate respondsToSelector:@selector(onceProductPaySuccess:)]) {
                        [self.delegate onceProductPaySuccess:NO];
                    }
                }else{
                    [self getReceipt]; //获取交易成功后的购买凭证
                    
                    [self saveReceipt]; //存储交易凭证
                    
                    [self checkIAPFiles];//把self.receipt发送到服务器验证是否有效
                    
                }
                
                [self restoreTransaction:transaction];
                
                break;
           
            default:
               
                break;
        }
    }
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    
    self.goodsRequestFinished = YES; //成功，请求完成
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}


- (void)failedTransaction:(SKPaymentTransaction *)transaction {

    NSLog(@"transaction.error.code = %ld", transaction.error.code);

    if(transaction.error.code != SKErrorPaymentCancelled) {

        [self filedWithErrorCode:IAP_FILEDCOED_BUYFILED error:nil];

    } else {

        [self filedWithErrorCode:IAP_FILEDCOED_USERCANCEL error:nil];
    }

    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
   
    self.goodsRequestFinished = YES; //失败，请求完成

}


- (void)restoreTransaction:(SKPaymentTransaction *)transaction {
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    
    self.goodsRequestFinished = YES; //恢复购买，请求完成

}

#pragma mark 获取交易成功后的购买凭证

- (void)getReceipt {

    NSURL *receiptUrl = [[NSBundle mainBundle] appStoreReceiptURL];
    
    NSData *receiptData = [NSData dataWithContentsOfURL:receiptUrl];
   
    self.receipt = [receiptData base64EncodedStringWithOptions:0];
}

#pragma mark  持久化存储用户购买凭证(这里最好还要存储当前日期，用户id等信息，用于区分不同的凭证)
-(void)saveReceipt {

    self.date = [NSDate chindDateFormate:[NSDate date]];
    
    NSString *fileName = [NSString uuid];
   
    self.userId = @"UserID";
   
    NSString *savedPath = [NSString stringWithFormat:@"%@/%@.plist", [SandBoxHelper iapReceiptPath], fileName];
    
    NSDictionary *dic =[NSDictionary dictionaryWithObjectsAndKeys:
                        self.receipt,                           receiptKey,
                        self.date,                              dateKey,
                        self.userId,                            userIdKey,
                        nil];
   
    NSLog(@"%@",savedPath);
    
    [dic writeToFile:savedPath atomically:YES];
}

#pragma mark 将存储到本地的IAP文件发送给服务端 验证receipt失败,App启动后再次验证
- (void)checkIAPFiles{

    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSError *error = nil;
   
    //搜索该目录下的所有文件和目录
    NSArray *cacheFileNameArray = [fileManager contentsOfDirectoryAtPath:[SandBoxHelper iapReceiptPath] error:&error];
    
    if (error == nil) {
       
        for (NSString *name in cacheFileNameArray) {
            
            if ([name hasSuffix:@".plist"]){ //如果有plist后缀的文件，说明就是存储的购买凭证
               
                NSString *filePath = [NSString stringWithFormat:@"%@/%@", [SandBoxHelper iapReceiptPath], name];
                
                [self sendAppStoreRequestBuyPlist:filePath];
            }
        }
    
    } else {
       
        NSLog(@"AppStoreInfoLocalFilePath error:%@", [error domain]);
    }
}

-(void)sendAppStoreRequestBuyPlist:(NSString *)plistPath {

    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:plistPath];

    //这里的参数请根据自己公司后台服务器接口定制，但是必须发送的是持久化保存购买凭证
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [dic objectForKey:receiptKey],          receiptKey,
                                   [dic objectForKey:dateKey],             dateKey,
                                   [dic objectForKey:userIdKey],           userIdKey,
                                   nil];

    if ([params allKeys].count == 0) {
        return;
    }
    
    NSDictionary *dict = @{@"receipt-data":[dic objectForKey:receiptKey],
                           @"password":@"70900af3c88e4d38b73f1ba93d2c5964"
                           };
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];//申明请求的数据是json类型
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", @"text/plain",@"image/png",nil];

//    NSString *buy = @"https://sandbox.itunes.apple.com/verifyReceipt";
    NSString *buy = @"https://buy.itunes.apple.com/verifyReceipt";
    
#if defined(DEBUG)||defined(_DEBUG)
    buy = @"https://sandbox.itunes.apple.com/verifyReceipt";
#endif
    [manager POST:buy parameters:dict headers:nil progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"----------验证购买凭证成功--------------");
        [self removeReceipt];
        if ([responseObject[@"status"] integerValue] == 0) {
            NSArray *latest_receipt_arr = responseObject[@"latest_receipt_info"];
            if (latest_receipt_arr.count) {
                NSDictionary *latest_receipt = latest_receipt_arr.firstObject;
                NSInteger expires_date_ms = [latest_receipt[@"expires_date_ms"] integerValue];
                NSInteger now_data_ms = [self getNowTimeTimestamp];
                if ([[latest_receipt allKeys] containsObject:@"cancellation_date_ms"]) {
                    //退款了
                    [SandBoxHelper setVipStatus:@"0"];
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"BuyFaild" object:nil];
                    
                }else{
                    if (expires_date_ms > now_data_ms) {
                        BOOL is_in_intro_offer_period = [latest_receipt[@"is_in_intro_offer_period"] boolValue];//是不是首单优惠
                        BOOL is_trial_period = [latest_receipt[@"is_trial_period"] boolValue];//是不是免费试用
                        NSString *type = latest_receipt[@"product_id"];
                        if ([type isEqualToString:@"clean_vip_weak"]) {
                            type = @"1";
                        }else if([type isEqualToString:@"celan_vip_month"]) {
                            type = @"2";
                        }else{
                            type = @"3";
                        }
//#define vip_month @"celan_vip_month" //包月
//#define vip_quarter @"celan_vip_quarter" //包季
//                        )
//                                          isEqualToString:@"seal_vip_week"] ? @"2" : @"1"; //1包月 2包年
                        [SandBoxHelper setVipStatus:type];
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"BuySuccess" object:nil];
                    }else{
                        [SandBoxHelper setVipStatus:@"0"];
                        [[NSNotificationCenter defaultCenter] postNotificationName:@"BuyFaild" object:nil];
                    }
                }
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"----------验证购买凭证失败--------------");
               [[NSNotificationCenter defaultCenter] postNotificationName:@"BuyFaild" object:nil];
    }];
    
    
}

- (NSInteger)getNowTimeTimestamp{
    
    NSDate *datenow = [NSDate date];//现在时间,你可以输出来看下是什么格式
    
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[datenow timeIntervalSince1970]];
    
    return  (long)[datenow timeIntervalSince1970] * 1000;
    
}

- (NSString *)ConvertStrToTime:(NSString *)timeStr

{
    
    long long time=[timeStr longLongValue]/1000;
    //    如果服务器返回的是13位字符串，需要除以1000，否则显示不正确(13位其实代表的是毫秒，需要除以1000)
    //    long long time=[timeStr longLongValue] / 1000;
    
    NSDate *date = [[NSDate alloc]initWithTimeIntervalSince1970:time];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString*timeString=[formatter stringFromDate:date];
    
    return timeString;
    
}


//验证成功就从plist中移除凭证
-(void)removeReceipt{
   
    NSFileManager *fileManager = [NSFileManager defaultManager];
   
    if ([fileManager fileExistsAtPath:[SandBoxHelper iapReceiptPath]]) {
        
        [fileManager removeItemAtPath:[SandBoxHelper iapReceiptPath] error:nil];
    
    }
}


#pragma mark 错误信息反馈
- (void)filedWithErrorCode:(NSInteger)code error:(NSString *)error {

    if (self.delegate && [self.delegate respondsToSelector:@selector(filedWithErrorCode:andError:)]) {
        switch (code) {
            case IAP_FILEDCOED_APPLECODE:
                [self.delegate filedWithErrorCode:IAP_FILEDCOED_APPLECODE andError:error];
                break;

                case IAP_FILEDCOED_NORIGHT:
                [self.delegate filedWithErrorCode:IAP_FILEDCOED_NORIGHT andError:nil];
                break;

            case IAP_FILEDCOED_EMPTYGOODS:
                [self.delegate filedWithErrorCode:IAP_FILEDCOED_EMPTYGOODS andError:nil];
                break;

            case IAP_FILEDCOED_CANNOTGETINFORMATION:
                 [self.delegate filedWithErrorCode:IAP_FILEDCOED_CANNOTGETINFORMATION andError:nil];
                break;

            case IAP_FILEDCOED_BUYFILED:
                 [self.delegate filedWithErrorCode:IAP_FILEDCOED_BUYFILED andError:nil];
                break;

            case IAP_FILEDCOED_USERCANCEL:
                 [self.delegate filedWithErrorCode:IAP_FILEDCOED_USERCANCEL andError:nil];
                break;

            default:
                break;
        }
    }
}

- (void)refreshOrder{
    
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}


@end
