//
//  NSString+category.h
//  IAPDemo
//
//  Created by Charles.Yao on 2016/10/31.
//  Copyright © 2016年 com.pico. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (category)

+ (NSString *)uuid;

@end
