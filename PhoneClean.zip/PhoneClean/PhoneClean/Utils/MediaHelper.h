//
//  MediaHelper.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MediaHelper : UIView

- (NSArray *)getDataByIndex:(NSInteger)index
                 completion:(void (^)(BOOL success, NSArray *array))completion;

@end

NS_ASSUME_NONNULL_END
