//
//  DeviceInfo.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DeviceInfo : NSObject

/**
 应用名称

 @return 应用名称
 */
+ (NSString *)applicationDisplayName;

/**
 应用版本号

 @return 应用版本号
 */
+ (NSString *)applicationVersion;
/**
 总内存大小

 @return 总内存大小
 */
+ (long long)totalMemorySize;

+ (NSString *)totalMemorySizeString;
/**
 手机可用内存

 @return  手机可用内存
 */
+ (long long)availableMemorySize;
+ (NSString *)availableMemorySizeString;
/**
 总磁盘容量

 @return 总磁盘容量
 */
+ (long long)totalDiskSize;
+ (NSString *)totalDiskSizeString;

/**
 可用磁盘空间

 @return 可用磁盘空间
 */
+ (long long)availableDiskSize;
+ (NSString *)availableDiskSizeString;

/**
 已经使用
 
 @return 已经使用磁盘空间
 */
+ (long long)usedDiskSize;
+ (NSString *)usedDiskSizeString;


+ (NSDictionary *)getDivceSizeAndUserSize ;


@end

NS_ASSUME_NONNULL_END
