//
//  ContactHelper.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ContactHelper : NSObject


//总共条数
@property (nonatomic, assign) NSInteger totalSaveSpace;

+ (ContactHelper *)shareManager;


@property (nonatomic, assign) BOOL clean;

- (NSArray *)getContactArray;
- (NSArray *)getAllDelArray;
- (void)updateInfo:(id)info
             event:(BOOL)event;


- (void)cleanAction:(void (^)(BOOL success, NSError *error))completion;

// 停止扫描
- (void)stopLoadPhoto;

- (void)loadContactWithProcess:(void (^)(NSInteger current, NSInteger total,NSString *currentName))process
             completionHandler:(void (^)(BOOL success, NSError *error))completion;

@end

NS_ASSUME_NONNULL_END
