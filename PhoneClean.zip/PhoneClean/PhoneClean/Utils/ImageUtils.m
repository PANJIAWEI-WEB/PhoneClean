//
//  ImageUtils.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "ImageUtils.h"
#import "ImageCompare.h"
#import <sys/sysctl.h>

#import <mach/mach.h>

@interface ImageUtils()<PHPhotoLibraryChangeObserver>

@property (nonatomic, strong, readwrite) NSMutableArray *similarArr;
@property (nonatomic, strong, readwrite) NSDictionary *similarInfo;
@property (nonatomic, strong, readwrite) NSMutableArray *screenshotsArr;
@property (nonatomic, strong, readwrite) NSDictionary *screenshotsInfo;
@property (nonatomic, strong, readwrite) NSMutableArray *thinPhotoArr;
@property (nonatomic, strong, readwrite) NSDictionary *thinPhotoInfo;
@property (nonatomic, strong, readwrite) NSMutableArray *midPhotoArr;
@property (nonatomic, strong, readwrite) NSMutableArray *sameDateArr;
@property (nonatomic, strong, readwrite) NSMutableArray *dimDateArr;


//相似图片所有数据
@property (nonatomic, strong, readwrite) NSMutableArray *allSimilarArray;
//需要删除(处理的)的数据
@property (nonatomic, strong, readwrite) NSMutableArray *deleteDimArray;
@property (nonatomic, strong, readwrite) NSMutableArray *deleteSimilarArray;
@property (nonatomic, strong, readwrite) NSMutableArray *deleteScreenshotsArray;
@property (nonatomic, strong, readwrite) NSMutableArray *deleteThinArray;



@property (nonatomic, assign, readwrite) double totalSaveSpace;
@property (nonatomic, assign) NSUInteger similarSaveSpace; //相似
@property (nonatomic, assign) NSUInteger screenshotsSaveSpace; //截屏
@property (nonatomic, assign) NSUInteger dimSaveSpace;  //模糊
@property (nonatomic, assign) NSUInteger thinPhotoSaveSpce; //瘦身

@property (nonatomic, strong) PHFetchResult *assetArr;
@property (nonatomic, strong) PHImageRequestOptions *sizeOpt;
@property (nonatomic, strong) PHImageRequestOptions *imageOpt;
@property (nonatomic, strong) PHAsset *lastAsset;
@property (nonatomic, strong) UIImage *lastImage;
@property (nonatomic, strong) NSData *lastImageData;
@property (nonatomic, assign) BOOL lastSame;
@property (nonatomic, assign) NSUInteger tag;

@property (nonatomic, copy) void (^completionHandler)(BOOL success, NSError *error);
@property (nonatomic, copy) void (^processHandler)(NSInteger current, NSInteger total,NSString *currentName);

@property (nonatomic, assign)BOOL isStop;
@property (nonatomic, assign)BOOL theSame;

@end


@implementation ImageUtils


+ (ImageUtils *)shareManager{
    static ImageUtils *mgr = nil;
    static dispatch_once_t token;
    dispatch_once(&token, ^{
        mgr = [[ImageUtils alloc] init];
        mgr.isStop = NO;
    });
    return mgr;
}



#pragma mark - LibraryChange 相册变换通知

- (instancetype)init {
    self = [super init];
    if (self) {
        [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];
        _tag = 0;
    }
    return self;
}

- (void)dealloc {
    [[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
}

- (void)photoLibraryDidChange:(PHChange *)changeInstance {
    // 筛选出没必要的变动
    PHFetchResultChangeDetails *collectionChanges =
    [changeInstance changeDetailsForFetchResult:self.assetArr];
    if (collectionChanges == nil || self.notificationStatus != WKPhotoNotificationStatusDefualt) {
        return;
    }
    WeakSelf(weakSelf)
    dispatch_async(dispatch_get_main_queue(), ^{
        StrongSelf(strongSelf)
        if ([strongSelf.delegate respondsToSelector:@selector(clearPhotoLibraryDidChange)]) {
            [strongSelf.delegate clearPhotoLibraryDidChange];
        }
    });
}

#pragma mark - GetImage 获取图片

// 加载照片
- (void)loadPhotoWithProcess:(void (^)(NSInteger current, NSInteger total,NSString *currentName))process
           completionHandler:(void (^)(BOOL success, NSError *error))completion {
    [self resetTagData];
    self.lastAsset = nil;
    self.processHandler = process;
    self.completionHandler = completion;
    self.isStop = NO;
    // 获取当前App的相册授权状态
    PHAuthorizationStatus authorizationStatus = [PHPhotoLibrary authorizationStatus];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(didReceiveMemoryWarning:)
                                                 name:UIApplicationDidReceiveMemoryWarningNotification
                                               object:nil];
    // 判断授权状态
    if (authorizationStatus == PHAuthorizationStatusAuthorized) {
        // 如果已经授权, 获取图片
        [self getAllAsset];
    }
    // 如果没决定, 弹出指示框, 让用户选择
    else if (authorizationStatus == PHAuthorizationStatusNotDetermined) {
        WeakSelf(weakSelf)
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            // 如果用户选择授权, 则获取图片
            if (status == PHAuthorizationStatusAuthorized) {
                [weakSelf getAllAsset];
            }
        }];
    } else {
        [self noticeAlert];
    }
}

// 获取相簿中的PHAsset对象
- (void)getAllAsset {
    // 获取所有资源的集合，并按资源的创建时间排序
    PHFetchOptions *options = [[PHFetchOptions alloc] init];
    options.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate"
                                                              ascending:NO]];
    PHFetchResult *result = [PHAsset fetchAssetsWithOptions:options];
    self.assetArr = result;
    
    [self requestImageWithIndex:0];
}

// 获取图片
- (void)requestImageWithIndex:(NSInteger)index {
    
    
    if (index >= self.assetArr.count || index>=4000) {
        [self loadCompletion];
        self.completionHandler(YES, nil);
        return;
    }
    
    if (self.isStop == YES) {
        [self stopLoadPhoto];
        return;
    }
    
    // 筛选本地图片，过滤视频、iCloud图片
    PHAsset *asset = self.assetArr[index];
    NSString *filename = [asset valueForKey:@"filename"];
    NSLog(@"process:%d   name:照片优化  %@",index,filename);
    
    self.totalSaveSpace = self.similarSaveSpace + self.thinPhotoSaveSpce + self.screenshotsSaveSpace + self.dimSaveSpace;
    self.processHandler(index, self.assetArr.count<4000? self.assetArr.count : 4000, filename);
    
    if (asset.mediaType != PHAssetMediaTypeImage || asset.sourceType != PHAssetSourceTypeUserLibrary) {
        [self requestImageWithIndex:index+1];
        return;
    }
    
    // 获取缩率图
    PHImageManager *mgr = [PHImageManager defaultManager];
    __weak typeof(self) weakSelf = self;
    [mgr requestImageForAsset:asset
                   targetSize:CGSizeMake(125, 125)
                  contentMode:PHImageContentModeDefault
                      options:self.imageOpt
                resultHandler:^(UIImage *result, NSDictionary *info) {
                    [weakSelf getImageSizeWithIndex:index
                                              image:result];
                }];
}

// 获取原图片大小
- (void)getImageSizeWithIndex:(NSInteger)index
                        image:(UIImage *)image {
    __weak typeof(self) weakSelf = self;
    PHImageManager *mgr = [PHImageManager defaultManager];
    [mgr requestImageDataForAsset:self.assetArr[index]
                          options:self.sizeOpt
                    resultHandler:^(NSData * _Nullable imageData, NSString * _Nullable dataUTI, UIImageOrientation orientation, NSDictionary * _Nullable info) {
                        [weakSelf dealImageWithIndex:index
                                               image:image
                                           imageData:imageData];
                    }];
}

#pragma mark - DealImage 处理图片

// 处理相片
- (void)dealImageWithIndex:(NSInteger)index
                     image:(UIImage *)image
                 imageData:(NSData *)imageData {
    //    NSLog(@"原图 %.2fM，缩率图 %@", imageData.length/M_KB/M_KB, NSStringFromCGSize(image.size));
    
    PHAsset *asset = self.assetArr[index];
    BOOL isSameDay = [self isSameDay:self.lastAsset.creationDate
                               date2:asset.creationDate];
    // 相似图片
    if (self.lastAsset && isSameDay) {
        //      BOOL isLike = [GetSimilarity getSimilarityValueWithImgA:self.lastImage ImgB:image] > 0.9;
        
        if (image ==nil) {
            [self requestImageWithIndex:index+1];
            return;
        }
//        NSDictionary *itemDict = @{ @"asset" : asset,
//                                    @"image" : image,
//                                    @"imageData" : imageData,
//                                    @"imageSize" : @(imageData.length) };
        
//        [self.midPhotoArr addObject:itemDict];
        
        BOOL isLike = NO;
        @try {
            //执行的代码，如果异常,就会抛出，程序不继续执行啦
           isLike = [ImageCompare isImage:self.lastImage likeImage:image];
        } @catch (NSException *exception) {
            //捕获异常
        } @finally {
            //这里一定执行，无论你异常与否
        }
        
        if (isLike) {
            [self updateSimilarArrWithAsset:asset image:image imageData:imageData];
            self.lastSame = YES;
        } else {
            self.lastSame = NO;
        }
        
    } else {
    }
    
    //模糊图片
    [self dealDimPhotoWithAsset:asset image:image imageData:imageData];
    
    
    // 截屏图片
    if (asset.mediaSubtypes == PHAssetMediaSubtypePhotoScreenshot) {
        NSDictionary *lastDict = self.screenshotsArr.lastObject;
        if (lastDict && !isSameDay) {
            lastDict = nil;
        }
        [self updateScreenShotsWithAsset:asset
                                   image:image
                               imageData:imageData
                                lastDict:lastDict];
    }
    
    // 照片瘦身
    [self dealThinPhotoWithAsset:asset
                           image:image
                       imageData:imageData];
    
    self.lastAsset = asset;
    self.lastImage = image;
    self.lastImageData = imageData;
    [self requestImageWithIndex:index+1];
}

// 更新相似图片数据
- (void)updateSimilarArrWithAsset:(PHAsset *)asset
                            image:(UIImage *)image
                        imageData:(NSData *)imageData {
    NSDictionary *lastDict = self.similarArr.lastObject;
    if (!self.lastSame) {
        lastDict = nil;
    }
    
    if (!lastDict) {
        NSDictionary *itemDict = @{ @"asset" : self.lastAsset,
//                                    @"image" : self.lastImage,
//                                    @"imageData" : self.lastImageData,
                                    @"imageSize" : @(self.lastImageData.length) };
        NSString *keyStr = [self stringWithDate:asset.creationDate];
        lastDict = @{keyStr : [@[itemDict] mutableCopy]};
        [self.sameDateArr addObject:lastDict];
    }
    
    self.similarSaveSpace = self.similarSaveSpace + imageData.length;
    NSMutableArray *itemArr = lastDict.allValues.lastObject;
    NSDictionary *itemDict = @{ @"asset" : asset,
//                                @"image" : image,
//                                @"imageData" : self.lastImageData,
                                @"imageSize" : @(imageData.length)};
    [itemArr addObject:itemDict];
    lastDict = @{lastDict.allKeys.lastObject : itemArr};
    [self.sameDateArr replaceObjectAtIndex:self.sameDateArr.count-1
                               withObject:lastDict];
}

// 更新截屏图片数据
- (void)updateScreenShotsWithAsset:(PHAsset *)asset
                             image:(UIImage *)image
                         imageData:(NSData *)imageData
                          lastDict:(NSDictionary *)lastDict{
    if (!asset | !image | !imageData ) {
        return;
    }
    NSDictionary *itemDict = @{ @"asset" : asset,
//                                @"image" : image,
//                                @"imageData" : imageData,
                                @"imageSize" : @(imageData.length) };
    if (!lastDict) {
        NSString *keyStr = [self stringWithDate:asset.creationDate];
        lastDict = @{keyStr : [@[itemDict] mutableCopy]};
        [self.screenshotsArr addObject:lastDict];
    } else {
        NSMutableArray *itemArr = lastDict.allValues.lastObject;
        if (!itemArr) {
            return;
        }
        [itemArr addObject:itemDict];
        lastDict = @{lastDict.allKeys.lastObject : itemArr};
        [self.screenshotsArr replaceObjectAtIndex:self.screenshotsArr.count-1
                                       withObject:lastDict];
    }
    self.screenshotsSaveSpace = self.screenshotsSaveSpace + imageData.length;
}

// 处理瘦身图片
- (void)dealThinPhotoWithAsset:(PHAsset *)asset
                         image:(UIImage *)image
                     imageData:(NSData *)imageData {
    if (!asset | !image | !imageData ) {
        return;
    }
    
    if (imageData.length < [ConfigModel imageMaxSize]) {
        return;
    }
    if (!asset) {
        return;
    }
    NSDictionary *itemDict = @{ @"asset" : asset,
//                                @"image" : image,
//                                @"imageData" : imageData,
                                @"imageSize" : @(imageData.length)};
    [self.thinPhotoArr addObject:itemDict];
    
    self.thinPhotoSaveSpce = self.thinPhotoSaveSpce + (imageData.length - M_KB * M_KB);
}


// 处理模糊图片
- (void)dealDimPhotoWithAsset:(PHAsset *)asset
                         image:(UIImage *)image
                     imageData:(NSData *)imageData{
    
    if (!asset | !image | !imageData ) {
        return;
    }
    if ([ImageCompare isDimImage:image] && asset) {
        NSDictionary *itemDict = @{ @"asset" : asset,
//                                    @"image" : image,
//                                    @"imageData" : imageData,
                                    @"imageSize" : @(imageData.length)};
        [self.dimDateArr addObject:itemDict];
        self.dimSaveSpace = self.dimSaveSpace + imageData.length;
    }
}


// 重置数据
- (void)resetTagData {
    self.clean = YES;
    self.similarArr = nil;
    self.similarInfo = nil;
    self.similarSaveSpace = 0;
    
    self.screenshotsArr = nil;
    self.screenshotsInfo = nil;
    self.thinPhotoSaveSpce = 0;
    
    self.thinPhotoArr = nil;
    self.thinPhotoInfo = nil;
    self.screenshotsSaveSpace = 0;
    
    [self.dimDateArr removeAllObjects];
    self.dimSaveSpace = 0;
    
    self.sameDateArr = nil;
    self.totalSaveSpace = 0;
    _theSame = NO;
    
    
    [self.deleteThinArray removeAllObjects];
    [self.deleteDimArray removeAllObjects];
    [self.deleteScreenshotsArray removeAllObjects];
    [self.deleteSimilarArray removeAllObjects];
    [self.allSimilarArray removeAllObjects];
}

// 加载完成
- (void)loadCompletion {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
    self.similarInfo = [self getInfoWithDataArr:self.sameDateArr
                                      saveSpace:self.similarSaveSpace];
    self.screenshotsInfo = [self getInfoWithDataArr:self.screenshotsArr
                                          saveSpace:self.screenshotsSaveSpace];
    if (self.thinPhotoArr.count > 0) {
        
        self.thinPhotoInfo = @{@"count" : @(self.thinPhotoArr.count),
                               @"saveSpace" : @(self.thinPhotoSaveSpce)};
    }else{
        
        self.thinPhotoInfo = @{@"count" : @(0),
                               @"saveSpace" : @(0)};
    }
    self.totalSaveSpace = self.similarSaveSpace + self.thinPhotoSaveSpce + self.screenshotsSaveSpace + self.dimSaveSpace;
    
    NSLog(@"相似照片可省 ：%.2fMB", self.similarSaveSpace / M_KB / (CGFloat)M_KB);
    NSLog(@"截屏照片可省 ：%.2fMB", self.screenshotsSaveSpace / M_KB / (CGFloat)M_KB);
    NSLog(@"压缩照片可省 ：%.2fMB", self.thinPhotoSaveSpce / M_KB / (CGFloat)M_KB);
    NSLog(@"模糊照片可省 ：%.2fMB", self.dimSaveSpace / M_KB / (CGFloat)M_KB);
    NSLog(@"图片 扫描完成");
    
    //需要删除的模糊数据
    [self.deleteDimArray removeAllObjects];
    [self.deleteDimArray addObjectsFromArray:self.dimDateArr];
    
    
    [self.deleteThinArray removeAllObjects];
    [self.deleteThinArray addObjectsFromArray:self.thinPhotoArr];
    
    [self.deleteScreenshotsArray removeAllObjects];
    for (NSDictionary *dict in self.screenshotsArr) {
        NSArray *array = [dict allValues].firstObject;
        [self.deleteScreenshotsArray addObjectsFromArray:array];
    }
    
    //相似数据
    [self.deleteSimilarArray removeAllObjects];
    [self.allSimilarArray removeAllObjects];
    for (NSDictionary *dict in self.sameDateArr) {
        NSArray *array = [dict allValues].firstObject;
        
        for (NSDictionary *data in array) {
            if (![self.allSimilarArray containsObject:data]) {
                [self.allSimilarArray addObject:data];
            }
        }
        [self.deleteSimilarArray addObject:array.lastObject];
    }
    
    
    self.totalSaveSpace = self.similarSaveSpace + self.thinPhotoSaveSpce + self.screenshotsSaveSpace + self.dimSaveSpace;
    
    
}

#pragma mark - Private 私有方法

- (NSDictionary *)getInfoWithDataArr:(NSArray *)dataArr
                           saveSpace:(NSUInteger)saveSpace {
    NSUInteger similarCount = 0;
    for (NSDictionary *dict in dataArr) {
        NSArray *arr = dict.allValues.lastObject;
        similarCount = similarCount + arr.count;
    }
    return @{@"count":@(similarCount), @"saveSpace" : @(saveSpace)};
}

// 是否为同一天
- (BOOL)isSameDay:(NSDate *)date1 date2:(NSDate *)date2 {
    if (!date1 || !date2) {
        return NO;
    }
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay;
    NSDateComponents *comp1 = [calendar components:unitFlags fromDate:date1];
    NSDateComponents *comp2 = [calendar components:unitFlags fromDate:date2];
    return  [comp1 day] == [comp2 day] &&
    [comp1 month] == [comp2 month] &&
    [comp1 year]  == [comp2 year];
}

// NSDate转NSString
- (NSString *)stringWithDate:(NSDate *)date {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy年MM月dd日"];
    return [dateFormatter stringFromDate:date];
}

// 开启权限提示
- (void)noticeAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"此功能需要相册授权"
                                        message:@"请您在设置系统中打开授权开关"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *left = [UIAlertAction actionWithTitle:@"取消"
                                                   style:UIAlertActionStyleCancel
                                                 handler:nil];
    UIAlertAction *right = [UIAlertAction actionWithTitle:@"前往设置"
                                                    style:UIAlertActionStyleDefault
                                                  handler:^(UIAlertAction * _Nonnull action) {
                                                      NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                                                      [[UIApplication sharedApplication] openURL:url];
                                                  }];
    [alert addAction:left];
    [alert addAction:right];
    UIViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc presentViewController:alert animated:YES completion:nil];
}

#pragma mark - Getter 懒加载
- (NSMutableArray *)dimDateArr{
    if (!_dimDateArr) {
        _dimDateArr = [NSMutableArray array];
    }
    return _dimDateArr;
}
- (NSMutableArray *)similarArr {
    if (!_similarArr) {
        _similarArr = [NSMutableArray array];
    }
    return _similarArr;
}

- (NSMutableArray *)screenshotsArr {
    if (!_screenshotsArr) {
        _screenshotsArr = [NSMutableArray array];
    }
    return _screenshotsArr;
}

- (NSMutableArray *)thinPhotoArr {
    if (!_thinPhotoArr) {
        _thinPhotoArr = [NSMutableArray array];
    }
    return _thinPhotoArr;
}

- (NSMutableArray *)sameDateArr {
    if (!_sameDateArr) {
        _sameDateArr = [NSMutableArray array];
    }
    return _sameDateArr;
}

- (NSMutableArray *)midPhotoArr {
    if (!_midPhotoArr) {
        _midPhotoArr = [NSMutableArray array];
    }
    return _midPhotoArr;
}


- (PHImageRequestOptions *)imageOpt {
    if (!_imageOpt) {
        _imageOpt = [[PHImageRequestOptions alloc] init];
        // resizeMode 属性控制图像的剪裁
        _imageOpt.resizeMode = PHImageRequestOptionsResizeModeNone;
        // deliveryMode 则用于控制请求的图片质量
        _imageOpt.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
    }
    return _imageOpt;
}

- (PHImageRequestOptions *)sizeOpt {
    if (!_sizeOpt) {
        _sizeOpt = [[PHImageRequestOptions alloc] init];
        _sizeOpt.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
        _sizeOpt.resizeMode = PHImageRequestOptionsResizeModeExact;
    }
    return _sizeOpt;
}

- (NSMutableArray *)deleteDimArray{
    if (!_deleteDimArray) {
        _deleteDimArray = [NSMutableArray array];
    }
    return _deleteDimArray;
}
- (NSMutableArray *)deleteSimilarArray{
    if (!_deleteSimilarArray) {
        _deleteSimilarArray = [NSMutableArray array];
    }
    return _deleteSimilarArray;
}
- (NSMutableArray *)deleteScreenshotsArray{
    if (!_deleteScreenshotsArray) {
        _deleteScreenshotsArray = [NSMutableArray array];
    }
    return _deleteScreenshotsArray;
}
- (NSMutableArray *)deleteThinArray{
    if (!_deleteThinArray) {
        _deleteThinArray = [NSMutableArray array];
    }
    return _deleteThinArray;
}
- (NSMutableArray *)allSimilarArray{
    if (!_allSimilarArray) {
        _allSimilarArray = [NSMutableArray array];
    }
    return _allSimilarArray;
}
#pragma mark - DeleteImage 删除图片

/// 删除照片
+ (void)deleteAssets:(NSArray<PHAsset *> *)assets completionHandler:(void (^)(BOOL success, NSError *error))completion {
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
        [PHAssetChangeRequest deleteAssets:assets];
    } completionHandler:^(BOOL success, NSError * _Nullable error) {
        if (completion) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(success, error);
            });
        }
    }];
}

// 获取原图
+ (void)getOriginImageWithAsset:(PHAsset *)asset completionHandler:(void (^)(UIImage *result, NSDictionary *info))completion {
    PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
    options.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
    options.resizeMode = PHImageRequestOptionsResizeModeExact;
    PHImageManager *mgr = [PHImageManager defaultManager];
    [mgr requestImageForAsset:asset
                   targetSize:PHImageManagerMaximumSize
                  contentMode:PHImageContentModeDefault
                      options:options
                resultHandler:completion];
}

#pragma mark - 图片压缩

+ (void)compressImage:(UIImage *)image
            imageSize:(NSUInteger)imageSize
    completionHandler:(void (^)(UIImage *compressImg, NSUInteger compresSize))completion {
    // 子线程压缩
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSDictionary *imgDict = [self compressImage:image imageSize:imageSize];
        //获取主线程
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) {
                completion(imgDict[@"image"], [imgDict[@"length"] unsignedIntegerValue]);
            }
        });
    });
}

// 压缩图片1 小于1.5M -- 先压缩大小再压缩数据
+ (NSDictionary *)compressImage:(UIImage *)image imageSize:(NSUInteger)imageSize {
    //    NSLog(@"图片压缩前 data: 0MB, size:%@",  NSStringFromCGSize(image.size));
    // 压缩率
    CGFloat rate = M_KB * M_KB / imageSize;
    
    // 数据压缩
    NSData *data = UIImageJPEGRepresentation(image, rate);
    UIImage *img = [UIImage imageWithData:data];
    //    NSLog(@"数据压缩后 data: %.2fMB, size:%@", data.length / M_KB / M_KB, NSStringFromCGSize(img.size));
    
    if (data.length > [ConfigModel imageMaxSize]) {
        // 大小压缩
        CGSize size = CGSizeMake(image.size.width * rate, image.size.height * rate);
        UIImage *img2 = [self imageWithImage:img scaledToSize:size];
        NSData *data2 = UIImageJPEGRepresentation(img2, 1);
        //        NSLog(@"大小压缩后 data: %.2fMB, size:%@", data2.length / M_KB / M_KB, NSStringFromCGSize(img2.size));
        if (data2.length > [ConfigModel imageMaxSize]) {
            return [self compressImage:img2 imageSize:data2.length];
        } else {
            return @{@"image":img2, @"length":@(data2.length)};
        }
    } else {
        return @{@"image":img, @"length":@(data.length)};
    }
}

+ (void)compressImageWithData:(NSData *)imageData
            completionHandler:(void (^)(UIImage *compressImg, NSUInteger compresSize))completion {
    // 子线程压缩
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSDictionary *imgDict = [self compressData:imageData];
        //获取主线程
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) {
                completion(imgDict[@"image"], [imgDict[@"length"] unsignedIntegerValue]);
            }
        });
    });
}


// 压缩图片2 小于1.5M -- 先压缩大小再压缩数据
+ (NSDictionary *)compressData:(NSData *)imageData {
    NSUInteger imageSize = imageData.length;
    UIImage *image = [UIImage imageWithData:imageData];
    //    NSLog(@"图片压缩前 data: %.2fMB, size:%@", imageData.length / M_KB / M_KB, NSStringFromCGSize(image.size));
    
    // 压缩率
    CGFloat rate = M_KB * M_KB / imageSize;
    
    // 大小压缩
    CGSize size = CGSizeMake(image.size.width * rate, image.size.height * rate);
    UIImage *img2 = [self imageWithImage:image scaledToSize:size];
    NSData *data2 =  UIImageJPEGRepresentation(img2, 1);
    //    NSLog(@"大小压缩后 data: %.2fMB, size:%@", data2.length / M_KB / M_KB, NSStringFromCGSize(size));
    if (data2.length > M_KB * M_KB * 1.5) {
        // 数据压缩
        NSData *data = UIImageJPEGRepresentation(img2, rate);
        UIImage *img = [UIImage imageWithData:data];
        //        NSLog(@"数据压缩后 data: %.2fMB, size:%@", data.length / M_KB / M_KB, NSStringFromCGSize(img.size));
        if (data.length > M_KB * M_KB * 1.5) {
            return [self compressData:data];
        } else {
            return @{@"image":img, @"length":@(data.length)};
        }
    } else {
        return @{@"image":img2, @"length":@(data2.length)};
    }
}

// 压缩大小
+ (UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize {
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

+ (void)tipWithMessage:(NSString *)str {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"提示"
                                        message:str
                                 preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action =
    [UIAlertAction actionWithTitle:@"确定"
                             style:UIAlertActionStyleCancel
                           handler:nil];
    [alert addAction:action];
    
    UIViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc presentViewController:alert animated:YES completion:nil];
}

- (void)stopLoadPhoto {
    self.isStop = YES;
    [self loadCompletion];
    if (self.completionHandler) {
        self.completionHandler(YES, nil);
    }
}

-(void)didReceiveMemoryWarning:(id)sender {
    [[[UIApplication sharedApplication] keyWindow] makeToast:@"图片扫描由于内存警告结束" duration:3.0f position:@"bottom"];
    [self stopLoadPhoto];
}







#pragma mark - 删除数据相关处理
//获取当前种类所有图片
- (NSMutableArray *)getImageDataByType:(ImageCleanType)type{
    
    switch (type) {
        case ImageCleanDim:
            return self.dimDateArr;
            break;
            
        case ImageCleanTypeSimilar:
            return self.allSimilarArray;
            break;
            
        case ImageCleanThinPhoto:
            return self.thinPhotoArr;
            break;
            
        case ImageCleanTypeScreenshots:{
            
            
            NSMutableArray *array = [NSMutableArray array];
            for (NSDictionary *dict in self.screenshotsArr) {
                NSArray *temp = [dict allValues].firstObject;
                [array addObjectsFromArray:temp];
            }
            return array;
            
        }
            break;
        default:
            return [@[] mutableCopy];
            break;
    }
    
}

//获取当前种类选中删除
- (NSMutableArray *)getDeletedImageByType:(ImageCleanType)type{
    switch (type) {
        case ImageCleanDim:
            return self.deleteDimArray;
            break;
            
        case ImageCleanTypeSimilar:
            return self.deleteSimilarArray;
            break;
            
        case ImageCleanThinPhoto:
            return self.deleteThinArray;
            break;
            
        case ImageCleanTypeScreenshots:
            return self.deleteScreenshotsArray;
            break;
        default:
            return [@[] mutableCopy];
            break;
    }
}

//更新当前种类需要删除内容
- (void)updateDeletedInfo:(id)info
                 withType:(ImageCleanType)type{
    
    switch (type) {
        case ImageCleanDim:{
            if([self.deleteDimArray containsObject:info]){
                [self.deleteDimArray removeObject:info];
                self.dimSaveSpace -= [info[@"imageSize"] integerValue];
            }else{
                [self.deleteDimArray addObject:info];
                self.dimSaveSpace += [info[@"imageSize"] integerValue];
            }
        } break;
            
        case ImageCleanTypeSimilar:{
            if([self.deleteSimilarArray containsObject:info]){
                [self.deleteSimilarArray removeObject:info];
                self.similarSaveSpace -= [info[@"imageSize"] integerValue];
            }else{
                [self.deleteSimilarArray addObject:info];
                self.similarSaveSpace += [info[@"imageSize"] integerValue];
            }
        } break;
            
        case ImageCleanThinPhoto:{
            
            if([self.deleteThinArray containsObject:info]){
                [self.deleteThinArray removeObject:info];
                self.thinPhotoSaveSpce -= [info[@"imageSize"] integerValue];
            }else{
                [self.deleteThinArray addObject:info];
                self.thinPhotoSaveSpce += [info[@"imageSize"] integerValue];
            }
        }break;
            
        case ImageCleanTypeScreenshots:{
            if([self.deleteScreenshotsArray containsObject:info]){
                [self.deleteScreenshotsArray removeObject:info];
                self.screenshotsSaveSpace -= [info[@"imageSize"] integerValue];
            }else{
                [self.deleteScreenshotsArray addObject:info];
                self.screenshotsSaveSpace += [info[@"imageSize"] integerValue];
            }
        }break;
        default:
            
            break;
    }
    
    self.totalSaveSpace = self.similarSaveSpace + self.thinPhotoSaveSpce + self.screenshotsSaveSpace + self.dimSaveSpace;
}


- (NSUInteger)getSizeByType:(ImageCleanType)type{
    switch (type) {
        case ImageCleanDim:
            return self.dimSaveSpace;
            break;
            
        case ImageCleanTypeSimilar:
            return self.similarSaveSpace;
            break;
            
        case ImageCleanThinPhoto:
            return self.thinPhotoSaveSpce;
            break;
            
        case ImageCleanTypeScreenshots:
            return self.screenshotsSaveSpace;
            break;
        default:
            return self.totalSaveSpace;
            break;
    }
}



- (void)getOriginImageWithAsset:(PHAsset *)asset completionHandler:(void (^)(UIImage * _Nonnull, NSDictionary * _Nonnull))completion
{
    PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
    // deliveryMode 则用于控制请求的图片质量
    options.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
    // resizeMode 属性控制图像的剪裁
    options.resizeMode = PHImageRequestOptionsResizeModeExact;
    
    // 原图
    PHImageManager *imageManager = [PHImageManager defaultManager];
    [imageManager requestImageForAsset:asset targetSize:PHImageManagerMaximumSize contentMode:PHImageContentModeDefault options:options resultHandler:completion];
}
- (void)dealLargeImage:(NSInteger) index{
    if (self.deleteThinArray.count > index) {
        //图片处理
        NSDictionary *dict = self.deleteThinArray[index];
        
//        [PHImageManager defaultManager] requestImageForAsset:<#(nonnull PHAsset *)#> targetSize:<#(CGSize)#> contentMode:<#(PHImageContentMode)#> options:<#(nullable PHImageRequestOptions *)#> resultHandler:<#^(UIImage * _Nullable result, NSDictionary * _Nullable info)resultHandler#>
        
        PHAssetResource * resource = [[PHAssetResource assetResourcesForAsset: dict[@"asset"]] firstObject];
        // file:///var/mobile/Media/DCIM/165APPLE/IMG_5225.MOV
        NSString *tempPrivateFileURL = [resource valueForKey:@"privateFileURL"];
        // IMG_5225.MOV
        NSString * tempFilename = resource.originalFilename;
        
        NSLog(@"fileName %@",tempFilename);
        
        [self getOriginImageWithAsset:dict[@"asset"] completionHandler:^(UIImage * _Nonnull image, NSDictionary * _Nonnull info) {
            //压缩图片
            
            [ImageUtils compressImage:image imageSize:[dict[@"imageSize"] integerValue] completionHandler:^(UIImage *compressImg, NSUInteger compresSize) {
                
                
                [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
                    
                } completionHandler:^(BOOL success, NSError * _Nullable error) {
                    
                }];
                
                
               BOOL result =  [UIImageJPEGRepresentation(compressImg, 1) writeToURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",tempPrivateFileURL]] atomically:NO];
                if (result) {
                    NSLog(@"success");
                }else{
                    NSLog(@"failed");
                }
                
                NSLog(@"%@ %d",tempPrivateFileURL,compresSize);
            
            }];
            
            
        }];
        
    }else{
        
    }
    
}
- (NSArray *)cleanArray{
    NSMutableArray *array = [NSMutableArray array];
    
    //压缩文件
    NSMutableArray *deleteArray = [NSMutableArray array];
    [deleteArray addObjectsFromArray:self.deleteThinArray];
    [deleteArray addObjectsFromArray:self.deleteDimArray];
    [deleteArray addObjectsFromArray:self.deleteSimilarArray];
    [deleteArray addObjectsFromArray:self.deleteScreenshotsArray];
    
    for (NSDictionary *dict in deleteArray) {
        if (![array containsObject:dict]) {
            [array addObject:dict];
        }
    }
    return array;
}

- (void)cleanAction:(void (^)(BOOL success, NSUInteger size))completion{
    NSMutableArray *array = [[self cleanArray] mutableCopy];
    
    if (!self.clean) {
        completion(YES,0);
        return;
    }
    
    [self cleanAll:array completion:completion];
    
    //删除
//    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
////            [PHAssetChangeRequest deleteAssets:@[dict[@"asset"]]];
//        NSMutableArray *del = [NSMutableArray array];
//        for (NSDictionary *dict in array) {
//            [del addObject:dict[@"asset"]];
//        }
//        [PHAssetChangeRequest deleteAssets:del];
//    } completionHandler:^(BOOL success, NSError * _Nullable error) {
//
//        NSUInteger delSize = 0;
//        if (success) {
//            NSMutableArray *tempArray = [array mutableCopy];
//            for (NSDictionary *dict in tempArray) {
//
//                if (![array containsObject:dict]) {
//                    delSize += [dict[@"imageSize"] integerValue];
//                }
//            }
//        }
//        completion(YES, delSize);
////            [weakSelf deleInfo:array index:(index+ 1)];
//    }];
    
    
}


- (void)cleanAll:(NSArray *)array
      completion:(void (^)(BOOL success, NSUInteger size))completion{
    //删除
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
//            [PHAssetChangeRequest deleteAssets:@[dict[@"asset"]]];
        NSMutableArray *del = [NSMutableArray array];
        for (NSDictionary *dict in array) {
            [del addObject:dict[@"asset"]];
        }
        [PHAssetChangeRequest deleteAssets:del];
    } completionHandler:^(BOOL success, NSError * _Nullable error) {
        
        NSUInteger delSize = 0;
        if (success) {
            NSMutableArray *tempArray = [array mutableCopy];
            for (NSDictionary *dict in array) {
                [tempArray removeObject:dict];
                if (![tempArray containsObject:dict]) {
                    
                    if ([dict[@"imageSize"] integerValue] > 0) {
                        delSize += [dict[@"imageSize"] integerValue];
                    }else{
                        delSize += [dict[@"size"] integerValue];
                    }
                    
                }
            }
        }
        completion(YES, delSize);
//            [weakSelf deleInfo:array index:(index+ 1)];
    }];
}


@end
