//
//  MediaHelper.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "MediaHelper.h"

#import <Photos/Photos.h>
#import <AssetsLibrary/AssetsLibrary.h>
@interface MediaHelper()

@property (nonatomic, strong) PHImageRequestOptions *sizeOpt;
@property (nonatomic, strong) NSMutableArray *resultArray;
@property (nonatomic, strong) NSMutableArray *infoArray;
@property (nonatomic, assign) BOOL photo;

@property (nonatomic, copy) void (^completionHandler)(BOOL success, NSArray *array);
@end
@implementation MediaHelper
-(NSMutableArray *)infoArray{
    if (!_infoArray) {
        _infoArray = [NSMutableArray array];
    }
    return _infoArray;
}
-(NSMutableArray *)resultArray{
    if (!_resultArray) {
        _resultArray = [NSMutableArray array];
    }
    return _resultArray;
}
- (NSArray *)getDataByIndex:(NSInteger)index completion:(nonnull void (^)(BOOL success, NSArray *array))completion{
    self.completionHandler = completion;
    [self.infoArray removeAllObjects];
    [self.resultArray removeAllObjects];
    
    NSInteger type = 206;
    switch (index) {
        case 0:
            type = 210;
            break;
        case 1:
            type = 213;
            break;
        case 2:
            type = 201;
            break;
        case 3:
            type = 2;
            break;
        case 4:
            type = 207;
            break;
        case 5:
            type = 211;
            break;
        case 6:
            type = 214;
            break;
        case 7:
            type = 202;
            break;
        case 8:
            type = 2;
            break;
            
        default:
            break;
    }
    
    self.photo = (index < 7);
    
    
    
    PHFetchResult *smartAlbums = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeAny options:nil];
    PHFetchResult *userAlbums = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAny options:nil];
    
    
    NSArray *allAlbums = @[smartAlbums,userAlbums];
    
    
    PHFetchOptions *options = [[PHFetchOptions alloc] init];
    
    // 同步获得图片, 只会返回1张图片
    //    options.synchronous = YES;
    // 获得某个相簿中的所有PHAsset对象
    if (index > 6) { //self.mediaType == MEDIA_VIDEO
        options.predicate = [NSPredicate predicateWithFormat:@"mediaType == %ld",PHAssetMediaTypeVideo];
    }else{
        options.predicate = [NSPredicate predicateWithFormat:@"mediaType == %ld",PHAssetMediaTypeImage];
    }
    
    
    options.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO]];
    for (PHFetchResult *fetchResult in allAlbums) {
        for (PHAssetCollection *collection in fetchResult) {
            // 有可能是PHCollectionList类的的对象，过滤掉
            if (![collection isKindOfClass:[PHAssetCollection class]]) continue;
            // 过滤空相册
            if (collection.estimatedAssetCount <= 0) continue;
            
            if (collection.assetCollectionSubtype == PHAssetCollectionSubtypeSmartAlbumAllHidden) continue;
//            if (collection.assetCollectionSubtype == 215) continue;
//            if (collection.assetCollectionSubtype == 212) continue;
//            if (collection.assetCollectionSubtype == 204) continue;
//            if (collection.assetCollectionSubtype == 1000000201) continue;
            
            if (collection.assetCollectionSubtype == type) {
                NSString *albumName = collection.localizedTitle;
                NSLog(@"info :%@",albumName);
                PHFetchResult *result = [PHAsset fetchAssetsInAssetCollection:collection options:options];
                
                if(result.count > 0){
                    for (PHAsset *asset in result) {
                        [self.resultArray addObject:asset];
                    }
                }
            }
        }
    }
    
    
//数据处理，获取文件大小
    if (self.resultArray.count > 0) {
        [self dealArray:0 photo:self.photo];
    }else{
        self.completionHandler(YES, self.infoArray);
    }
   
    
    
    return nil;
}

- (void)dealArray:(NSInteger)count
            photo:(BOOL)photo
{
    if (self.photo) {
        PHImageManager *mgr = [PHImageManager defaultManager];
        if (count < self.resultArray.count) {
            PHAsset *asset = self.resultArray[count];
            WeakSelf(weakSelf)
            [mgr requestImageDataForAsset:asset
                                  options:self.sizeOpt
                            resultHandler:^(NSData * _Nullable imageData, NSString * _Nullable dataUTI, UIImageOrientation orientation, NSDictionary * _Nullable info) {
                
                NSDictionary *itemDict = @{ @"asset" : asset,
                                            @"size" : @(imageData.length) };
                
                [weakSelf addData:itemDict index:count+1];
//                [weakSelf.infoArray addObject:itemDict];
//                [weakSelf dealArray:count+1 photo:photo];
            }];
        }else{
            self.completionHandler(YES, self.infoArray);
        }
    }else{
        PHVideoRequestOptions *options = [[PHVideoRequestOptions alloc] init];
        options.version = PHImageRequestOptionsVersionCurrent;
        options.deliveryMode = PHVideoRequestOptionsDeliveryModeAutomatic;
        
        
        if (count < self.resultArray.count) {
            PHAsset *asset = self.resultArray[count];
            WeakSelf(weakSelf)
            [[PHImageManager defaultManager] requestAVAssetForVideo:asset options:options resultHandler:^(AVAsset * _Nullable ast, AVAudioMix * _Nullable audioMix, NSDictionary * _Nullable info) {
                
                AVURLAsset* urlAsset = (AVURLAsset*)ast;
                
                NSNumber *size;
                [urlAsset.URL getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
                
                NSDictionary *itemDict = @{ @"asset" : asset,
                                            @"size" : size };
                
                [weakSelf addData:itemDict index:count+1];
//                [weakSelf.infoArray addObject:itemDict];
//                [weakSelf dealArray:count+1 photo:photo];
                
            }];
        }else{
            self.completionHandler(YES, self.infoArray);
            
        }
    }
   
}

- (void)addData:(NSDictionary *)dict index:(NSInteger)index{
    
    [self.infoArray addObject:dict];
    [self dealArray:index photo:self.photo];
    
}

- (PHImageRequestOptions *)sizeOpt {
    if (!_sizeOpt) {
        _sizeOpt = [[PHImageRequestOptions alloc] init];
        _sizeOpt.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
        _sizeOpt.resizeMode = PHImageRequestOptionsResizeModeExact;
    }
    return _sizeOpt;
}


@end
