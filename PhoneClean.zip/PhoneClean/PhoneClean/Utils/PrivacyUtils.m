//
//  PrivacyUtils.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "PrivacyUtils.h"
#import <AVFoundation/AVFoundation.h>            //相机/麦克风
#import <Photos/Photos.h>                        //相册
#import <Contacts/Contacts.h>                    //通讯录iOS9以后  之前用//#import <AddressBook/AddressBook.h>
#import <EventKit/EventKit.h>
#import <MediaPlayer/MediaPlayer.h>


//这里需要注意，我们最好写成这种形式（防止低版本找不到头文件出现问题）
#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h> //通知
#endif


#define IOS10_OR_LATER  ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0)
#define IOS9_OR_LATER   ([[[UIDevice currentDevice] systemVersion] floatValue] >= 9.0)
#define IOS8_OR_LATER   ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define IOS7_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)


@interface PrivacyUtils ()<UNUserNotificationCenterDelegate>

//隐私权限状态回调block
@property(nonatomic,copy) ResultBlock block;



/*
 * 提示
 */
@property(nonatomic,strong) NSString *tipStr;


@end
@implementation PrivacyUtils

+(instancetype)shareInstance
{
    static PrivacyUtils *share = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (share ==nil)
        {
            share = [[PrivacyUtils alloc]init];
        }
    });
    return share;
}

/**
 获取权限
 
 @param type 类型
 @param isPushSetting 是否跳转设置界面开启权限 (为NO时 只提示信息)
 @param ResultBlock 回调
 */
- (void)CheckPrivacyAuthWithType:(PrivacyType)type isPushSetting:(BOOL)isPushSetting withHandle:(ResultBlock)ResultBlock{

    self.block = ResultBlock;
    switch (type) {
            
        case PrivacyType_Photos:
        {   // 相册
            _tipStr = @"请在iPhone的“设置-隐私-相册”选项中开启权限";
            [self Auth_Photos:isPushSetting];
        }
            break;
        case PrivacyType_Camera:
        {   // 相机
            _tipStr = @"请在iPhone的“设置-隐私-相机”选项中开启权限";
            [self Auth_Camera:isPushSetting];
        }
            break;
            break;
        case PrivacyType_Contacts:
        {   // 通讯录
            _tipStr = @"请在iPhone的“设置-隐私-通讯录”选项中开启权限";
            [self Auth_Contacts:isPushSetting];
        }
            break;
        case PrivacyType_Calendars:
        {   // 日历
            _tipStr = @"请在iPhone的“设置-隐私-日历”选项中开启权限";
            [self Auth_Calendars:isPushSetting];
        }
            break;
        case PrivacyType_Reminders:
        {    // 提醒事项
            _tipStr = @"请在iPhone的“设置-隐私-提醒事项”选项中开启权限";
            [self Auth_Reminders:isPushSetting];
        }
    
            break;
        default:
            break;
    }

}

#pragma mark - 相册权限
- (void)Auth_Photos:(BOOL)isPushSetting{
    
    __weak typeof(self) weakSelf = self;
    PHAuthorizationStatus authStatus = [PHPhotoLibrary authorizationStatus];
    switch (authStatus) {
        case PHAuthorizationStatusNotDetermined:
            {   //第一次进来
                [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
                    if (status == PHAuthorizationStatusAuthorized) {
                        weakSelf.block(YES, AuthStatus_Authorized);
                    } else {
                        weakSelf.block(NO, AuthStatus_Denied);
                        [self pushSetting:isPushSetting]; //拒绝时跳转或提示
                    }
                }];
            }
            break;
        case PHAuthorizationStatusRestricted:
        {    //未授权，家长限制
            weakSelf.block(NO, AuthStatus_Restricted);
           [self pushSetting:isPushSetting]; //拒绝时跳转或提示
          
        }
            break;
        case PHAuthorizationStatusDenied:
        {   //拒绝
            weakSelf.block(NO, AuthStatus_Denied);
            [self pushSetting:isPushSetting]; //拒绝时跳转或提示
        }
            break;
        case PHAuthorizationStatusAuthorized:
        {   //已授权
            weakSelf.block(YES, AuthStatus_Authorized);
        }
            break;
            
        default:
            break;
    }
    

    
}

#pragma mark - 相机权限
- (void)Auth_Camera:(BOOL)isPushSetting{
    
    __weak typeof(self) weakSelf = self;
    
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        switch (authStatus) {
            case AVAuthorizationStatusNotDetermined:
            {   //第一次进来
                [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                    
                    if (granted == YES) {
                        weakSelf.block(YES, AuthStatus_Authorized);
                    }else{
                        weakSelf.block(NO, AuthStatus_Denied);
                        [self pushSetting:isPushSetting]; //拒绝时跳转或提示
                    }
                }];
            }
                break;
            case AVAuthorizationStatusRestricted:
            {   //未授权，家长限制
                weakSelf.block(NO, AuthStatus_Restricted);
               [self pushSetting:isPushSetting]; //拒绝时跳转或提示
            }
                break;
            case AVAuthorizationStatusDenied:
            {   //拒绝
                weakSelf.block(NO, AuthStatus_Denied);
                [self pushSetting:isPushSetting]; //拒绝时跳转或提示
            }
                break;
            case AVAuthorizationStatusAuthorized:
            {   //已授权
                weakSelf.block(YES, AuthStatus_Authorized);
            }
                break;
            default:
                break;
        }
        
        
        
    }else{
        //硬件不支持
        weakSelf.block(NO, AutStatus_NotSupport);
        
         NSLog(@" 硬件不支持 ");
        
//         [MSProgressHUD showText:@"硬件不支持"];
    }
    
}

#pragma mark - 通讯录权限
- (void)Auth_Contacts:(BOOL)isPushSetting{
    
    __weak typeof(self) weakSelf = self;
    CNAuthorizationStatus authStatus = [CNContactStore authorizationStatusForEntityType:CNEntityTypeContacts];
    switch (authStatus) {
        case CNAuthorizationStatusNotDetermined:
        {   //第一次进来
            CNContactStore *store = [[CNContactStore alloc] init];
            [store requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError * _Nullable error) {
                if (granted == YES) {
                    weakSelf.block(YES, AuthStatus_Authorized);
                }else{
                    weakSelf.block(NO, AuthStatus_Denied);
                     [self pushSetting:isPushSetting]; //拒绝时跳转或提示
                }
            }];
        }
            break;
        case CNAuthorizationStatusRestricted:
        {   //未授权，家长限制
            weakSelf.block(NO, AuthStatus_Restricted);
            [self pushSetting:isPushSetting]; //拒绝时跳转或提示
        }
            break;
        case CNAuthorizationStatusDenied:
        {   //拒绝
            weakSelf.block(NO, AuthStatus_Denied);
            [self pushSetting:isPushSetting]; //拒绝时跳转或提示
        }
            break;
        case CNAuthorizationStatusAuthorized:
        {   //已授权
            weakSelf.block(YES, AuthStatus_Authorized);
        }
            break;
        default:
            break;
    }
 

}
#pragma mark - 日历权限
- (void)Auth_Calendars:(BOOL)isPushSetting{
    
    __weak typeof(self) weakSelf = self;
    EKEntityType type  = EKEntityTypeEvent;
    EKAuthorizationStatus authStatus = [EKEventStore authorizationStatusForEntityType:type];
    switch (authStatus) {
        case EKAuthorizationStatusNotDetermined:
        {   //第一次进来
            EKEventStore *eventStore = [[EKEventStore alloc] init];
            [eventStore requestAccessToEntityType:type completion:^(BOOL granted, NSError * _Nullable error) {
                if (granted == YES) {
                    weakSelf.block(YES, AuthStatus_Authorized);
                }else{
                    weakSelf.block(NO, AuthStatus_Denied);
                    [self pushSetting:isPushSetting]; //拒绝时跳转或提示
                }
            }];
            
        }
            break;
        case EKAuthorizationStatusRestricted:
        {   //未授权，家长限制
            weakSelf.block(NO, AuthStatus_Restricted);
            [self pushSetting:isPushSetting]; //拒绝时跳转或提示
        }
            break;
        case EKAuthorizationStatusDenied:
        {   //拒绝
            weakSelf.block(NO, AuthStatus_Denied);
           [self pushSetting:isPushSetting]; //拒绝时跳转或提示
        }
            break;
        case EKAuthorizationStatusAuthorized:
        {   //已授权
            weakSelf.block(YES, AuthStatus_Authorized);
        }
            break;
        default:
            break;
    }
    
    
    
}

#pragma mark - 提醒事项权限
- (void)Auth_Reminders:(BOOL)isPushSetting{
    
    __weak typeof(self) weakSelf = self;
    EKEntityType type  = EKEntityTypeReminder;
    EKAuthorizationStatus authStatus = [EKEventStore authorizationStatusForEntityType:type];
    switch (authStatus) {
        case EKAuthorizationStatusNotDetermined:
        {   //第一次进来
            EKEventStore *eventStore = [[EKEventStore alloc] init];
            [eventStore requestAccessToEntityType:type completion:^(BOOL granted, NSError * _Nullable error) {
                if (granted == YES) {
                    weakSelf.block(YES, AuthStatus_Authorized);
                }else{
                    weakSelf.block(NO, AuthStatus_Denied);
                    [self pushSetting:isPushSetting]; //拒绝时跳转或提示
                }
            }];

        }
            break;
        case EKAuthorizationStatusRestricted:
        {   //未授权，家长限制
            weakSelf.block(NO, AuthStatus_Restricted);
            [self pushSetting:isPushSetting]; //拒绝时跳转或提示
        }
            break;
        case EKAuthorizationStatusDenied:
        {   //拒绝
            weakSelf.block(NO, AuthStatus_Denied);
            [self pushSetting:isPushSetting]; //拒绝时跳转或提示
        }
            break;
        case EKAuthorizationStatusAuthorized:
        {   //已授权
            weakSelf.block(YES, AuthStatus_Authorized);
        }
            break;
        default:
            break;
    }
    
}



#pragma mark - 跳转设置
- (void)pushSetting:(BOOL)isPushSetting{
    
    if(isPushSetting ==YES){
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"未开启权限" message:[NSString stringWithFormat:@"%@",_tipStr] preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        }];
        [alert addAction:cancelAction];
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"去设置" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            NSURL *url= [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if (IOS10_OR_LATER) {
                if( [[UIApplication sharedApplication]canOpenURL:url] ) {
                    [[UIApplication sharedApplication]openURL:url options:@{}completionHandler:^(BOOL        success) {
                    }];
                }
            }else{
                if( [[UIApplication sharedApplication]canOpenURL:url] ) {
                    [[UIApplication sharedApplication]openURL:url];
                }
            }
        }];
        [alert addAction:okAction];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [[PrivacyUtils getCurrentVC] presentViewController:alert animated:YES completion:nil];
            
        });
        
        
    }else{
        
        NSLog(@" 可以添加弹框,弹框的提示信息:%@ ",_tipStr);
        
        //     [MSProgressHUD showText:_tipStr];
        
        
        
    }
    
    
}

#pragma mark - 获取当前VC
+ (UIViewController *)getCurrentVC
{
    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    UIViewController *currentVC = [self getCurrentVCFrom:rootViewController];
    return currentVC;
}
+ (UIViewController *)getCurrentVCFrom:(UIViewController *)rootVC
{
    UIViewController *currentVC;
    if ([rootVC presentedViewController]) {
        // 视图是被presented出来的
        rootVC = [rootVC presentedViewController];
    }
    if ([rootVC isKindOfClass:[UITabBarController class]]) {
        // 根视图为UITabBarController
        currentVC = [self getCurrentVCFrom:[(UITabBarController *)rootVC selectedViewController]];
        
    } else if ([rootVC isKindOfClass:[UINavigationController class]]){
        // 根视图为UINavigationController
        currentVC = [self getCurrentVCFrom:[(UINavigationController *)rootVC visibleViewController]];
        
    } else {
        // 根视图为非导航类
        currentVC = rootVC;
    }
    return currentVC;
}




#pragma mark - 检测通知权限状态
- (void)CheckNotificationAuthWithisPushSetting:(BOOL)isPushSetting;{
    
    _tipStr = @"请在iPhone的“设置-通知-”选项中开启通知权限";
    
    if (IOS10_OR_LATER) {
        //iOS 10 later
        [[UNUserNotificationCenter currentNotificationCenter] getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
            if (settings.authorizationStatus == UNAuthorizationStatusDenied)
            {
                 NSLog(@" 通知权限 - 没开启 IOS10以后 ");
                [self pushSetting:isPushSetting];

                
            }else{
                NSLog(@" 通知权限 - 开了 IOS10以后  ");
            }
        }];
    }else if (IOS8_OR_LATER){
        UIUserNotificationSettings *settings = [[UIApplication sharedApplication] currentUserNotificationSettings];
        if(settings.types == UIUserNotificationTypeNone){
            NSLog(@" 通知权限 - 没开启 IOS8-iOS10 ");
            [self pushSetting:isPushSetting];
            
        }else{
            NSLog(@" 通知权限 - 开了 IOS8-iOS10 ");
        }
        
    }else{
        UIRemoteNotificationType type = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
        if (type == UIUserNotificationTypeNone)
        {
            NSLog(@" 通知权限 - 没开启 IOS8以下 ");
            [self pushSetting:isPushSetting];
            
        }else{
            NSLog(@" 通知权限 - 开了 IOS8以下 ");
        }

    }
    
    
    
}


#pragma mark - 注册通知
+ (void)RequestNotificationAuth{
    
    UIApplication *application = [UIApplication sharedApplication];
    if (IOS10_OR_LATER) {
        //iOS 10 later
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        //必须写代理，不然无法监听通知的接收与点击事件
        center.delegate = self;
        [center requestAuthorizationWithOptions:(UNAuthorizationOptionBadge | UNAuthorizationOptionSound | UNAuthorizationOptionAlert) completionHandler:^(BOOL granted, NSError * _Nullable error) {
            if (!error && granted) {
                //用户点击允许
                NSLog(@"注册ios10以上的通知 成功");
            }else{
                //用户点击不允许
                NSLog(@"注册ios10以上的通知 失败");
            }
        }];
        
        // 可以通过 getNotificationSettingsWithCompletionHandler 获取权限设置
        //之前注册推送服务，用户点击了同意还是不同意，以及用户之后又做了怎样的更改我们都无从得知，现在 apple 开放了这个 API，我们可以直接获取到用户的设定信息了。注意UNNotificationSettings是只读对象哦，不能直接修改！
        [center getNotificationSettingsWithCompletionHandler:^(UNNotificationSettings * _Nonnull settings) {
            NSLog(@"========%@",settings);
        }];
    }else if (IOS8_OR_LATER){
        //iOS 8 - iOS 10系统
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound categories:nil];
        [application registerUserNotificationSettings:settings];
        
    }else{
        //iOS 8.0系统以下
        [application registerForRemoteNotificationTypes:UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound];
        
    }
    
    
    
}
@end
