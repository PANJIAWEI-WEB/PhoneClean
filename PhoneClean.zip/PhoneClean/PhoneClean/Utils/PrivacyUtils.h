//
//  PrivacyUtils.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN



typedef NS_ENUM(NSInteger, PrivacyType)
{
    PrivacyType_Contacts                 ,    // 通讯录
    PrivacyType_Calendars                ,    // 日历
    PrivacyType_Reminders                ,    // 提醒事项
    PrivacyType_Photos                   ,    // 照片
    PrivacyType_Camera                   ,    // 相机

};

//对应类型权限状态，参考PHAuthorizationStatus等
typedef NS_ENUM(NSInteger, AuthStatus)
{
    /** 用户从未进行过授权等处理，首次访问相应内容会提示用户进行授权 */
    AuthStatus_NotDetermined  = 0,
    /** 已授权 */
    AuthStatus_Authorized     = 1,
    /** 拒绝 */
    AuthStatus_Denied         = 2,
    /** 应用没有相关权限，且当前用户无法改变这个权限，比如:家长控制 */
    AuthStatus_Restricted     = 3,
    /** 硬件等不支持 */
    AutStatus_NotSupport     = 4,
    
};

/**
 对应类型隐私权限状态回调block

 @param granted 是否授权
 @param status 授权的具体状态
 */
typedef void (^ResultBlock) (BOOL granted,AuthStatus status);

/// 权限请求
@interface PrivacyUtils : NSObject

+(instancetype)shareInstance;
@property (nonatomic, assign) PrivacyType PrivacyType;
@property (nonatomic, assign) AuthStatus AuthStatus;


/**
 检查和请求对应类型的隐私权限

 @param type 类型
 @param isPushSetting 当拒绝时是否跳转设置界面开启权限 (为NO时 只提示信息)
 @param ResultBlock 对应类型状态回调
 */
- (void)CheckPrivacyAuthWithType:(PrivacyType)type
                   isPushSetting:(BOOL)isPushSetting
                      withHandle:(ResultBlock)ResultBlock;



/**
 检测通知权限状态

 @param isPushSetting 当拒绝时是否跳转设置界面开启权限 (为NO时 只提示信息)
 */
- (void)CheckNotificationAuthWithisPushSetting:(BOOL)isPushSetting;


/**
 注册通知
 */
+(void)RequestNotificationAuth;
@end

NS_ASSUME_NONNULL_END
