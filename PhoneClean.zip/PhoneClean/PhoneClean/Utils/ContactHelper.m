//
//  ContactHelper.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "ContactHelper.h"
#import <Contacts/Contacts.h>
#import <AddressBook/AddressBook.h>

@interface ContactHelper()

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, copy) void (^completionHandler)(BOOL success, NSError *error);
@property (nonatomic, copy) void (^processHandler)(NSInteger current, NSInteger total,NSString *currentName);


@property (nonatomic, strong) NSMutableArray *sameArray;
@property (nonatomic, strong) NSMutableArray *nilArray;
@property (nonatomic, strong) NSMutableArray *deleteArray;

@property (nonatomic, assign)BOOL isStop;

@end

@implementation ContactHelper


+ (ContactHelper *)shareManager{
    static ContactHelper *mgr = nil;
    static dispatch_once_t token;
    dispatch_once(&token, ^{
        mgr = [[ContactHelper alloc] init];
//        mgr.isStop = NO;
    });
    return mgr;
}

-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (NSMutableArray *)sameArray{
    if (!_sameArray) {
        _sameArray = [NSMutableArray array];
    }
    return _sameArray;
}
- (NSMutableArray *)nilArray{
    if (!_nilArray) {
        _nilArray = [NSMutableArray array];
    }
    return _nilArray;
}
-(NSMutableArray *)deleteArray{
    if (!_deleteArray) {
        _deleteArray = [NSMutableArray array];
    }
    return _deleteArray;
}
- (void)loadContactWithProcess:(void (^)(NSInteger, NSInteger, NSString * _Nonnull))process completionHandler:(void (^)(BOOL, NSError * _Nonnull))completion{
    [self.dataArray removeAllObjects];
    [self.sameArray removeAllObjects];
    [self.nilArray removeAllObjects];
    [self.deleteArray removeAllObjects];
    self.isStop = NO;
    self.processHandler = process;
    self.completionHandler = completion;
    self.totalSaveSpace = 0;
    self.clean = YES;
    [self requestContactAuthorAfterSystemVersion9];
}


#pragma mark 请求通讯录权限
- (void)requestContactAuthorAfterSystemVersion9{
    
    CNAuthorizationStatus status = [CNContactStore authorizationStatusForEntityType:CNEntityTypeContacts];
    if (status == CNAuthorizationStatusNotDetermined) {
        CNContactStore *store = [[CNContactStore alloc] init];
        [store requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError*  _Nullable error) {
            if (error) {
                NSLog(@"授权失败");
                [self showAlertViewAboutNotAuthorAccessContact];
            }else {
                NSLog(@"成功授权");
                [self openContact];
            }
        }];
    }
    else if(status == CNAuthorizationStatusRestricted)
    {
        NSLog(@"用户拒绝");
        [self showAlertViewAboutNotAuthorAccessContact];
    }
    else if (status == CNAuthorizationStatusDenied)
    {
        NSLog(@"用户拒绝");
        [self showAlertViewAboutNotAuthorAccessContact];
    }
    else if (status == CNAuthorizationStatusAuthorized)//已经授权
    {
        //有通讯录权限-- 进行下一步操作
        [self openContact];
    }
    
}

//有通讯录权限-- 进行下一步操作
- (void)openContact{
 // 获取指定的字段,并不是要获取所有字段，需要指定具体的字段
    NSArray *keysToFetch = @[CNContactGivenNameKey, CNContactFamilyNameKey, CNContactPhoneNumbersKey];
    CNContactFetchRequest *fetchRequest = [[CNContactFetchRequest alloc] initWithKeysToFetch:keysToFetch];
    CNContactStore *contactStore = [[CNContactStore alloc] init];
    
    
    WeakSelf(weakSelf)
    
    [contactStore enumerateContactsWithFetchRequest:fetchRequest error:nil usingBlock:^(CNContact * _Nonnull contact, BOOL * _Nonnull stop) {
        
        
        [weakSelf.dataArray addObject:contact];
     
        
    }];
    
    
    
    [self dealData];

}

- (void)dealData{
    //判断重复
    NSMutableArray *sameData = [NSMutableArray array];
    
    NSInteger count = self.dataArray.count;
    for (NSInteger i = 0; i < count - 1; i ++) {
        
        if (self.isStop) {
            [self delArray];
            self.completionHandler(YES, nil);
            return;
        }
        
        CNContact *person = self.dataArray[i];
        
        NSString *nameStr = [NSString stringWithFormat:@"%@%@",person.familyName,person.givenName];
        self.processHandler(i, count, nameStr);
        
        if ([sameData containsObject:person]) { //相同 已添加
            continue;
        }
        NSArray *numbers0 = [self numberInfoByContact:person];
        if (numbers0.count == 0) { //无号码联系人
            [self.nilArray addObject:person];
            continue;
        }
        NSMutableArray *tempArray = [NSMutableArray array];
        [tempArray addObject:person];
        
        NSString *sameNumber = @"";
        
        for (NSInteger j = i + 1; j < count; j ++) {
            if ([sameData containsObject:person]) { //相同 已添加
                continue;
            }
           
            CNContact *person1 = self.dataArray[j];
            NSArray *numbers1 = [self numberInfoByContact:person1];
            
            NSString *nameStr = [NSString stringWithFormat:@"%@%@",person.familyName,person.givenName];
            NSLog(@"compare :%@  %@",nameStr,numbers1.firstObject);
            
            NSString *tempNumber = [self judgeSameNumber:numbers0 number1:numbers1];
            
            if (tempNumber.length > 0) {
                
                if ([sameNumber isEqualToString:@""]) {
                    sameNumber = tempNumber;
                }
                
                //相同
                if (![sameData containsObject:person]) {
                    [sameData addObject:person];
                    
                }
                if (![sameData containsObject:person1]) {
                    [sameData addObject:person1];
                }
                //添加
                [tempArray addObject:person1];
            }
            
        }
        
        if (tempArray.count > 1) {
            [self.sameArray addObject:@{sameNumber:tempArray}];
        }
        
    }
    
    self.totalSaveSpace = self.sameArray.count + self.nilArray.count;
    
    [self delArray];
    self.completionHandler(YES, nil);
    
    
    
}


// 停止扫描
- (void)stopLoadPhoto{
    self.isStop = YES;
}
- (NSArray *)numberInfoByContact:(CNContact *)contant{
    
    NSMutableArray *dataArray = [NSMutableArray array];
    
    for (CNLabeledValue *labelValue in contant.phoneNumbers) {
        
        CNPhoneNumber *phoneNumber = labelValue.value;
        
        NSString * string = phoneNumber.stringValue ;
        
        //去除多余符号
        string = [string stringByReplacingOccurrencesOfString:@"+86" withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"-" withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@"(" withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@")" withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        
        [dataArray addObject:string];
    }
    return dataArray;
}

- (NSString *)judgeSameNumber:(NSArray *)numberArray0
                number1:(NSArray *)numberArray1{
    
    NSString *hasSame;
    
    for (NSString *number1 in numberArray0) {
        if ([numberArray1 containsObject:number1]) {
            hasSame = number1;
            break;
        }
    }
    
    return hasSame;
}



//提示没有通讯录权限
- (void)showAlertViewAboutNotAuthorAccessContact{
    
    UIAlertController *alertController = [UIAlertController
        alertControllerWithTitle:@"请授权通讯录权限"
        message:@"请在iPhone的\"设置-隐私-通讯录\"选项中,允许App解访问你的通讯录"
        preferredStyle: UIAlertControllerStyleAlert];

    UIAlertAction *OKAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:OKAction];
    
    UIViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc presentViewController:alertController animated:YES completion:nil];
}



- (NSArray *)getContactArray{
    
    NSMutableArray *array = [NSMutableArray array];
    [array addObjectsFromArray:self.sameArray];
    
    if (self.nilArray.count > 0) {
        [array addObject:@{@"空号码":self.nilArray}];
    }
    return array;
}

- (void)delArray{
    
    [self.deleteArray removeAllObjects];
    for (NSDictionary *dict in self.sameArray) {
        NSArray *number = [dict allValues].firstObject;
        
        NSInteger origin = -1; //源本
        for (NSInteger i = 0; i < number.count; i ++) {
            
            
            CNContact *temp = number[i];
            if (origin < 0) {
                NSString *nameStr = [NSString stringWithFormat:@"%@%@",temp.familyName,temp.givenName];
                if (nameStr.length > 0) {
                    origin = i;
                }
            }
            [self.deleteArray addObject:temp];
        }
        
        if (origin < 0) {
            origin = 0;
        }
        [self.deleteArray removeObject:number[origin]];
        
    }
    
    [self.deleteArray addObjectsFromArray:self.nilArray];
    
}

- (NSArray *)getAllDelArray{
    
   
    return self.deleteArray;
    
   
}
- (void)updateInfo:(id)info
             event:(BOOL)event{
    if ([self.deleteArray containsObject:info]) {
        [self.deleteArray removeObject:info];
    }else{
        [self.deleteArray addObject:info];
    }
    
    self.totalSaveSpace = self.deleteArray.count;
}

- (void)cleanAction:(void (^)(BOOL success, NSError *error))completion{
    
    if (!self.clean) {
        completion(YES,nil);
        return;
    }
    
    
    CNContactStore *store = [[CNContactStore alloc] init];
    //检索条件，检索所有名字中FamilyName包含A的联系人
    
    NSMutableArray *identifiers = [NSMutableArray array];
    for (CNContact *contact in self.deleteArray) {
        [identifiers addObject:contact.identifier];
    }
    
    NSPredicate *predicate = [CNContact predicateForContactsWithIdentifiers:identifiers];
    //提取数据
    NSArray *contacts = [store unifiedContactsMatchingPredicate:predicate keysToFetch:@[CNContactFamilyNameKey] error:nil];
     
    CNSaveRequest *saveRequest = [[CNSaveRequest alloc] init];
    for (CNContact *contact in contacts) {
        CNMutableContact *contact1 = [contact mutableCopy];
        // 删除联系人
        [saveRequest deleteContact:contact1];
    }
    [store executeSaveRequest:saveRequest error:nil];
    
    completion(YES,nil);
}


@end
