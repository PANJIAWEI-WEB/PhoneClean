//
//  ImageCompare.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ImageCompare : NSObject

/// 是否相似
+ (BOOL)isImage:(UIImage *)img0 likeImage:(UIImage *)img1;

/// 获取相似度
+ (float)isImageFloat:(UIImage *)img0 likeImage:(UIImage *)img1;

///是否模糊
+ (BOOL)isDimImage:(UIImage *)img;

///是否是大图
+ (BOOL)isLargerImage:(UIImage *)img;

@end

NS_ASSUME_NONNULL_END
