//
//  ImageUtils.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import <Foundation/Foundation.h>
#import <Photos/Photos.h>
NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, ImageUtilsNotificationStatus) {
    WKPhotoNotificationStatusDefualt  = 0, // 相册变更默认处理
    WKPhotoNotificationStatusClose    = 1, // 相册变更不处理
    WKPhotoNotificationStatusNeed     = 2, // 相册变更主动处理
};
//图片种类
typedef NS_ENUM(NSInteger, ImageCleanType) {
    ImageCleanTypeSimilar           = 0,
    ImageCleanTypeScreenshots       = 1,
    ImageCleanDim                   = 2,
    ImageCleanThinPhoto             = 3,
};

@protocol ImageUtilsDelegate<NSObject>
@optional
/// 相册变动代理方法
- (void)clearPhotoLibraryDidChange;
@end

@interface ImageUtils : NSObject

+ (ImageUtils *)shareManager;

// 代理
@property (nonatomic, weak) id<ImageUtilsDelegate> delegate;

// 变更状态
@property (nonatomic, assign) ImageUtilsNotificationStatus notificationStatus;

// 相似照片数据 [{date1:[dict1,dict2]}, {date2:[dict3,dict4]}...]
@property (nonatomic, strong, readonly) NSMutableArray *similarArr;
// 相似照片信息
@property (nonatomic, strong, readonly) NSDictionary *similarInfo;

// 截图照片数据
@property (nonatomic, strong, readonly) NSMutableArray *screenshotsArr;
// 截图照片信息
@property (nonatomic, strong, readonly) NSDictionary *screenshotsInfo;

// 照片瘦身数据
@property (nonatomic, strong, readonly) NSMutableArray *thinPhotoArr;
// 照片瘦身信息
@property (nonatomic, strong, readonly) NSDictionary *thinPhotoInfo;
// 相同时间段相同的图片
@property (nonatomic, strong, readonly) NSMutableArray *sameDateArr;

// 节约空间 [dict3,dict4,....]
@property (nonatomic, assign, readonly) double totalSaveSpace;

@property (nonatomic, assign)BOOL isPrecise;

// 加载照片
- (void)loadPhotoWithProcess:(void (^)(NSInteger current, NSInteger total,NSString *currentName))process
           completionHandler:(void (^)(BOOL success, NSError *error))completion;

// 删除照片
+ (void)deleteAssets:(NSArray<PHAsset *> *)assets
   completionHandler:(void (^)(BOOL success, NSError *error))completion;

// 获取原图
+ (void)getOriginImageWithAsset:(PHAsset *)asset
              completionHandler:(void (^)(UIImage *result, NSDictionary *info))completion;

/// 压缩照片
+ (void)compressImageWithData:(NSData *)imageData
            completionHandler:(void (^)(UIImage *compressImg, NSUInteger compresSize))completion;

+ (void)tipWithMessage:(NSString *)str;

// 停止扫描
- (void)stopLoadPhoto;

//获取当前种类所有图片
- (NSArray *)getImageDataByType:(ImageCleanType)type;

//获取当前种类选中删除
- (NSArray *)getDeletedImageByType:(ImageCleanType)type;

//更新当前种类需要删除内容
- (void)updateDeletedInfo:(id)info
                 withType:(ImageCleanType)type;

//获取删除大小
- (NSUInteger)getSizeByType:(ImageCleanType)type;


- (void)cleanAction:(void (^)(BOOL success, NSUInteger size))completion;

- (NSArray *)cleanArray;

- (void)cleanAll:(NSArray *)array
      completion:(void (^)(BOOL success, NSUInteger size))completion;



@property (nonatomic, assign) BOOL clean;

@end

NS_ASSUME_NONNULL_END
