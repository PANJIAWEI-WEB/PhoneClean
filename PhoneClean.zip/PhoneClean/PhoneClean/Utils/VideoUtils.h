//
//  VideoUtils.h
//  PhoneClean
//
//  Created by PW on 2021/5/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//图片种类
typedef NS_ENUM(NSInteger, VideoCleanType) {
    VideoCleanTypeSimilar           = 0,
    VideoCleanTypeDamage            = 1,
    VideoCleanLarge                 = 2,
};

@interface VideoUtils : NSObject

+ (VideoUtils *)shareManager;


// 节约空间 [dict3,dict4,....]
@property (nonatomic, assign) double totalSaveSpace;
@property (nonatomic, strong)NSMutableDictionary *dataInfo;

- (void)loadVideoWithProcess:(void (^)(NSInteger current, NSInteger total,NSString *currentName))process
           completionHandler:(void (^)(BOOL success, NSError *error))completion;

// 停止扫描
- (void)stopLoadPhoto;

//获取当前种类所有视频
- (NSArray *)getVideoDataByType:(VideoCleanType)type;

//获取当前种类选中删除
- (NSArray *)getDeletedVideoByType:(VideoCleanType)type;

//更新当前种类需要删除内容
- (void)updateDeletedInfo:(id)info
                 withType:(VideoCleanType)type;

//获取删除大小
- (NSUInteger)getSizeByType:(VideoCleanType)type;

//清理操作
- (void)cleanAction:(void (^)(NSInteger current, NSInteger total,NSString *currentName))process
  completionHandler:(void (^)(BOOL success, NSUInteger size))completion;


@property (nonatomic, assign) BOOL clean;
- (NSArray *)cleanArray;
@end

NS_ASSUME_NONNULL_END
