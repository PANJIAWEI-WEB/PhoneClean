//
//  VideoUtils.m
//  PhoneClean
//
//  Created by PW on 2021/5/6.
//

#import "VideoUtils.h"
#import "ImageCompare.h"
#import <Photos/Photos.h>

@interface VideoUtils ()

@property (nonatomic, copy) void (^completionHandler)(BOOL success, NSError *error);
@property (nonatomic, copy) void (^processHandler)(NSInteger current, NSInteger total,NSString *currentName);

@property (nonatomic, strong) PHFetchResult *assetArr;

@property (nonatomic, strong) NSMutableArray *dataArr;

@property (nonatomic, assign) NSUInteger saveSpace;

@property (nonatomic, strong) PHImageRequestOptions *imageOpt;




@property (nonatomic, strong) PHAsset *lastAsset;
@property (nonatomic, strong) UIImage *lastImage;
@property (nonatomic, assign) NSInteger lastImageData;
@property (nonatomic, assign) BOOL lastSame;



@property (nonatomic, strong, readwrite) NSMutableArray *sameDateArr;
@property (nonatomic, strong, readwrite) NSMutableArray *allSimilarArray;
@property (nonatomic, strong, readwrite) NSMutableArray *largeArray;

@property (nonatomic, assign) NSUInteger similarSaveSpace;
@property (nonatomic, assign) NSUInteger largeSaveSpace;


@property (nonatomic, strong, readwrite) NSMutableArray *delSameDateArr;
@property (nonatomic, strong, readwrite) NSMutableArray *delLargeArray;


@property (nonatomic, assign)BOOL isStop;



@property (nonatomic, copy) void (^delCompletionHandler)(BOOL success, NSUInteger size);
@property (nonatomic, copy) void (^delProcessHandler)(NSInteger current, NSInteger total,NSString *currentName);

@property (nonatomic, assign) NSUInteger delSize;


@end

@implementation VideoUtils

+ (VideoUtils *)shareManager {
    static VideoUtils *manage = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manage = [[VideoUtils alloc] init];
    });
    return manage;
    
}

// 重置数据
- (void)resetTagData {
    [self.dataArr removeAllObjects];
    self.saveSpace = 0;
}

-(NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

-(NSMutableArray *)sameDateArr{
    if (!_sameDateArr) {
        _sameDateArr = [NSMutableArray array];
    }
    return _sameDateArr;
}
-(NSMutableArray *)delSameDateArr{
    if (!_delSameDateArr) {
        _delSameDateArr = [NSMutableArray array];
    }
    return _delSameDateArr;
}
-(NSMutableArray *)largeArray{
    if (!_largeArray) {
        _largeArray = [NSMutableArray array];
    }
    return _largeArray;
}
-(NSMutableArray *)delLargeArray{
    if (!_delLargeArray) {
        _delLargeArray = [NSMutableArray array];
    }
    return _delLargeArray;
}
-(NSMutableArray *)allSimilarArray{
    if (!_allSimilarArray) {
        _allSimilarArray = [NSMutableArray array];
    }
    return _allSimilarArray;
}
#pragma mark - GetImage

- (void)loadVideoWithProcess:(void (^)(NSInteger current, NSInteger total, NSString *name))process
           completionHandler:(void (^)(BOOL success, NSError *error))completion {
    [self resetTagData];
    self.isStop = NO;
    self.totalSaveSpace = 0;
    self.clean = YES;
    self.lastSame = NO;
    self.saveSpace = 0;
    self.similarSaveSpace = 0;
    self.largeSaveSpace = 0;
    self.lastAsset = nil;
    self.assetArr = nil;
    [self.sameDateArr removeAllObjects];
    [self.largeArray removeAllObjects];
    [self.allSimilarArray removeAllObjects];
    [self.delLargeArray removeAllObjects];
    [self.delSameDateArr removeAllObjects];
    self.dataInfo = [[NSMutableDictionary alloc] init];
    self.processHandler = process;
    self.completionHandler = completion;
    
    // 获取当前App的相册授权状态
    PHAuthorizationStatus authorizationStatus = [PHPhotoLibrary authorizationStatus];
    // 判断授权状态
    if (authorizationStatus == PHAuthorizationStatusAuthorized) {
        // 如果已经授权, 获取图片
        [self getAllAsset];
    }
    // 如果没决定, 弹出指示框, 让用户选择
    else if (authorizationStatus == PHAuthorizationStatusNotDetermined) {
       WeakSelf(weakSelf)
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            // 如果用户选择授权, 则获取图片
            if (status == PHAuthorizationStatusAuthorized) {
                [weakSelf getAllAsset];
            }
        }];
    } else {
        [self noticeAlert];
    }
}

// 获取相簿中的PHAsset对象
- (void)getAllAsset {
    // 获取所有资源的集合，并按资源的创建时间排序
    PHFetchOptions *options = [[PHFetchOptions alloc] init];
    options.predicate = [NSPredicate predicateWithFormat:@"mediaType == %ld",PHAssetMediaTypeVideo];
    options.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO]];
    
    PHFetchResult *result = [PHAsset fetchAssetsWithMediaType:PHAssetMediaTypeVideo options:options];
    self.assetArr = result;
    
    [self requestImageWithIndex:0];
}

// 获取图片
- (void)requestImageWithIndex:(NSInteger)index {
    
    if (index >= self.assetArr.count) {
        [self loadCompletion];
        self.totalSaveSpace = self.largeSaveSpace + self.similarSaveSpace;
        self.completionHandler(YES, nil);
        return;
    }
    if (self.isStop == YES) {
        [self stopLoadPhoto];
        return;
    }
    
    __weak typeof(self) weakSelf = self;
    // 筛选本地图片，过滤视频、iCloud图片
    PHAsset *asset = self.assetArr[index];
    
    NSString *videoName = [asset valueForKey:@"filename"];
    
    self.totalSaveSpace = self.largeSaveSpace + self.similarSaveSpace;
    self.processHandler(index, self.assetArr.count,videoName);
    
    
    
    if (asset.mediaType != PHAssetMediaTypeVideo || asset.sourceType != PHAssetSourceTypeUserLibrary) {
        [self requestImageWithIndex:index+1];
        return;
    } else { //视频处理
        [weakSelf saveData:asset andindex:index];
    }

    
}

-  (void)saveData:(PHAsset *)asset andindex:(NSInteger )index {
    PHVideoRequestOptions *options = [[PHVideoRequestOptions alloc] init];
    options.version = PHImageRequestOptionsVersionCurrent;
    options.deliveryMode = PHVideoRequestOptionsDeliveryModeAutomatic;
    
    
        __weak typeof(self) weakSelf = self;
    [[PHImageManager defaultManager] requestAVAssetForVideo:asset options:options resultHandler:^(AVAsset * _Nullable ast, AVAudioMix * _Nullable audioMix, NSDictionary * _Nullable info) {

        if ([ast isKindOfClass:[AVComposition class]]) {
            //下一个 慢动作视频 崩溃
            [weakSelf requestImageWithIndex:index+1];
        }else{
            AVURLAsset* urlAsset = (AVURLAsset*)ast;
            
            NSNumber *size;
            [urlAsset.URL getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
            weakSelf.saveSpace = weakSelf.saveSpace + [size floatValue];
            // 获取缩率图
            StrongSelf(strongSelf)
            PHImageManager *mgr = [PHImageManager defaultManager];
            [mgr requestImageForAsset:asset targetSize:CGSizeMake(125, 125) contentMode:PHImageContentModeAspectFill options:weakSelf.imageOpt resultHandler:^(UIImage *result, NSDictionary *info) {
                
                NSString *videoName = [asset valueForKey:@"filename"];
                //获取视频的缩略图
                UIImage *image = result;
                //视频时长
                NSString *timeLength = [strongSelf getVideoDurtion:[self getcalduration:asset]];
                
                //相似视频
                BOOL isSameDay = [strongSelf isSameDay:strongSelf.lastAsset.creationDate
                                                 date2:asset.creationDate];
                
                if (strongSelf.lastAsset && isSameDay) {
                    BOOL isLike = NO;
                    @try {
                        //执行的代码，如果异常,就会抛出，程序不继续执行啦
                        isLike = [ImageCompare isImage:strongSelf.lastImage likeImage:image];
                    } @catch (NSException *exception) {
                        //捕获异常
                    } @finally {
                        //这里一定执行，无论你异常与否
                    }
                    
                    if (isLike ) {
                        [strongSelf updateSimilarArrWithAsset:asset image:image imageSize:size];
                        strongSelf.lastSame = YES;
                    } else {
                        strongSelf.lastSame = NO;
                    }
                }
                
                //大视频
                if ([size integerValue] > [ConfigModel videoMaxSize] ) {
                    
                    
                    if (!(!asset || !size)) {
                        NSDictionary *itemDict = @{ @"asset" : asset,
                                                    @"size" : size };
                        
                        [strongSelf.largeArray addObject:itemDict];
                        strongSelf.largeSaveSpace += [size integerValue];
                    }
                }
                
                
                strongSelf.lastImageData = [size integerValue];
                strongSelf.lastAsset = asset;
                strongSelf.lastImage = image;
                
                //            NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:asset,@"asset",videoName,@"name",size,@"size",timeLength,@"timeLength", nil];
                //            [self.dataArr addObject:dic];
                
                [strongSelf requestImageWithIndex:index+1];
            }];
        }
    }];


}

// 更新相似图片数据
- (void)updateSimilarArrWithAsset:(PHAsset *)asset
                            image:(UIImage *)image
                        imageSize:(NSNumber *)size{
    NSDictionary *lastDict;
    {
        if (self.lastAsset) {
            NSDictionary *itemDict = @{ @"asset" : self.lastAsset,
                                        @"size" : @(self.lastImageData) };
            NSString *keyStr = [self stringWithDate:asset.creationDate];
            lastDict = @{keyStr : [@[itemDict] mutableCopy]};
            [self.sameDateArr addObject:lastDict];
        }
        
    }
    if (!asset || !lastDict) {
        return;
    }
    self.similarSaveSpace = self.similarSaveSpace + [size floatValue];
    NSMutableArray *itemArr = lastDict.allValues.lastObject;
    NSDictionary *itemDict = @{ @"asset" : asset,
                                @"size" : size};
    [itemArr addObject:itemDict];
    lastDict = @{lastDict.allKeys.lastObject : itemArr};
    [self.sameDateArr replaceObjectAtIndex:self.sameDateArr.count-1
                               withObject:lastDict];
}

#pragma mark -  加载完成
- (void)loadCompletion {
    
    if (self.dataArr.count > 0) {
        [self.dataInfo setObject:self.dataArr forKey:@"array"];
        [self.dataInfo setObject:@(self.saveSpace) forKey:@"saveSpace"];
    }else{
        
        [self.dataInfo setObject:@[] forKey:@"array"];
        [self.dataInfo setObject:@(0) forKey:@"saveSpace"];
    }
    
//    self.dataInfo =  @{@"array":self.dataArr, @"saveSpace" : @(self.saveSpace)};
    
    //加载完成，
    //待删除数据
    [self.delLargeArray removeAllObjects];
    [self.delLargeArray addObjectsFromArray:self.largeArray];
    [self.delSameDateArr removeAllObjects];
    for (NSDictionary *dict in self.sameDateArr) {
        NSArray *array = [dict allValues].firstObject;
        
        for (NSDictionary *data in array) {
            if (![self.allSimilarArray containsObject:data]) {
                [self.allSimilarArray addObject:data];
            }
        }
        [self.delSameDateArr addObject:array.lastObject];
    }
    
}


// NSDate转NSString
- (NSString *)stringWithDate:(NSDate *)date {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy年MM月dd日"];
    return [dateFormatter stringFromDate:date];
}

// 是否为同一天
- (BOOL)isSameDay:(NSDate *)date1 date2:(NSDate *)date2 {
    if (!date1 || !date2) {
        return NO;
    }
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay;
    NSDateComponents *comp1 = [calendar components:unitFlags fromDate:date1];
    NSDateComponents *comp2 = [calendar components:unitFlags fromDate:date2];
    return  [comp1 day] == [comp2 day] &&
    [comp1 month] == [comp2 month] &&
    [comp1 year]  == [comp2 year];
}

// 开启权限提示
- (void)noticeAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"此功能需要相册授权"
                                        message:@"请您在设置系统中打开授权开关"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *left = [UIAlertAction actionWithTitle:@"取消"
                                                   style:UIAlertActionStyleCancel
                                                 handler:nil];
    UIAlertAction *right = [UIAlertAction actionWithTitle:@"前往设置"
                                                    style:UIAlertActionStyleDefault
                                                  handler:^(UIAlertAction * _Nonnull action) {
                                                      NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                                                      [[UIApplication sharedApplication] openURL:url];
                                                  }];
    [alert addAction:left];
    [alert addAction:right];
    UIViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc presentViewController:alert animated:YES completion:nil];
}

- (NSInteger)getcalduration:(PHAsset *)asset{
    
    NSInteger dur;
    
    NSInteger time = asset.duration;
    
    double time2 = (double)(asset.duration - time);
    
    if (time2 < 0.5) {
        dur = asset.duration;
    }else{
        dur = asset.duration + 1;
    }
    
    return dur;
    
}


-(NSString *)getVideoDurtion:(NSInteger)duration{
    
    NSInteger h = (NSInteger)duration/3600; //总小时
    
    NSInteger mT = (NSInteger)duration%3600; //总分钟
    
    NSInteger m = mT/60; //最终分钟
    
    
    NSInteger s = mT%60; //最终秒数
    
    
    return [NSString stringWithFormat:@"%02ld:%02ld:%02ld",(long)h,(long)m,(long)s];
    
}


- (PHImageRequestOptions *)imageOpt {
    if (!_imageOpt) {
        _imageOpt = [[PHImageRequestOptions alloc] init];
        // resizeMode 属性控制图像的剪裁
        _imageOpt.resizeMode = PHImageRequestOptionsResizeModeNone;
        // deliveryMode 则用于控制请求的图片质量
        _imageOpt.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
    }
    return _imageOpt;
}




//获取当前种类所有视频
- (NSArray *)getVideoDataByType:(VideoCleanType)type{
    switch (type) {
        case VideoCleanTypeSimilar:
            return self.allSimilarArray;
            break;
            
        case VideoCleanTypeDamage:
            return @[];
            break;
            
        case VideoCleanLarge:
            return self.largeArray;
            break;
        
        default:
            return [@[] mutableCopy];
            break;
    }
}

//获取当前种类选中删除
- (NSArray *)getDeletedVideoByType:(VideoCleanType)type{
    
    switch (type) {
        case VideoCleanTypeSimilar:
            return self.delSameDateArr;
            break;
            
        case VideoCleanTypeDamage:
            return @[];
            break;
            
        case VideoCleanLarge:
            return self.delLargeArray;
            break;
        
        default:
            return [@[] mutableCopy];
            break;
    }
    
}

//更新当前种类需要删除内容
- (void)updateDeletedInfo:(id)info
                 withType:(VideoCleanType)type{
    switch (type) {
        case VideoCleanTypeSimilar:{
            if([self.delSameDateArr containsObject:info]){
                [self.delSameDateArr removeObject:info];
                self.similarSaveSpace -= [info[@"size"] integerValue];
            }else{
                [self.delSameDateArr addObject:info];
                self.similarSaveSpace += [info[@"size"] integerValue];
            }
        } break;
            
        case VideoCleanTypeDamage:
            
            break;
            
        case VideoCleanLarge:{
            if([self.delLargeArray containsObject:info]){
                [self.delLargeArray removeObject:info];
                self.largeSaveSpace -= [info[@"size"] integerValue];
            }else{
                [self.delLargeArray addObject:info];
                self.largeSaveSpace += [info[@"size"] integerValue];
            }
        } break;
            
        default:
            break;
    }
    self.totalSaveSpace = self.similarSaveSpace + self.largeSaveSpace;
}

//获取删除大小
- (NSUInteger)getSizeByType:(VideoCleanType)type{
    switch (type) {
        case VideoCleanTypeSimilar:
            return self.similarSaveSpace;
            break;
            
        case VideoCleanTypeDamage:
            return 0;
            break;
            
        case VideoCleanLarge:
            return self.largeSaveSpace;
            break;
        
        default:
            return self.totalSaveSpace;
            break;
    }
}


// 停止扫描
- (void)stopLoadPhoto{
    self.isStop = YES;
    [self loadCompletion];
    if (self.completionHandler) {
        self.completionHandler(YES, nil);
    }
}

- (void)cleanAction:(void (^)(NSInteger current, NSInteger total,NSString *currentName))process
  completionHandler:(void (^)(BOOL success, NSUInteger size))completion{
    
    
    
    if (!self.clean) {
        completion(YES,0);
        return;
    }
    
    self.delSize = 0;
    self.delCompletionHandler =  completion;
    self.delProcessHandler = process;
    //
    
    
    
    NSMutableArray *deleteArray = [NSMutableArray array];
    
    [deleteArray addObjectsFromArray:self.delSameDateArr];
    [deleteArray addObjectsFromArray:self.delLargeArray];
    
    
    [self deleInfo:deleteArray index:0];
    
}

- (NSArray *)cleanArray{
    NSMutableArray *deleteArray = [NSMutableArray array];
    
    [deleteArray addObjectsFromArray:self.delSameDateArr];
    [deleteArray addObjectsFromArray:self.delLargeArray];
    
    return deleteArray;
}
- (void)deleInfo:(NSMutableArray *)array
           index:(NSInteger)index{
    
    if (index < array.count) {
        NSDictionary *dict = array[index];
        WeakSelf(weakSelf)
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
//            [PHAssetChangeRequest deleteAssets:@[dict[@"asset"]]];
            NSMutableArray *del = [NSMutableArray array];
            for (NSDictionary *dict in array) {
                [del addObject:dict[@"asset"]];
            }
            
            
            [PHAssetChangeRequest deleteAssets:del];
            weakSelf.delProcessHandler(index, array.count, @"");
        } completionHandler:^(BOOL success, NSError * _Nullable error) {
            if (success) {
                NSMutableArray *tempArray = [array mutableCopy];
                for (NSDictionary *dict in tempArray) {
                    [array removeObject:dict];
                    if (![array containsObject:dict]) {
                        weakSelf.delSize += [dict[@"size"] integerValue];
                    }
                }
            }
            self.delCompletionHandler(YES, self.delSize);
//            [weakSelf deleInfo:array index:(index+ 1)];
        }];
    }else{
        self.delCompletionHandler(YES, self.delSize);
    }
    
    
}
// 删除照片
+ (void)deleteAssets:(NSArray<PHAsset *> *)assets completionHandler:(void (^)(BOOL, NSError * _Nonnull))completion
{
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
        // 删除当前图片资源
        [PHAssetChangeRequest deleteAssets:assets];
    } completionHandler:^(BOOL success, NSError * _Nullable error) {
        // 调用删除后的回调代码块
        if (completion)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(success, error);
            });
        }
    }];
}
@end
