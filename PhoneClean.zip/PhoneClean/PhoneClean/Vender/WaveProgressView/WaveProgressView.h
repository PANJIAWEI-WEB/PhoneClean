//
//  WaveProgressView.h
//  CleanMyIphone
//
//  Created by Claire on 2021/1/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WaveProgressView : UIView

/// 背景颜色（默认灰色）
@property (nonatomic, strong) UIColor *defaultColor;
/// 进度颜色（默认蓝色）
@property (nonatomic, strong) UIColor *progressColor;
/// 边框线条颜色（默认黑色）
@property (nonatomic, strong) UIColor *lineColor;
/// 边框线条大小（默认1.0）
@property (nonatomic, assign) CGFloat lineWidth;

/// 数值是否动画效果变化（默认无动画）
@property (nonatomic, assign) BOOL animationText;

/// 渐变颜色（默认：黄，红）
@property (nonatomic, strong) NSArray <UIColor *> *colorsGradient;
/// 是否渐变色样式（默认否）
@property (nonatomic, assign) BOOL showGradient;

/// 是否与边框有间距（默认无）
@property (nonatomic, assign) BOOL showSpace;
/// 间隔大小（默认0.0）
@property (nonatomic, assign) CGFloat spaceWidth;

/// 是否动效变换（默认否）
@property (nonatomic, assign) BOOL isAnimation;

/**
 初始化（设置属性后，最后必须调用一次）
 */
- (void)initializeProgress;
/// 是否显示边框（默认不显示）
@property (nonatomic, assign) BOOL showBorderline;

/// 进度（值范围0.0~1.0，默认0.0）
@property (nonatomic, assign) CGFloat progress;

@end

NS_ASSUME_NONNULL_END
