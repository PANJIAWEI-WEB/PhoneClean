//
//  Header.h
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#ifndef Header_h
#define Header_h

#define APPID @"1566700798"
#define APP_SHARE  [NSURL URLWithString:[NSString stringWithFormat:@"https://apps.apple.com/cn/app/id%@",APPID]]
#define APP_RATE [NSURL URLWithString:[NSString stringWithFormat:@"itms-apps://itunes.apple.com/cn/app/id%@?mt=8&action=write-review",APPID]]

//广告
//插页式
#define ID_AD_PAGE @"ca-app-pub-8768920203437542/6204687139"
//banner广告
#define ID_AD_BANNER @"ca-app-pub-8768920203437542/1562734543"




//颜色
#define RANDOM_COLOR [UIColor colorWithRed:arc4random_uniform(256) / 255.0 green:arc4random_uniform(256) / 255.0 blue:arc4random_uniform(256) / 255.0 alpha:0.2]
// rgb颜色转换（16进制->10进制）
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define UIColorFromRGBA(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF000000) >> 24))/255.0 green:((float)((rgbValue & 0xFF0000) >> 16))/255.0 blue:((float)((rgbValue & 0xFF0000) >> 8))/255.0 alpha:((float)(rgbValue & 0xFF))/255.0]

#define RGBA_COLOR(r, g, b, a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

#define RGB_COLOR(r, g, b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1.0f]



//打印
#ifdef DEBUG
#    define DLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
#    define DLog(...)
#endif
//#ifdef DEBUG
//#define NSLog(...) NSLog(@"%s 第%d行 \n %@\n\n",__func__,__LINE__,[NSString stringWithFormat:__VA_ARGS__])
//#else
//#define NSLog(...)
//#endif

//弱引用/强引用
#define WeakSelf(weakSelf)      __weak __typeof(&*self)    weakSelf  = self;
#define StrongSelf(strongSelf)  __strong __typeof(&*self) strongSelf = weakSelf;


#pragma mark 数据判断相关
//字符串是否为空
#define StringIsEmpty(str) ([str isKindOfClass:[NSNull class]] || str == nil || [str length] < 1 ? YES : NO )
//数组是否为空
#define ArrayIsEmpty(array) (array == nil || [array isKindOfClass:[NSNull class]] || array.count == 0)
//字典是否为空
#define DictIsEmpty(dic) (dic == nil || [dic isKindOfClass:[NSNull class]] || dic.allKeys == 0)



//程序的本地化，引用国际化的文件
#define LocalizedString(fmt,...) NSLocalizedString(fmt,nil)


///常用数值宏定义
// 屏幕大小
#define  ScreenBounds           [UIScreen mainScreen].bounds
#define  ScreenWidth            [UIScreen mainScreen].bounds.size.width
#define  ScreenHeight           [UIScreen mainScreen].bounds.size.height
// 屏幕宽度比例
#define  ScaleWidth             (ScreenWidth / 375.0f)
#define  ScaleHeight            (ScreenHeight / 667.0f)
#define  ScaleSize              [UIScreen mainScreen].scale
// 状态栏高度
#define StatusBarHeight         [[UIApplication sharedApplication] statusBarFrame].size.height
// 导航栏高度
#define NavigationBarHeight     (StatusBarHeight + 44)
// 标签栏高度
#define TabBarHeight            ([Tools bottmHeight] + 49)
// 标签栏高度
#define BottomHeight            [Tools bottmHeight]
// 判断是否是iPhone X
#define IS_iPhoneX              [Tools isIphoneX]
// 判断是否是小屏幕
#define IS_iPhoneSE             (ScreenWidth < 375)


//内存单位变换
#define M_KB 1000
#define M_MB (M_KB * M_KB)
#define M_GB (M_MB * M_MB)



//VIP
#define vip_month @"celan_vip_month" //包月
#define vip_quarter @"celan_vip_quarter" //包季
#define vip_week @"clean_vip_weak" //周卡

#endif /* Header_h */
