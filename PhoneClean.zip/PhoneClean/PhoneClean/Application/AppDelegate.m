//
//  AppDelegate.m
//  PhoneClean
//
//  Created by PW on 2021/5/4.
//

#import "AppDelegate.h"
#import "HomeController.h"
#import "IAPManager.h"
#import "SandBoxHelper.h"
#import "StartVIPController.h"
#import "GuideViewController.h"
#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import <AdSupport/AdSupport.h>
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];

    self.window.backgroundColor = [UIColor whiteColor];
    //设置window的rootViewController
    
    /**启动IAP工具类*/
    [[IAPManager shared] startManager];
    
    //IDFA 请求
    [self requestIDFA];
    
    
    if(![[NSUserDefaults standardUserDefaults] valueForKey:@"NotFirstIn"]){
        //第一次进入
        //引导界面，权限请求
        GuideViewController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GuideViewController"];
        
        //
        self.window.rootViewController = vc;
        
        
    }else{
        //非第一次进入
        NSInteger status = [[SandBoxHelper vipStatus] integerValue];
        if (status == 0) {
            //非会员，展示会员
            StartVIPController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"StartVIPController"];
            
            //
            self.window.rootViewController = vc;
            
        }else{
            //进入Home
            HomeController *vc = [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"HomeController"];
            
            self.window.rootViewController = vc;
            
        }
    }
    [self.window makeKeyAndVisible];
    
    return YES;
}



- (void)requestIDFA {
    if (@available(iOS 14, *)) {
        [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status) {
            // Tracking authorization completed. Start loading ads here.
            // [self loadAd];
        }];
    } else {
        // Fallback on earlier versions
    }
}


@end
